<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductPropertyItems extends Model
{
   protected $table ='hnt_product_property_items';
}
