<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductTaskReport extends Model
{
   protected $table = 'hnt_product_task_report';
}
