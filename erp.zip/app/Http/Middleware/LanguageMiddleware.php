<?php

namespace App\Http\Middleware;

use Closure;
use App;
use Illuminate\Support\Facades\Session;

class LanguageMiddleware
{
    /**

     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if (Session::has('locale')){
          App::setLocale(Session::get('locale'));
        }
        else {
            App::setLocale('fa');
            Session::put('locale','fa');
        }
        return $next($request);
    }
}
