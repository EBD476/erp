<?php $__env->startSection('title',__('Order')); ?>

<?php $__env->startSection('content'); ?>
    <!------ Include the above in your HEAD tag ---------->
    <?php if(auth()->check() && auth()->user()->hasRole('Admin')): ?>
    <div class="content persian">
        <div class="container-fluid">
            <div class="card">
                <div class="card-body">
                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-12"/>
                                <form id="form1"  action="<?php echo e(route('order.edit_pre',$order->id)); ?>" method="post" >
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                            <table class="table table-condensed">
                                                <thead>
                                                <tr>
                                                    <td class="text-left"><h4
                                                                style="margin-top:30px;"><?php echo e(__('Date:')); ?> <?php echo e($data->hop_due_date); ?></h4>
                                                        <input name="hop_due_date" value="<?php echo e($data->hop_due_date); ?>"
                                                               type="hidden">
                                                    </td>
                                                    <td class="text-center"><h1
                                                                style="margin-top:70px; margin-right: 150px ; margin-left: 150px"><?php echo e(__('Pre Invoice Sales Of Product')); ?></h1>
                                                    </td>
                                                    <td><img align="right" width="170" height="170"
                                                             src="<?php echo e(asset('assets/images/g.png')); ?>">
                                                    </td>

                                                </tr>
                                                </thead>
                                            </table>
                                        </div>
                                        <div class="panel-body">
                                            <div class="table-responsive">
                                                <table class="table table-condensed">
                                                    <thead>
                                                    <tr>
                                                        <th class="text-center">
                                                            <strong><?php echo e(__('Owner profile')); ?>

                                                                <?php $__currentLoopData = $client; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clients): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if($clients->id == $order->ho_client): ?>
                                                                        &nbsp;<?php echo e($clients->hc_name); ?>

                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                &nbsp;<?php echo e($order->hp_phone_number); ?></strong>
                                                            <input value="<?php echo e($order->ho_client); ?>"
                                                                   name="hpo_client_id"
                                                                   type="hidden">
                                                            <input value="<?php echo e($order->id); ?>" name="hpo_order_id"
                                                                   id="hpo_order_id"
                                                                   type="hidden">
                                                        </th>
                                                        <th class="text-center">
                                                            <?php echo e(__('Employer Name:')); ?>

                                                            &nbsp;<?php echo e($order->hp_employer_name); ?></th>
                                                        <th class="text-center"><?php echo e(__('Project Name:')); ?>

                                                            &nbsp;<?php echo e($order->hp_project_name); ?></th>
                                                        <th class="text-center">&nbsp;<?php echo e(__('Type Project:')); ?>

                                                            &nbsp;<?php echo e($order->hp_type_project); ?></th>
                                                        <th class="text-center">
                                                            <?php echo e(__('Address:')); ?>

                                                            &nbsp;<?php echo e($state->hp_project_state); ?><?php echo e($city->hp_city); ?>

                                                            &nbsp;<?php echo e($order->hp_address); ?>

                                                        </th>
                                                        <th class="text-center">
                                                            &nbsp;<?php echo e(__('Create By:')); ?>

                                                            &nbsp;<?php echo e($order->hp_registrant); ?>

                                                        </th>
                                                    </tr>
                                                    <tr>
                                                        <th class="text-center"><strong><?php echo e(__('Row')); ?></strong></th>
                                                        <th class="text-center">
                                                            <strong><?php echo e(__('Product Name')); ?></strong>
                                                        </th>
                                                        <th class="text-center">
                                                            <strong><?php echo e(__('Description of Product')); ?></strong></th>
                                                        <th class="text-center"><strong><?php echo e(__('Price')); ?></strong>
                                                        </th>
                                                        <th class="text-center"><strong><?php echo e(__('Quantity')); ?></strong>
                                                        </th>
                                                        <th class="text-center"><strong><?php echo e(__('Sub Total')); ?></strong>
                                                        </th>

                                                    </tr>
                                                    </thead>
                                                    <tbody>
                                                    <!-- foreach ($order->lineItems as $line) or some such thing here -->
                                                    <div hidden><?php echo e($index = 0); ?></div>
                                                    <?php $__currentLoopData = $data->name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data_loop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($products->id == $data->name[$index]): ?>
                                                                <tr>
                                                                    <td class="text-center"><?php echo e($key + 1); ?></td>
                                                                    <input type="hidden"
                                                                           value="<?php echo e($data->name[$index]); ?>"
                                                                           name="name[]">
                                                                    <td class="text-center"><?php echo e($products->hp_product_name . $products->hp_product_model . $products->hp_product_color_id . $products->hp_product_size . $products->hp_product_property . $products->hp_product_code_number); ?></td>
                                                                    <td class="text-center"><?php echo e($data->invoice_items[$index]); ?></td>
                                                                    <input value="<?php echo e($data->invoice_items[$index]); ?>"
                                                                           name="invoice_items[]" type="hidden">
                                                                    <td class="text-center"><?php echo e($products->hp_product_price); ?></td>
                                                                    <td class="text-center"><?php echo e($data->invoice_items_qty[$index]); ?></td>
                                                                    <input value="<?php echo e($data->invoice_items_qty[$index]); ?>"
                                                                           name="invoice_items_qty[]" type="hidden">
                                                                    <td class="text-center"><?php echo e($data->total[$index]); ?></td>
                                                                    <input value="<?php echo e($data->total[$index]); ?>"
                                                                           name="total[]"
                                                                           type="hidden">
                                                                    <td hidden="hidden"><?php echo e($index++); ?></td>
                                                                </tr>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <td class="thick-line"></td>
                                                    </tbody>
                                                    <table>
                                                        <tr>
                                                            <th class="no-line"></th>
                                                            <th class="no-line"></th>
                                                            <th class="no-line">
                                                                <strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo e(__('Totals')); ?></strong>&nbsp;<?php echo e($data->all_tot); ?>

                                                                <input value="<?php echo e($data->all_tot); ?>" name="all_tot"
                                                                       type="hidden">
                                                            </th>

                                                        </tr>
                                                        <?php if($data->hpo_discount != ""): ?>
                                                            <tr>
                                                                <th class="no-line"></th>
                                                                <th class="no-line"></th>
                                                                <th class="no-line">
                                                                    <strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo e(__('Discount')); ?>

                                                                        %&nbsp;</strong><?php echo e($data->hpo_discount); ?>

                                                                    &nbsp;&nbsp;
                                                                    <input value="<?php echo e($data->hpo_discount); ?>"
                                                                           name="hpo_discount"
                                                                           type="hidden">
                                                                </th>
                                                            </tr>
                                                            <tr>
                                                                <th class="no-line"></th>
                                                                <th class="no-line"></th>
                                                                <th class="no-line">
                                                                    <strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo e(__('Total including discount:')); ?>

                                                                        &nbsp;</strong><?php echo e($data->all_dis); ?></th>
                                                                <input value="<?php echo e($data->all_dis); ?>" name="all_dis"
                                                                       type="hidden">
                                                            </tr>
                                                            <tr>
                                                                <th class="no-line"></th>
                                                                <th class="no-line"></th>
                                                                &nbsp;
                                                            </tr>
                                                        <?php endif; ?>
                                                    </table>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                    <button id="edit_pre" type="submit"
                                            class="btn btn-outline-light"><?php echo e(__('Back')); ?></button>
                                </form>
                                <div class="row">
                                    <div class="col-md-12">
                                        <button type="submit"
                                                id="btn-1" class="btn btn-outline-light"><?php echo e(__('Verify')); ?></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('order')): ?>
    <div class="content persian">
        <div class="container-fluid">
            <div class="card">
                <div class="card-body">
                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <form  action="<?php echo e(route('order.edit_pre',$order->id)); ?>" method="post" >
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <div class="panel panel-default">
                                            <div class="panel-heading">
                                                <table class="table table-condensed">
                                                    <thead>
                                                    <tr>
                                                        <td class="text-left"><h4
                                                                    style="margin-top:30px;"><?php echo e(__('Date:')); ?> <?php echo e($data->hop_due_date); ?></h4>
                                                            <input name="hop_due_date" value="<?php echo e($data->hop_due_date); ?>"
                                                                   type="hidden">
                                                        </td>
                                                        <td class="text-center"><h1
                                                                    style="margin-top:70px; margin-right: 150px ; margin-left: 150px"><?php echo e(__('Pre Invoice Sales Of Product')); ?></h1>
                                                        </td>
                                                        <td><img align="right" width="170" height="170"
                                                                 src="<?php echo e(asset('assets/images/g.png')); ?>">
                                                        </td>

                                                    </tr>
                                                    </thead>
                                                </table>
                                            </div>
                                            <div class="panel-body">
                                                <div class="table-responsive">
                                                    <table class="table table-condensed">
                                                        <thead>
                                                        <tr>
                                                            <th class="text-center">
                                                                <strong><?php echo e(__('Owner profile')); ?>

                                                                    <?php $__currentLoopData = $client; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clients): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php if($clients->id == $order->ho_client): ?>
                                                                            &nbsp;<?php echo e($clients->hc_name); ?>

                                                                        <?php endif; ?>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    &nbsp;<?php echo e($order->hp_phone_number); ?></strong>
                                                                <input value="<?php echo e($order->ho_client); ?>"
                                                                       name="hpo_client_id"
                                                                       type="hidden">
                                                                <input value="<?php echo e($order->id); ?>" name="hpo_order_id"
                                                                       id="hpo_order_id"
                                                                       type="hidden">
                                                            </th>
                                                            <th class="text-center">
                                                                <?php echo e(__('Employer Name:')); ?>

                                                                &nbsp;<?php echo e($order->hp_employer_name); ?></th>
                                                            <th class="text-center"><?php echo e(__('Project Name:')); ?>

                                                                &nbsp;<?php echo e($order->hp_project_name); ?></th>
                                                            <th class="text-center">&nbsp;<?php echo e(__('Type Project:')); ?>

                                                                &nbsp;<?php echo e($order->hp_type_project); ?></th>
                                                            <th class="text-center">
                                                                <?php echo e(__('Address:')); ?>

                                                                &nbsp;<?php echo e($state->hp_project_state); ?><?php echo e($city->hp_city); ?>

                                                                &nbsp;<?php echo e($order->hp_address); ?>

                                                            </th>
                                                            <th class="text-center">
                                                                &nbsp;<?php echo e(__('Create By:')); ?>

                                                                &nbsp;<?php echo e($order->hp_registrant); ?>

                                                            </th>
                                                        </tr>
                                                        <tr>
                                                            <th class="text-center"><strong><?php echo e(__('Row')); ?></strong></th>
                                                            <th class="text-center">
                                                                <strong><?php echo e(__('Product Name')); ?></strong>
                                                            </th>
                                                            <th class="text-center">
                                                                <strong><?php echo e(__('Description of Product')); ?></strong></th>
                                                            <th class="text-center"><strong><?php echo e(__('Price')); ?></strong>
                                                            </th>
                                                            <th class="text-center"><strong><?php echo e(__('Quantity')); ?></strong>
                                                            </th>
                                                            <th class="text-center"><strong><?php echo e(__('Sub Total')); ?></strong>
                                                            </th>

                                                        </tr>
                                                        </thead>
                                                        <tbody>
                                                        <!-- foreach ($order->lineItems as $line) or some such thing here -->
                                                        <div hidden><?php echo e($index = 0); ?></div>
                                                        <?php $__currentLoopData = $data->name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data_loop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if($products->id == $data->name[$index]): ?>
                                                                    <tr>
                                                                        <td class="text-center"><?php echo e($key + 1); ?></td>
                                                                        <input type="hidden"
                                                                               value="<?php echo e($data->name[$index]); ?>"
                                                                               name="name[]">
                                                                        <td class="text-center"><?php echo e($products->hp_product_name . $products->hp_product_model . $products->hp_product_color_id . $products->hp_product_size . $products->hp_product_property . $products->hp_product_code_number); ?></td>
                                                                        <td class="text-center"><?php echo e($data->invoice_items[$index]); ?></td>
                                                                        <input value="<?php echo e($data->invoice_items[$index]); ?>"
                                                                               name="invoice_items[]" type="hidden">
                                                                        <td class="text-center"><?php echo e($products->hp_product_price); ?></td>
                                                                        <td class="text-center"><?php echo e($data->invoice_items_qty[$index]); ?></td>
                                                                        <input value="<?php echo e($data->invoice_items_qty[$index]); ?>"
                                                                               name="invoice_items_qty[]" type="hidden">
                                                                        <td class="text-center"><?php echo e($data->total[$index]); ?></td>
                                                                        <input value="<?php echo e($data->total[$index]); ?>"
                                                                               name="total[]"
                                                                               type="hidden">
                                                                        <td hidden="hidden"><?php echo e($index++); ?></td>
                                                                    </tr>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <td class="thick-line"></td>
                                                        </tbody>
                                                        <table>
                                                            <tr>
                                                                <th class="no-line"></th>
                                                                <th class="no-line"></th>
                                                                <th class="no-line">
                                                                    <strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo e(__('Totals')); ?></strong>&nbsp;<?php echo e($data->all_tot); ?>

                                                                    <input value="<?php echo e($data->all_tot); ?>" name="all_tot"
                                                                           type="hidden">
                                                                </th>

                                                            </tr>
                                                            <?php if($data->hpo_discount != ""): ?>
                                                                <tr>
                                                                    <th class="no-line"></th>
                                                                    <th class="no-line"></th>
                                                                    <th class="no-line">
                                                                        <strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo e(__('Discount')); ?>

                                                                            %&nbsp;</strong><?php echo e($data->hpo_discount); ?>

                                                                        &nbsp;&nbsp;
                                                                        <input value="<?php echo e($data->hpo_discount); ?>"
                                                                               name="hpo_discount"
                                                                               type="hidden">
                                                                    </th>
                                                                </tr>
                                                                <tr>
                                                                    <th class="no-line"></th>
                                                                    <th class="no-line"></th>
                                                                    <th class="no-line">
                                                                        <strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo e(__('Total including discount:')); ?>

                                                                            &nbsp;</strong><?php echo e($data->all_dis); ?></th>
                                                                    <input value="<?php echo e($data->all_dis); ?>" name="all_dis"
                                                                           type="hidden">
                                                                </tr>
                                                                <tr>
                                                                    <th class="no-line"></th>
                                                                    <th class="no-line"></th>
                                                                    &nbsp;
                                                                </tr>
                                                            <?php endif; ?>
                                                        </table>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                        <button type="submit"
                                                class="btn btn-outline-light"><?php echo e(__('Back')); ?></button>
                                    </form>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <button type="submit"
                                                    id="btn-1" class="btn btn-outline-light"><?php echo e(__('Verify')); ?></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('assets/js/plugins/jquery.blockUI.js')); ?>" type="text/javascript"></script>
    <script>
        $(document).ready(function () {
            // $('#edit_pre').on('click', function (event) {
            //     var oid = $("#hpo_order_id").val();
            //     var data = $("#form1").serialize();
            //     event.preventDefault();
            //     $.ajaxSetup({
            //         headers: {
            //             'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            //         }
            //     });
            //
            //
            //     $.ajax({
            //         url: '/edit_pre/' + oid,
            //         type: 'POST',
            //         data: data,
            //         dataType: 'json',
            //         method: 'put',
            //
            //         success: function (data) {
            //             alert(data.response);
            //             $('.container-fluid').html(data.response);
            //         },
            //         cache: false,
            //     });
            // })
            $("#btn-1").on('click', function (event) {
                var data = $("#form1").serialize();
                event.preventDefault();
                $.blockUI({
                    message: '<?php echo e(__('please wait...')); ?>', css: {
                        border: 'none',
                        padding: '15px',
                        backgroundColor: '#000',
                        '-webkit-border-radius': '10px',
                        '-moz-border-radius': '10px',
                        opacity: .5,
                        color: '#fff'
                    }
                });
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });

                $.ajax({
                    url: '/order_product',
                    type: 'POST',
                    data: data,
                    dataType: 'json',
                    async: false,
                    success: function (data) {
                        setTimeout($.unblockUI, 2000);
                        window.location.href = "/order";
                    },
                    cache: false,
                });
            });
        });

    </script>

<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>