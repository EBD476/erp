<?php $__env->startPush('css'); ?>
    <link href="<?php echo e(asset('assets/css/leaflet.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
                <div id="map" class="map" style="width: 100%; height: 100%;direction: ltr"></div>
<?php $__env->stopSection(); ?>

 <?php $__env->startPush('scripts'); ?>


    <script type="text/javascript" src="<?php echo e(asset('assets/js/plugins/perfect-scrollbar.jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugins/leaflet.js')); ?>"></script>

    <script>
        $(document).ready(function(){

            var isWindows = navigator.platform.indexOf('Win') > -1 ? true : false;

            /**** Scroller ****/

            // if ($.fn.niceScroll){
            //     var mainScroller = $("html").niceScroll({
            //         zindex:999999,
            //         boxzoom:true,
            //         cursoropacitymin :0.5,
            //         cursoropacitymax :0.8,
            //         cursorwidth :"10px",
            //         cursorborder :"0px solid",
            //         autohidemode:false
            //     });
            // };

            /*** PerfectScrollbar ****/

            if (isWindows) {

                if ($('.main-panel').length != 0) {
                    var ps = new PerfectScrollbar('.main-panel', {
                        wheelSpeed: 2,
                        wheelPropagation: true,
                        minScrollbarLength: 20,
                        suppressScrollX: true
                    });
                }

                if ($('.sidebar .sidebar-wrapper').length != 0) {

                    var ps1 = new PerfectScrollbar('.sidebar .sidebar-wrapper');
                    $('.table-responsive').each(function () {
                        var ps2 = new PerfectScrollbar($(this)[0]);
                    });
                }

                $('html').addClass('perfect-scrollbar-on');
            }

            var greenIcon = L.icon({
                iconUrl: '../../assets/images/marker-icon.png',
                iconSize:     [24, 24], // size of the icon
            });

            var cities = L.layerGroup();

            <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               L.marker([<?php echo e($project->hp_project_location); ?>], {icon: greenIcon}).bindPopup('HANTA Smart Home Project').addTo(cities);
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            var mbAttr = '',
                mbUrl = 'https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token=pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTA2emYycXBndHRqcmZ3N3gifQ.rJcFIG214AriISLbB6B5aw';

            var grayscale   = L.tileLayer(mbUrl, {id: 'mapbox.light', attribution: mbAttr}),
                streets  = L.tileLayer(mbUrl, {id: 'mapbox.streets',   attribution: mbAttr});

            var map = L.map('map', {
                center: [32.760,53.503],
                zoom: 5,
                layers: [cities,grayscale]
            });

            var baseLayers = {
                "Grayscale": grayscale,
                "Streets": streets
            };

            var overlays = {
                "Cities": cities
            };

            sidebar_mini_active = true;

            $('body').addClass('sidebar-mini');
            $(".navbar").removeClass('bg-gradient-light');
            $(".navbar").addClass('bg-transparent');
            // map.on('click', onMapClick);

        });
    </script>
  <?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>