<div class="sidebar" data="purple">
    <!-- Tip 1: You can change the color of the sidebar using: data-color="blue | green | orange | red"-->
    <div class="sidebar-wrapper">
        <div class="logo">
            <a href="javascript:void(0)" class="simple-text logo-mini">

            </a>

            <a href="javascript:void(0)" class="simple-text logo-normal">
                <small>Hanta Smart Home</small>
            </a>
        </div>
        <?php if(auth()->check() && auth()->user()->hasRole('super admin')): ?>
        <!-- Sidebar -->
        <ul class="nav">
            <li class="nav-item ">
                <a class="nav-link" href="<?php echo e(route('home')); ?>">
                    <i class="tim-icons icon-chart-pie-36" style="float: right"></i>
                    <p><?php echo e(__('Dashboard')); ?></p>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link collapsed" data-toggle="collapse" href="#componentsExamples" aria-expanded="false">
                    <i class="tim-icons icon-coins" style="float: right"></i>
                    <p>
                        <?php echo e(__('Order')); ?>

                        <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse" id="componentsExamples" style="">
                    <ul class="nav">
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('order.index')); ?>">
                                <i class="tim-icons icon-coins"></i>
                                <span class="sidebar-normal"> <?php echo e(__('Order')); ?></span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="collapse" href="#formsExamples">
                    <i class="tim-icons icon-coins" style="float: right"></i>
                    <p>
                        <?php echo e(__('Agreement')); ?>

                        <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse " id="formsExamples">
                    <ul class="nav">
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('agreement.index')); ?>">
                                <i class="tim-icons icon-coins"></i>
                                <span class="sidebar-normal"
                                ><?php echo e(__('Agreement Management')); ?></span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="collapse" href="#tablesExamples">
                    <i class="tim-icons icon-coins" style="float: right"></i>
                    <p>
                        <?php echo e(__('Finance')); ?>

                        <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse " id="tablesExamples">
                    <ul class="nav">
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('finance.index')); ?>">
                                <i class="tim-icons icon-coins"></i>
                                <span class="sidebar-normal"><?php echo e(__('Finance Product')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('fund.index')); ?>">
                                <i class="tim-icons icon-coins"></i>
                                <span class="sidebar-normal">
                                    <?php echo e(__('Fund')); ?>

                                </span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('finance.index')); ?>">
                                <i class="tim-icons icon-coins"></i>
                                <span class="sidebar-normal"> <?php echo e(__('Debit')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('finance.index')); ?>">
                                <i class="tim-icons icon-coins"></i>
                                <span class="sidebar-normal"> <?php echo e(__('Revenue')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('finance.index')); ?>">
                                <i class="tim-icons icon-coins"></i>
                                <span class="sidebar-normal"> <?php echo e(__('Costs')); ?></span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="collapse" href="#ProductExamples" aria-expanded="true">
                    <i class="tim-icons icon-app" style="float: right"></i>
                    <p>
                        <?php echo e(__('Product')); ?>

                        <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse show" id="ProductExamples" style="">
                    <ul class="nav">
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('repository_requirement.index')); ?>">
                                <i class="tim-icons icon-bullet-list-67"></i>
                                <span class="sidebar-normal"
                                ><?php echo e(__('Product Requirement')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(Route('product.index')); ?>">
                                <i class="tim-icons icon-app" style="size: 8px"></i>
                                <span class="sidebar-normal"><?php echo e(__('Product')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('repository-part.index')); ?>">
                                <i class="tim-icons icon-paper"></i>
                                <span class="sidebar-normal"><?php echo e(__('Part Repository')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('part.index')); ?>">
                                <i class="tim-icons icon-settings-gear-63"></i>
                                <span class="sidebar-normal"><?php echo e(__('Parts')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('product_part.index')); ?>">
                                <i class="tim-icons icon-settings-gear-63"></i>
                                <span class="sidebar-normal"><?php echo e(__('Product Parts')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('product-color.index')); ?>">
                                <i class="tim-icons icon-single-02"></i>
                                <span class="sidebar-normal"><?php echo e(__('Product Color')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('product-property.index')); ?>">
                                <i class="tim-icons icon-single-02"></i>
                                <span class="sidebar-normal"><?php echo e(__('Product Property')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('product-property-items.index')); ?>">
                                <i class="tim-icons icon-single-02"></i>
                                <span class="sidebar-normal"><?php echo e(__('Product Property Items')); ?></span>
                            </a>
                        </li>

                    </ul>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="collapse" href="#projectExamples">
                    <i class="tim-icons icon-molecule-40" style="float: right"></i>
                    <p>
                        <?php echo e(__('Project')); ?>

                        <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse " id="projectExamples">
                    <ul class="nav">
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('projects.index')); ?>">
                                <i class="tim-icons icon-paper"></i> <span
                                        class="sidebar-normal"><?php echo e(__('Projects Management')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('map')); ?>">
                                <i class="tim-icons icon-square-pin"></i>
                                <span class="sidebar-normal"
                                ><?php echo e(__('Projects Map')); ?></span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            
            
            
            
            
            
            <li class="nav-item">
                <a class="nav-link" data-toggle="collapse" href="#RepositoryExamples">
                    <i class="tim-icons icon-wallet-43" style="float: right"></i>
                    <p>
                        <?php echo e(__('Repository')); ?>

                        <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse " id="RepositoryExamples">
                    <ul class="nav">
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(Route('repository.index')); ?>">
                                <i class="tim-icons icon-paper"></i> <span
                                        class="sidebar-normal"> <?php echo e(__('Repository')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('repository_create.index')); ?>">
                                <i class="tim-icons icon-wallet-43"></i>
                                <span class="sidebar-normal"><?php echo e(__('Repository Management')); ?></span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="collapse" href="#InstallExamples">
                    <i class="tim-icons icon-wallet-43" style="float: right"></i>
                    <p>
                        <?php echo e(__('Install')); ?>

                        <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse " id="InstallExamples">
                    <ul class="nav">
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(Route('install.index')); ?>">
                                <i class="tim-icons icon-paper"></i> <span
                                        class="sidebar-normal"> <?php echo e(__('Install Management')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(Route('delivery.index')); ?>">
                                <i class="tim-icons icon-wallet-43"></i>
                                <span class="sidebar-normal"><?php echo e(__('Delivery Management')); ?></span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="collapse" href="#SupportExamples">
                    <i class="tim-icons icon-wallet-43" style="float: right"></i>
                    <p>
                        <?php echo e(__('Support')); ?>

                        <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse " id="SupportExamples">
                    <ul class="nav">
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(Route('support.index')); ?>">
                                <i class="tim-icons icon-wallet-43"></i>
                                <span class="sidebar-normal"> <?php echo e(__('Support List')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(Route('support_status.index')); ?>">
                                <i class="tim-icons icon-wallet-43"></i>
                                <span class="sidebar-normal"> <?php echo e(__('Support Status')); ?></span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="collapse" href="#HelpDeskExamples">
                    <i class="tim-icons icon-headphones" style="float: right"></i>
                    <p>
                        <?php echo e(__('Help Desk')); ?>

                        <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse " id="HelpDeskExamples">
                    <ul class="nav">
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('help_desk.index')); ?>">
                                <i class="tim-icons icon-headphones"></i>
                                <span class="sidebar-normal"> <?php echo e(__('Help Desk')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('priority.index')); ?>">
                                <i class="tim-icons icon-headphones"></i>
                                <span class="sidebar-normal">
                                    <?php echo e(__('Priority')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('type.index')); ?>">
                                <i class="tim-icons icon-headphones"></i>
                                <span class="sidebar-normal"><?php echo e(__('Type')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item  ">
                            <a class="nav-link" href="<?php echo e(route('ticket.index')); ?>">
                                <i class="tim-icons icon-headphones"></i>
                                <span class="sidebar-normal"><?php echo e(__('Ticket Status')); ?></span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="collapse" href="#UsersExamples">
                    <i class="tim-icons icon-user-run" style="float: right"></i>
                    <p>
                        <?php echo e(__('Users')); ?>

                        <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse " id="UsersExamples">
                    <ul class="nav">
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('users.index')); ?>">
                                <i class="tim-icons icon-paper"></i>
                                <span class="sidebar-normal"><?php echo e(__('Manage Users')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('roles.index')); ?>">
                                <i class="tim-icons icon-user-run"></i>
                                <span class="sidebar-normal"><?php echo e(__('Manage Roles')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('verifier.index')); ?>">
                                <i class="tim-icons icon-check-2"></i>
                                <span class="sidebar-normal"><?php echo e(__('Verifier')); ?></span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="collapse" href="#ConversationExamples">
                    <i class="tim-icons icon-single-02" style="float: right"></i>
                    <p>
                        <?php echo e(__('Conversation View')); ?>

                        <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse " id="ConversationExamples">
                    <ul class="nav">
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('conversation_view.index')); ?>">
                                <i class="tim-icons icon-single-02"></i>
                                <span class="sidebar-normal"> <?php echo e(__('Conversation View')); ?></span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="collapse" href="#ClientExamples">
                    <i class="tim-icons icon-single-02" style="float: right"></i>
                    <p>
                        <?php echo e(__('Client')); ?>

                        <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse " id="ClientExamples">
                    <ul class="nav">
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('client.index')); ?>">
                                <i class="tim-icons icon-single-02"></i>
                                <span class="sidebar-normal"> <?php echo e(__('Client')); ?></span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="collapse" href="#ClientExamples">
                    <i class="tim-icons icon-single-02" style="float: right"></i>
                    <p>
                        <?php echo e(__('Setting')); ?>

                        <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse " id="ClientExamples">
                    <ul class="nav">
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('level.index')); ?>">
                                <i class="tim-icons icon-single-02"></i>
                                <span class="sidebar-normal"> <?php echo e(__('HNT Level')); ?></span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
        </ul>
        <!-- End of Sidebar -->
        <?php endif; ?>
        <?php if(auth()->check() && auth()->user()->hasRole('Admin')): ?>
        <!-- Sidebar -->
        <ul class="nav">
            <li class="nav-item ">
                <a class="nav-link" href="<?php echo e(route('home')); ?>">
                    <i class="tim-icons icon-chart-pie-36" style="float: right"></i>
                    <p><?php echo e(__('Dashboard')); ?></p>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link collapsed" data-toggle="collapse" href="#componentsExamples" aria-expanded="false">
                    <i class="tim-icons icon-coins" style="float: right"></i>
                    <p>
                        <?php echo e(__('Order')); ?>

                        <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse" id="componentsExamples" style="">
                    <ul class="nav">
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('order.index')); ?>">
                                <i class="tim-icons icon-coins"></i>
                                <span class="sidebar-normal"> <?php echo e(__('Order')); ?></span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="collapse" href="#formsExamples">
                    <i class="tim-icons icon-coins" style="float: right"></i>
                    <p>
                        <?php echo e(__('Agreement')); ?>

                        <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse " id="formsExamples">
                    <ul class="nav">
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('agreement.index')); ?>">
                                <i class="tim-icons icon-coins"></i>
                                <span class="sidebar-normal"
                                ><?php echo e(__('Agreement Management')); ?></span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="collapse" href="#tablesExamples">
                    <i class="tim-icons icon-coins" style="float: right"></i>
                    <p>
                        <?php echo e(__('Finance')); ?>

                        <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse " id="tablesExamples">
                    <ul class="nav">
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('finance.index')); ?>">
                                <i class="tim-icons icon-coins"></i>
                                <span class="sidebar-normal"><?php echo e(__('Finance Product')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('fund.index')); ?>">
                                <i class="tim-icons icon-coins"></i>
                                <span class="sidebar-normal">
                                    <?php echo e(__('Fund')); ?>

                                </span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('finance.index')); ?>">
                                <i class="tim-icons icon-coins"></i>
                                <span class="sidebar-normal"> <?php echo e(__('Debit')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('finance.index')); ?>">
                                <i class="tim-icons icon-coins"></i>
                                <span class="sidebar-normal"> <?php echo e(__('Revenue')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('finance.index')); ?>">
                                <i class="tim-icons icon-coins"></i>
                                <span class="sidebar-normal"> <?php echo e(__('Costs')); ?></span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="collapse" href="#ProductExamples" aria-expanded="true">
                    <i class="tim-icons icon-app" style="float: right"></i>
                    <p>
                        <?php echo e(__('Product')); ?>

                        <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse show" id="ProductExamples" style="">
                    <ul class="nav">
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('repository_requirement.index')); ?>">
                                <i class="tim-icons icon-bullet-list-67"></i>
                                <span class="sidebar-normal"
                                ><?php echo e(__('Product Requirement')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(Route('product.index')); ?>">
                                <i class="tim-icons icon-app" style="size: 8px"></i>
                                <span class="sidebar-normal"><?php echo e(__('Product')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('repository-part.index')); ?>">
                                <i class="tim-icons icon-paper"></i>
                                <span class="sidebar-normal"><?php echo e(__('Part Repository')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('part.index')); ?>">
                                <i class="tim-icons icon-settings-gear-63"></i>
                                <span class="sidebar-normal"><?php echo e(__('Parts')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('product_part.index')); ?>">
                                <i class="tim-icons icon-settings-gear-63"></i>
                                <span class="sidebar-normal"><?php echo e(__('Product Parts')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('provider.index')); ?>">
                                <i class="tim-icons icon-single-02"></i>
                                <span class="sidebar-normal"><?php echo e(__('Provider')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('product-color.index')); ?>">
                                <i class="tim-icons icon-single-02"></i>
                                <span class="sidebar-normal"><?php echo e(__('Product Color')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('product-property.index')); ?>">
                                <i class="tim-icons icon-single-02"></i>
                                <span class="sidebar-normal"><?php echo e(__('Product Property')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('product-property-items.index')); ?>">
                                <i class="tim-icons icon-single-02"></i>
                                <span class="sidebar-normal"><?php echo e(__('Product Property Items')); ?></span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="collapse" href="#projectExamples">
                    <i class="tim-icons icon-molecule-40" style="float: right"></i>
                    <p>
                        <?php echo e(__('Project')); ?>

                        <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse " id="projectExamples">
                    <ul class="nav">
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('projects.index')); ?>">
                                <i class="tim-icons icon-paper"></i> <span
                                        class="sidebar-normal"><?php echo e(__('Projects Management')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('map')); ?>">
                                <i class="tim-icons icon-square-pin"></i>
                                <span class="sidebar-normal"
                                ><?php echo e(__('Projects Map')); ?></span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            
            
            
            
            
            
            <li class="nav-item">
                <a class="nav-link" data-toggle="collapse" href="#RepositoryExamples">
                    <i class="tim-icons icon-wallet-43" style="float: right"></i>
                    <p>
                        <?php echo e(__('Repository')); ?>

                        <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse " id="RepositoryExamples">
                    <ul class="nav">
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(Route('repository.index')); ?>">
                                <i class="tim-icons icon-paper"></i> <span
                                        class="sidebar-normal"> <?php echo e(__('Repository')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('repository_create.index')); ?>">
                                <i class="tim-icons icon-wallet-43"></i>
                                <span class="sidebar-normal"><?php echo e(__('Repository Management')); ?></span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="collapse" href="#InstallExamples">
                    <i class="tim-icons icon-wallet-43" style="float: right"></i>
                    <p>
                        <?php echo e(__('Install')); ?>

                        <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse " id="InstallExamples">
                    <ul class="nav">
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(Route('install.index')); ?>">
                                <i class="tim-icons icon-paper"></i> <span
                                        class="sidebar-normal"> <?php echo e(__('Install Management')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(Route('delivery.index')); ?>">
                                <i class="tim-icons icon-wallet-43"></i>
                                <span class="sidebar-normal"><?php echo e(__('Delivery Management')); ?></span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="collapse" href="#SupportExamples">
                    <i class="tim-icons icon-wallet-43" style="float: right"></i>
                    <p>
                        <?php echo e(__('Support')); ?>

                        <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse " id="SupportExamples">
                    <ul class="nav">
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(Route('support.index')); ?>">
                                <i class="tim-icons icon-wallet-43"></i>
                                <span class="sidebar-normal"> <?php echo e(__('Support List')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(Route('support_status.index')); ?>">
                                <i class="tim-icons icon-wallet-43"></i>
                                <span class="sidebar-normal"> <?php echo e(__('Support Status')); ?></span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="collapse" href="#HelpDeskExamples">
                    <i class="tim-icons icon-headphones" style="float: right"></i>
                    <p>
                        <?php echo e(__('Help Desk')); ?>

                        <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse " id="HelpDeskExamples">
                    <ul class="nav">
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('help_desk.index')); ?>">
                                <i class="tim-icons icon-headphones"></i>
                                <span class="sidebar-normal"> <?php echo e(__('Help Desk')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('priority.index')); ?>">
                                <i class="tim-icons icon-headphones"></i>
                                <span class="sidebar-normal">
                                    <?php echo e(__('Priority')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('type.index')); ?>">
                                <i class="tim-icons icon-headphones"></i>
                                <span class="sidebar-normal"><?php echo e(__('Type')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item  ">
                            <a class="nav-link" href="<?php echo e(route('ticket.index')); ?>">
                                <i class="tim-icons icon-headphones"></i>
                                <span class="sidebar-normal"><?php echo e(__('Ticket Status')); ?></span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="nav-item">
                    <a class="nav-link" data-toggle="collapse" href="#UsersExamples">
                        <i class="tim-icons icon-user-run" style="float: right"></i>
                        <p>
                            <?php echo e(__('Users')); ?>

                            <b class="caret"></b>
                        </p>
                    </a>
                    <div class="collapse " id="UsersExamples">
                        <ul class="nav">
                            <li class="nav-item ">
                                <a class="nav-link" href="<?php echo e(route('users.index')); ?>">
                                    <i class="tim-icons icon-paper"></i>
                                    <span class="sidebar-normal"><?php echo e(__('Manage Users')); ?></span>
                                </a>
                            </li>
                            <li class="nav-item ">
                                <a class="nav-link" href="<?php echo e(route('roles.index')); ?>">
                                    <i class="tim-icons icon-user-run"></i>
                                    <span class="sidebar-normal"><?php echo e(__('Manage Roles')); ?></span>
                                </a>
                            </li>
                            <li class="nav-item ">
                                <a class="nav-link" href="<?php echo e(route('verifier.index')); ?>">
                                    <i class="tim-icons icon-check-2"></i>
                                    <span class="sidebar-normal"><?php echo e(__('Verifier')); ?></span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>
            <li class="nav-item">
                    <a class="nav-link" data-toggle="collapse" href="#ConversationExamples">
                        <i class="tim-icons icon-single-02" style="float: right"></i>
                        <p>
                            <?php echo e(__('Conversation View')); ?>

                            <b class="caret"></b>
                        </p>
                    </a>
                    <div class="collapse " id="ConversationExamples">
                        <ul class="nav">
                            <li class="nav-item ">
                                <a class="nav-link" href="<?php echo e(route('conversation_view.index')); ?>">
                                    <i class="tim-icons icon-single-02"></i>
                                    <span class="sidebar-normal"> <?php echo e(__('Conversation View')); ?></span>
                                </a>
                            </li>
                        </ul>
                    </div>
            </li>
            <li class="nav-item">
                    <a class="nav-link" data-toggle="collapse" href="#ClientExamples">
                        <i class="tim-icons icon-single-02" style="float: right"></i>
                        <p>
                            <?php echo e(__('Client')); ?>

                            <b class="caret"></b>
                        </p>
                    </a>
                    <div class="collapse " id="ClientExamples">
                        <ul class="nav">
                            <li class="nav-item ">
                                <a class="nav-link" href="<?php echo e(route('client.index')); ?>">
                                    <i class="tim-icons icon-single-02"></i>
                                    <span class="sidebar-normal"> <?php echo e(__('Client')); ?></span>
                                </a>
                            </li>
                        </ul>
                    </div>
            </li>
            <li class="nav-item">
                    <a class="nav-link" data-toggle="collapse" href="#ClientExamples">
                        <i class="tim-icons icon-single-02" style="float: right"></i>
                        <p>
                            <?php echo e(__('Setting')); ?>

                            <b class="caret"></b>
                        </p>
                    </a>
                    <div class="collapse " id="ClientExamples">
                        <ul class="nav">
                            <li class="nav-item ">
                                <a class="nav-link" href="<?php echo e(route('level.index')); ?>">
                                    <i class="tim-icons icon-single-02"></i>
                                    <span class="sidebar-normal"> <?php echo e(__('HNT Level')); ?></span>
                                </a>
                            </li>
                        </ul>
                    </div>
            </li>
        </ul>
        <!-- End of Sidebar -->
        <?php endif; ?>
        <?php if(auth()->check() && auth()->user()->hasRole('order')): ?>
        <!-- Sidebar -->
        <ul class="nav">
            <li class="nav-item ">
                <a class="nav-link" href="<?php echo e(route('home')); ?>">
                    <i class="tim-icons icon-chart-pie-36" style="float: right"></i>
                    <p><?php echo e(__('Dashboard')); ?></p>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link collapsed" data-toggle="collapse" href="#componentsExamples" aria-expanded="false">
                    <i class="tim-icons icon-coins" style="float: right"></i>
                    <p>
                        <?php echo e(__('Order')); ?>

                        <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse" id="componentsExamples" style="">
                    <ul class="nav">
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('order.index')); ?>">
                                <i class="tim-icons icon-coins"></i>
                                <span class="sidebar-normal"> <?php echo e(__('Order')); ?></span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="collapse" href="#HelpDeskExamples">
                    <i class="tim-icons icon-headphones" style="float: right"></i>
                    <p>
                        <?php echo e(__('Help Desk')); ?>

                        <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse " id="HelpDeskExamples">
                    <ul class="nav">
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('help_desk.index')); ?>">
                                <i class="tim-icons icon-headphones"></i>
                                <span class="sidebar-normal"> <?php echo e(__('Help Desk')); ?></span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="nav-item">
                    <a class="nav-link" data-toggle="collapse" href="#UsersExamples">
                        <i class="tim-icons icon-user-run" style="float: right"></i>
                        <p>
                            <?php echo e(__('Users')); ?>

                            <b class="caret"></b>
                        </p>
                    </a>
                    <div class="collapse " id="UsersExamples">
                        <ul class="nav">
                            <li class="nav-item ">
                                <a class="nav-link" href="<?php echo e(route('users.index')); ?>">
                                    <i class="tim-icons icon-paper"></i>
                                    <span class="sidebar-normal"><?php echo e(__('Manage Users')); ?></span>
                                </a>
                            </li>

                        </ul>
                    </div>
                </li>
            <li class="nav-item">
                    <a class="nav-link" data-toggle="collapse" href="#ClientExamples">
                        <i class="tim-icons icon-single-02" style="float: right"></i>
                        <p>
                            <?php echo e(__('Client')); ?>

                            <b class="caret"></b>
                        </p>
                    </a>
                    <div class="collapse " id="ClientExamples">
                        <ul class="nav">
                            <li class="nav-item ">
                                <a class="nav-link" href="<?php echo e(route('client.index')); ?>">
                                    <i class="tim-icons icon-single-02"></i>
                                    <span class="sidebar-normal"> <?php echo e(__('Client')); ?></span>
                                </a>
                            </li>
                        </ul>
                    </div>
            </li>
        </ul>
        <!-- End of Sidebar -->
        <?php endif; ?>
        <?php if(auth()->check() && auth()->user()->hasRole('finance')): ?>
        <!-- Sidebar -->
        <ul class="nav">
            <li class="nav-item ">
                <a class="nav-link" href="<?php echo e(route('home')); ?>">
                    <i class="tim-icons icon-chart-pie-36" style="float: right"></i>
                    <p><?php echo e(__('Dashboard')); ?></p>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="collapse" href="#formsExamples">
                    <i class="tim-icons icon-coins" style="float: right"></i>
                    <p>
                        <?php echo e(__('Agreement')); ?>

                        <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse " id="formsExamples">
                    <ul class="nav">
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('agreement.index')); ?>">
                                <i class="tim-icons icon-coins"></i>
                                <span class="sidebar-normal"
                                ><?php echo e(__('Agreement Management')); ?></span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="collapse" href="#tablesExamples">
                    <i class="tim-icons icon-coins" style="float: right"></i>
                    <p>
                        <?php echo e(__('Finance')); ?>

                        <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse " id="tablesExamples">
                    <ul class="nav">
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('finance.index')); ?>">
                                <i class="tim-icons icon-coins"></i>
                                <span class="sidebar-normal"><?php echo e(__('Finance Product')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('fund.index')); ?>">
                                <i class="tim-icons icon-coins"></i>
                                <span class="sidebar-normal">
                                    <?php echo e(__('Fund')); ?>

                                </span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('finance.index')); ?>">
                                <i class="tim-icons icon-coins"></i>
                                <span class="sidebar-normal"> <?php echo e(__('Debit')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('finance.index')); ?>">
                                <i class="tim-icons icon-coins"></i>
                                <span class="sidebar-normal"> <?php echo e(__('Revenue')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('finance.index')); ?>">
                                <i class="tim-icons icon-coins"></i>
                                <span class="sidebar-normal"> <?php echo e(__('Costs')); ?></span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="collapse" href="#HelpDeskExamples">
                    <i class="tim-icons icon-headphones" style="float: right"></i>
                    <p>
                        <?php echo e(__('Help Desk')); ?>

                        <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse " id="HelpDeskExamples">
                    <ul class="nav">
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('help_desk.index')); ?>">
                                <i class="tim-icons icon-headphones"></i>
                                <span class="sidebar-normal"> <?php echo e(__('Help Desk')); ?></span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="collapse" href="#UsersExamples">
                    <i class="tim-icons icon-user-run" style="float: right"></i>
                    <p>
                        <?php echo e(__('Users')); ?>

                        <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse " id="UsersExamples">
                    <ul class="nav">
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('users.index')); ?>">
                                <i class="tim-icons icon-paper"></i>
                                <span class="sidebar-normal"><?php echo e(__('Manage Users')); ?></span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="collapse" href="#ConversationExamples">
                    <i class="tim-icons icon-single-02" style="float: right"></i>
                    <p>
                        <?php echo e(__('Conversation View')); ?>

                        <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse " id="ConversationExamples">
                    <ul class="nav">
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('conversation_view.index')); ?>">
                                <i class="tim-icons icon-single-02"></i>
                                <span class="sidebar-normal"> <?php echo e(__('Conversation View')); ?></span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
        </ul>
        <!-- End of Sidebar -->
        <?php endif; ?>
        <?php if(auth()->check() && auth()->user()->hasRole('dealership')): ?>
        <!-- Sidebar -->
        <ul class="nav">
            <li class="nav-item ">
                <a class="nav-link" href="<?php echo e(route('home')); ?>">
                    <i class="tim-icons icon-chart-pie-36" style="float: right"></i>
                    <p><?php echo e(__('Dashboard')); ?></p>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link collapsed" data-toggle="collapse" href="#componentsExamples" aria-expanded="false">
                    <i class="tim-icons icon-coins" style="float: right"></i>
                    <p>
                        <?php echo e(__('Order')); ?>

                        <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse" id="componentsExamples" style="">
                    <ul class="nav">
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('order.index')); ?>">
                                <i class="tim-icons icon-coins"></i>
                                <span class="sidebar-normal"> <?php echo e(__('Order')); ?></span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="collapse" href="#HelpDeskExamples">
                    <i class="tim-icons icon-headphones" style="float: right"></i>
                    <p>
                        <?php echo e(__('Help Desk')); ?>

                        <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse " id="HelpDeskExamples">
                    <ul class="nav">
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('help_desk.index')); ?>">
                                <i class="tim-icons icon-headphones"></i>
                                <span class="sidebar-normal"> <?php echo e(__('Help Desk')); ?></span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="nav-item">
                    <a class="nav-link" data-toggle="collapse" href="#UsersExamples">
                        <i class="tim-icons icon-user-run" style="float: right"></i>
                        <p>
                            <?php echo e(__('Users')); ?>

                            <b class="caret"></b>
                        </p>
                    </a>
                    <div class="collapse " id="UsersExamples">
                        <ul class="nav">
                            <li class="nav-item ">
                                <a class="nav-link" href="<?php echo e(route('users.index')); ?>">
                                    <i class="tim-icons icon-paper"></i>
                                    <span class="sidebar-normal"><?php echo e(__('Manage Users')); ?></span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>
            <li class="nav-item">
                    <a class="nav-link" data-toggle="collapse" href="#ConversationExamples">
                        <i class="tim-icons icon-single-02" style="float: right"></i>
                        <p>
                            <?php echo e(__('Conversation View')); ?>

                            <b class="caret"></b>
                        </p>
                    </a>
                    <div class="collapse " id="ConversationExamples">
                        <ul class="nav">
                            <li class="nav-item ">
                                <a class="nav-link" href="<?php echo e(route('conversation_view.index')); ?>">
                                    <i class="tim-icons icon-single-02"></i>
                                    <span class="sidebar-normal"> <?php echo e(__('Conversation View')); ?></span>
                                </a>
                            </li>
                        </ul>
                    </div>
            </li>
            <li class="nav-item">
                    <a class="nav-link" data-toggle="collapse" href="#ClientExamples">
                        <i class="tim-icons icon-single-02" style="float: right"></i>
                        <p>
                            <?php echo e(__('Client')); ?>

                            <b class="caret"></b>
                        </p>
                    </a>
                    <div class="collapse " id="ClientExamples">
                        <ul class="nav">
                            <li class="nav-item ">
                                <a class="nav-link" href="<?php echo e(route('client.index')); ?>">
                                    <i class="tim-icons icon-single-02"></i>
                                    <span class="sidebar-normal"> <?php echo e(__('Client')); ?></span>
                                </a>
                            </li>
                        </ul>
                    </div>
            </li>
        </ul>
        <!-- End of Sidebar -->
        <?php endif; ?>
        <?php if(auth()->check() && auth()->user()->hasRole('repository')): ?>
        <!-- Sidebar -->
        <ul class="nav">
            <li class="nav-item ">
                <a class="nav-link" href="<?php echo e(route('home')); ?>">
                    <i class="tim-icons icon-chart-pie-36" style="float: right"></i>
                    <p><?php echo e(__('Dashboard')); ?></p>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="collapse" href="#ProductExamples" aria-expanded="true">
                    <i class="tim-icons icon-app" style="float: right"></i>
                    <p>
                        <?php echo e(__('Product')); ?>

                        <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse show" id="ProductExamples" style="">
                    <ul class="nav">
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('repository_requirement.index')); ?>">
                                <i class="tim-icons icon-bullet-list-67"></i>
                                <span class="sidebar-normal"
                                ><?php echo e(__('Product Requirement')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(Route('product.index')); ?>">
                                <i class="tim-icons icon-app" style="size: 8px"></i>
                                <span class="sidebar-normal"><?php echo e(__('Product')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('repository-part.index')); ?>">
                                <i class="tim-icons icon-paper"></i>
                                <span class="sidebar-normal"><?php echo e(__('Part Repository')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('part.index')); ?>">
                                <i class="tim-icons icon-settings-gear-63"></i>
                                <span class="sidebar-normal"><?php echo e(__('Parts')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('product_part.index')); ?>">
                                <i class="tim-icons icon-settings-gear-63"></i>
                                <span class="sidebar-normal"><?php echo e(__('Product Parts')); ?></span>
                            </a>
                        </li>


                    </ul>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="collapse" href="#RepositoryExamples">
                    <i class="tim-icons icon-wallet-43" style="float: right"></i>
                    <p>
                        <?php echo e(__('Repository')); ?>

                        <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse " id="RepositoryExamples">
                    <ul class="nav">
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(Route('repository.index')); ?>">
                                <i class="tim-icons icon-paper"></i> <span
                                        class="sidebar-normal"> <?php echo e(__('Repository')); ?></span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="collapse" href="#HelpDeskExamples">
                    <i class="tim-icons icon-headphones" style="float: right"></i>
                    <p>
                        <?php echo e(__('Help Desk')); ?>

                        <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse " id="HelpDeskExamples">
                    <ul class="nav">
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('help_desk.index')); ?>">
                                <i class="tim-icons icon-headphones"></i>
                                <span class="sidebar-normal"> <?php echo e(__('Help Desk')); ?></span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="nav-item">
                    <a class="nav-link" data-toggle="collapse" href="#UsersExamples">
                        <i class="tim-icons icon-user-run" style="float: right"></i>
                        <p>
                            <?php echo e(__('Users')); ?>

                            <b class="caret"></b>
                        </p>
                    </a>
                    <div class="collapse " id="UsersExamples">
                        <ul class="nav">
                            <li class="nav-item ">
                                <a class="nav-link" href="<?php echo e(route('users.index')); ?>">
                                    <i class="tim-icons icon-paper"></i>
                                    <span class="sidebar-normal"><?php echo e(__('Manage Users')); ?></span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>
            
                    
                        
                        
                            
                            
                        
                    
                    
                        
                            
                                
                                    
                                    
                                
                            
                        
                    
            
        </ul>
        <!-- End of Sidebar -->
        <?php endif; ?>
        <?php if(auth()->check() && auth()->user()->hasRole('product')): ?>
        <!-- Sidebar -->
        <ul class="nav">
            <li class="nav-item ">
                <a class="nav-link" href="<?php echo e(route('home')); ?>">
                    <i class="tim-icons icon-chart-pie-36" style="float: right"></i>
                    <p><?php echo e(__('Dashboard')); ?></p>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="collapse" href="#ProductExamples" aria-expanded="true">
                    <i class="tim-icons icon-app" style="float: right"></i>
                    <p>
                        <?php echo e(__('Product')); ?>

                        <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse show" id="ProductExamples" style="">
                    <ul class="nav">
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('repository_requirement.index')); ?>">
                                <i class="tim-icons icon-bullet-list-67"></i>
                                <span class="sidebar-normal"
                                ><?php echo e(__('Product Requirement')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(Route('product.index')); ?>">
                                <i class="tim-icons icon-app" style="size: 8px"></i>
                                <span class="sidebar-normal"><?php echo e(__('Product')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('repository-part.index')); ?>">
                                <i class="tim-icons icon-paper"></i>
                                <span class="sidebar-normal"><?php echo e(__('Part Repository')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('part.index')); ?>">
                                <i class="tim-icons icon-settings-gear-63"></i>
                                <span class="sidebar-normal"><?php echo e(__('Parts')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('product_part.index')); ?>">
                                <i class="tim-icons icon-settings-gear-63"></i>
                                <span class="sidebar-normal"><?php echo e(__('Product Parts')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('provider.index')); ?>">
                                <i class="tim-icons icon-single-02"></i>
                                <span class="sidebar-normal"><?php echo e(__('Provider')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('product-color.index')); ?>">
                                <i class="tim-icons icon-single-02"></i>
                                <span class="sidebar-normal"><?php echo e(__('Product Color')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('product-property.index')); ?>">
                                <i class="tim-icons icon-single-02"></i>
                                <span class="sidebar-normal"><?php echo e(__('Product Property')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('product-property-items.index')); ?>">
                                <i class="tim-icons icon-single-02"></i>
                                <span class="sidebar-normal"><?php echo e(__('Product Property Items')); ?></span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="collapse" href="#HelpDeskExamples">
                    <i class="tim-icons icon-headphones" style="float: right"></i>
                    <p>
                        <?php echo e(__('Help Desk')); ?>

                        <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse " id="HelpDeskExamples">
                    <ul class="nav">
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('help_desk.index')); ?>">
                                <i class="tim-icons icon-headphones"></i>
                                <span class="sidebar-normal"> <?php echo e(__('Help Desk')); ?></span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="nav-item">
                    <a class="nav-link" data-toggle="collapse" href="#UsersExamples">
                        <i class="tim-icons icon-user-run" style="float: right"></i>
                        <p>
                            <?php echo e(__('Users')); ?>

                            <b class="caret"></b>
                        </p>
                    </a>
                    <div class="collapse " id="UsersExamples">
                        <ul class="nav">
                            <li class="nav-item ">
                                <a class="nav-link" href="<?php echo e(route('users.index')); ?>">
                                    <i class="tim-icons icon-paper"></i>
                                    <span class="sidebar-normal"><?php echo e(__('Manage Users')); ?></span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="collapse" href="#RepositoryExamples">
                    <i class="tim-icons icon-wallet-43" style="float: right"></i>
                    <p>
                        <?php echo e(__('Repository')); ?>

                        <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse " id="RepositoryExamples">
                    <ul class="nav">
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(Route('repository.index')); ?>">
                                <i class="tim-icons icon-paper"></i> <span
                                        class="sidebar-normal"> <?php echo e(__('Repository')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('repository_create.index')); ?>">
                                <i class="tim-icons icon-wallet-43"></i>
                                <span class="sidebar-normal"><?php echo e(__('Repository Management')); ?></span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            
                    
                        
                        
                            
                            
                        
                    
                    
                        
                            
                                
                                    
                                    
                                
                            
                        
                    
            
        </ul>
        <!-- End of Sidebar -->
        <?php endif; ?>

        <?php if(auth()->check() && auth()->user()->hasRole('geust')): ?>
        <!-- Sidebar -->
        <ul class="nav">
            <li class="nav-item ">
                <a class="nav-link" href="<?php echo e(route('home')); ?>">
                    <i class="tim-icons icon-chart-pie-36" style="float: right"></i>
                    <p><?php echo e(__('Dashboard')); ?></p>
                </a>
            </li>
                <a class="nav-link" data-toggle="collapse" href="#UsersExamples">
                    <i class="tim-icons icon-user-run" style="float: right"></i>
                    <p>
                        <?php echo e(__('Users')); ?>

                        <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse " id="UsersExamples">
                    <ul class="nav">
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('users.index')); ?>">
                                <i class="tim-icons icon-paper"></i>
                                <span class="sidebar-normal"><?php echo e(__('Manage Users')); ?></span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="collapse" href="#ConversationExamples">
                    <i class="tim-icons icon-single-02" style="float: right"></i>
                    <p>
                        <?php echo e(__('Conversation View')); ?>

                        <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse " id="ConversationExamples">
                    <ul class="nav">
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('conversation_view.index')); ?>">
                                <i class="tim-icons icon-single-02"></i>
                                <span class="sidebar-normal"> <?php echo e(__('Conversation View')); ?></span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="nav-item">
        </ul>
        <!-- End of Sidebar -->
        <?php endif; ?>
    </div>
</div>



