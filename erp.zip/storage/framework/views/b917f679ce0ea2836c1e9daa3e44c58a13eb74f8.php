<?php $__env->startSection('title',__('Order')); ?>

<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <!------ Include the above in your HEAD tag ---------->
    <div class="content">
        <div class="container-fluid">
            <div class="card">
                <div class="card-body">
                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                            <table class="table table-condensed">
                                                <thead>
                                                <tr>
                                                    <td class="text-left"><h4
                                                                style="margin-top:30px;"><?php echo e(__('Date:')); ?> <?php echo e($data_dis->hop_due_date); ?></h4>
                                                    </td>
                                                    <td class="text-center"><h1
                                                                style="margin-top:70px; margin-right: 150px ; margin-left: 150px"><?php echo e(__('Pre Invoice Sales Of Product')); ?></h1>
                                                    </td>
                                                    <td><img align="right" width="170" height="170"
                                                             src="<?php echo e(asset('assets/images/g.png')); ?>">
                                                    </td>

                                                </tr>
                                                </thead>
                                            </table>
                                        </div>
                                        <div class="panel-body">
                                            <div class="table-responsive">
                                                <table class="table table-condensed">
                                                    <thead>
                                                    <th class="text-center"><strong><?php echo e(__('Owner profile')); ?>

                                                            &nbsp;<?php echo e($order->ho_client); ?>

                                                            &nbsp;<?php echo e($order->hp_phone_number); ?></strong></th>
                                                    <th class="text-center"><?php echo e(__('Employer Name:')); ?>

                                                        &nbsp;<?php echo e($order->hp_employer_name); ?></th>
                                                    <th class="text-center"><?php echo e(__('Project Name:')); ?>

                                                        &nbsp;<?php echo e($order->hp_project_name); ?></th>
                                                    <th class="text-center">&nbsp;<?php echo e(__('Type Project:')); ?>

                                                        &nbsp;<?php echo e($order->hp_type_project); ?></th>
                                                    <th class="text-center">
                                                        <?php echo e(__('Address:')); ?>

                                                        &nbsp;<?php echo e($state->hp_project_state); ?><?php echo e($city->hp_city); ?>

                                                        &nbsp;<?php echo e($order->hp_address); ?>

                                                    </th>
                                                    <th class="text-center">
                                                        &nbsp;<?php echo e(__('Create By:')); ?>&nbsp;<?php echo e($order->hp_registrant); ?>

                                                    </th>
                                                    </thead>
                                                    <thead>
                                                    <th class="text-center"><strong><?php echo e(__('Row')); ?></strong></th>
                                                    <th class="text-center"><strong><?php echo e(__('Product Name')); ?></strong></th>
                                                    <th class="text-center">
                                                        <strong><?php echo e(__('Description of Product')); ?></strong></th>
                                                    <th class="text-center"><strong><?php echo e(__('Price')); ?></strong></th>
                                                    <th class="text-center"><strong><?php echo e(__('Quantity')); ?></strong></th>
                                                    <th class="text-center"><strong><?php echo e(__('Sub Total')); ?></strong></th>
                                                    </thead>
                                                    <tbody>
                                                    <!-- foreach ($order->lineItems as $line) or some such thing here -->

                                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_loop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($products->id == $data_loop->hpo_product_id): ?>
                                                                <tr>
                                                                    <td class="text-center"><?php echo e($key + 1); ?></td>
                                                                    <td class="text-center"><?php echo e($products->hp_product_name . $products->hp_product_model . $products->hp_product_color_id . $products->hp_product_size . $products->hp_product_property . $products->hp_product_code_number); ?></td>
                                                                    <td class="text-center"><?php echo e($data_loop->hpo_count); ?></td>
                                                                    <td class="text-center"><?php echo e($products->hp_product_price); ?></td>
                                                                    <td class="text-center"><?php echo e($data_loop->hpo_description); ?></td>
                                                                    <td class="text-center"><?php echo e($data_loop->hpo_total); ?></td>
                                                                </tr>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <td class="thick-line"></td>
                                                    </tbody>
                                                    <table>
                                                        <tr>
                                                            <th class="no-line"></th>
                                                            <th class="no-line"></th>
                                                            <th class="no-line">
                                                                <strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo e(__('Totals')); ?></strong>&nbsp;<?php echo e($data_dis->hpo_total); ?>

                                                            </th>

                                                        </tr>
                                                        <tr>
                                                            <th class="no-line"></th>
                                                            <th class="no-line"></th>
                                                            <th class="no-line">
                                                                <strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo e(__('Discount')); ?>

                                                                    %&nbsp;</strong><?php echo e($data_dis->hpo_discount); ?>&nbsp;&nbsp;
                                                            </th>
                                                        </tr>
                                                        <tr>
                                                            <th class="no-line"></th>
                                                            <th class="no-line"></th>
                                                            <th class="no-line">
                                                                <strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo e(__('Total including discount:')); ?>

                                                                    &nbsp;</strong><?php echo e($data_dis->hpo_total_discount); ?>

                                                            </th>
                                                        </tr>
                                                    </table>
                                                </table>
                                            </div>
                                            <?php if($current_verified_order === null): ?>
                                                <form method="POST" action="<?php echo e(route('verify_pre.update',$order->id)); ?>"
                                                      ENCTYPE="multipart/form-data">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('PUT'); ?>
                                                    <button class="btn btn-primary"><?php echo e(__('send')); ?></button>
                                                </form>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>