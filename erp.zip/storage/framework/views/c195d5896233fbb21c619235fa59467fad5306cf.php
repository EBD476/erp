<script type="text/javascript">
    $(function() {
        $('[data-toggle="tooltip"]').tooltip();
    });
</script>