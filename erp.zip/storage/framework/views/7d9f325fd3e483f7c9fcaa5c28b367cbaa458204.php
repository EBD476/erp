<?php $__env->startSection('title',__('Request')); ?>

<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap.min.css">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <a href="<?php echo e(route('request.create')); ?>" class="btn btn-primary float-left mb-lg-2"><i class="tim-icons icon-simple-add"></i><?php echo e(__('Add New Request')); ?></a>
                </div>
                <div class="col-md-9">
                    <div class="card">
                        <div class="card-header card-header-primary">
                            <h4 class="card-title "><?php echo e(__('Request')); ?></h4>
                            <p class="card-category"></p>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="table" class="table" cellspacing="0" width="100%">
                                    <thead class=" text-primary">
                                    <th>
                                        <?php echo e(__('Row')); ?>

                                    </th>
                                    <th>
                                        <?php echo e(__('Product')); ?>

                                    </th>
                                    <th>
                                        <?php echo e(__('Product Count')); ?>

                                    </th>
                                    <th>
                                        <?php echo e(__('User ID')); ?>

                                    </th>
                                    <th>
                                        <?php echo e(__('Request Date')); ?>

                                    </th>
                                    <th>
                                        <?php echo e(__('Accept Level')); ?>

                                    </th>
                                    <th>
                                        <?php echo e(__('action')); ?>

                                    </th>
                                    </thead>
                                    <tbody>

                                    <?php $__currentLoopData = $Request; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $Request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <?php echo e($key + 1); ?>

                                            </td>
                                            <td>
                                                <?php echo e($Request -> goods); ?>

                                            </td>
                                            <td>
                                                <?php echo e($Request -> goods_count); ?>

                                            </td>
                                            <td>
                                                <?php echo e($Request->user_id); ?>

                                            </td>
                                            <td>
                                                <?php echo e($Request -> request_date); ?>

                                            </td>
                                            <td>
                                                <?php echo e($Request -> accept_level); ?>

                                            </td>
                                            <td>
                                                <div class="dropdown">
                                                    <button type="button"
                                                            class="btn btn-link dropdown-toggle btn-icon"
                                                            data-toggle="dropdown">
                                                        <i class="tim-icons icon-settings-gear-63"></i>
                                                    </button>
                                                    <div class="dropdown-menu dropdown-menu-right"
                                                         aria-labelledby="dropdownMenuLink">
                                                        <a class="dropdown-item"
                                                           href="<?php echo e(route('request.edit',$Request->id)); ?>"
                                                        ><?php echo e(__('Edit')); ?></a>
                                                        <form id="-form-delete<?php echo e($Request->id); ?>"
                                                              style="display: none;" method="POST"
                                                              action="<?php echo e(route('request.destroy',$Request->id)); ?>">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                        </form>
                                                        <a class="dropdown-item"
                                                           onclick="if(confirm('آیا از حذف این پروژه اطمینان دارید؟')){
                                                                   event.preventDefault();
                                                                   document.getElementById('-form-delete<?php echo e($Request->id); ?>').submit();
                                                                   }else {
                                                                   event.preventDefault();}"><?php echo e(__('Delete')); ?></a>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <br><br>
                    <div class="card card-user">
                        <div class="card-body">
                            <p class="card-text">
                                <div class="author">
                                    <div class="block block-one"></div>
                                    <div class="block block-two"></div>
                                    <div class="block block-three"></div>
                                    <div class="block block-four"></div>
                                    <a href="javascript:void(0)">
                                        
                                        <h5 class="title">Hanta IBMS</h5>
                                    </a>
                            <p class="description">

                            </p>
                        </div>
                        </p>
                        <div class="card-description">

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
        <?php $__env->stopSection(); ?>

        <?php $__env->startPush('scripts'); ?>
            <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
            <script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap.min.js"></script>
            <script>
                $(document).ready(function() {
                    $('#table').DataTable({
                        "language": {
                            "sEmptyTable":     "هیچ داده ای در جدول وجود ندارد",
                            "sInfo":           "نمایش _START_ تا _END_ از _TOTAL_ رکورد",
                            "sInfoEmpty":      "نمایش 0 تا 0 از 0 رکورد",
                            "sInfoFiltered":   "(فیلتر شده از _MAX_ رکورد)",
                            "sInfoPostFix":    "",
                            "sInfoThousands":  ",",
                            "sLengthMenu":     "نمایش _MENU_ رکورد",
                            "sLoadingRecords": "در حال بارگزاری...",
                            "sProcessing":     "در حال پردازش...",
                            "sSearch":         "جستجو:",
                            "sZeroRecords":    "رکوردی با این مشخصات پیدا نشد",
                            "oPaginate": {
                                "sFirst":    "ابتدا",
                                "sLast":     "انتها",
                                "sNext":     "بعدی",
                                "sPrevious": "قبلی"
                            },
                            "oAria": {
                                "sSortAscending":  ": فعال سازی نمایش به صورت صعودی",
                                "sSortDescending": ": فعال سازی نمایش به صورت نزولی"
                            }
                        }
                    } );
                });
            </script>
    <?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>