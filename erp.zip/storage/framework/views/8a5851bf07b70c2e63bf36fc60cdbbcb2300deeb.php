<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('assets/js/core/jquery.min.js')); ?> "></script>
    <script src="<?php echo e(asset('assets/js/core/bootstrap.min.js')); ?> "></script>
    <script src="<?php echo e(asset('assets/js/jquery.nicescroll.min.js')); ?>" type="text/javascript" ></script>

    <!-- Styles -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,600,700,800" rel="stylesheet" />
    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">

    <link href="<?php echo e(asset('assets/css/nucleo-icons.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/style.min.css')); ?>" rel="stylesheet">


</head>
<body class="white-content">

<div class="wrapper container-fluid">

    <?php echo $__env->yieldContent('content'); ?>


</div>



</body>
</html>