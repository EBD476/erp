<?php $__env->startSection('title',__('Order')); ?>

<?php $__env->startPush('css'); ?>
    <link href="<?php echo e(asset('assets/css/select2.min.css')); ?>" rel="stylesheet"/>
    <link href="<?php echo e(asset('assets/css/select2-bootstrap4.min.css')); ?>" rel="stylesheet"/>
    <link href="<?php echo e(asset('assets/css/leaflet.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/kamadatepicker.min.css')); ?>" rel="stylesheet"/>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin')): ?>
    <div class="content persian">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <?php echo $__env->make('layouts.partial.Msg', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>

                <div class="card">
                    <div class="card-header card-header-primary">
                        <h4 class="card-title "><?php echo e(__('Edit Order')); ?>&nbsp;<?php echo e($project->hp_employer_name); ?></h4>
                        <p class="card-category"></p>
                        <div class="row pull-left">
                            <div class="col-md-12 pull-left">
                                <div class="form-group">
                                    <label class="bmd-label-floating"><?php echo e(__('Order ID:')); ?></label>
                                    <label class="bmd-label-floating" id="order_id_show" data-id="<?php echo e($project->id); ?>"
                                           data-client="<?php echo e($project->ho_client); ?>"><?php echo e($project->id); ?></label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <ul class="nav nav-pills" style="float: none">
                            <li class="nav-item" style="width: 33.3333%;">
                                <a class="nav-link active" href="#tab1" data-toggle="tab" role="tab">
                                    <?php echo e(__('Order')); ?>

                                </a>
                            </li>
                            <li class="nav-item" style="width: 33.3333%;">
                                <a class="nav-link" href="#tab2" data-toggle="tab" role="tab">
                                    <?php echo e(__('List of Material')); ?>

                                </a>
                            </li>
                        </ul>
                        <br>
                        <div class="tab-content">
                            <div role="tabpanel" class="tab-pane active" id="tab1">
                                <form id="form1">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label class="bmd-label-floating"><?php echo e(__('Project Name')); ?></label>
                                                <input type="text" class="form-control" required=""
                                                       aria-invalid="false" name="hp_project_name" id="hp_project_name"
                                                       data-id="<?php echo e($project->id); ?>" value="<?php echo e($project->hp_project_name); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label class="bmd-label-floating"><?php echo e(__('Employer Name')); ?></label>
                                                <input type="text" class="form-control" required="" aria-invalid="false"
                                                       name="hp_employer_name" id="hp_employer_name"
                                                       value="<?php echo e($project->hp_employer_name); ?>">
                                            </div>

                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label class="bmd-label-floating"><?php echo e(__('Client Name')); ?></label>
                                                <select class="form-control" name="ho_client" id="ho_client">
                                                    <?php $__currentLoopData = $client; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client_select): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($client_select->id == $project->ho_client): ?>
                                                            <option><?php echo e($client_select->hc_name); ?></option>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php $__currentLoopData = $client; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clients): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($clients->id); ?>"><?php echo e($clients->hc_name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <div class="text-light">
                                                    <a class="pointer" href="#" data-toggle="modal"
                                                       data-target="#modalRegisterForm">
                                                        <?php echo e(__('Add New Client')); ?></a>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label class="bmd-label-floating"><?php echo e(__('Connector')); ?></label>
                                                <input type="text" class="form-control" required=""
                                                       aria-invalid="false"
                                                       name="hp_connector" id="hp_connector"
                                                       value="<?php echo e($project->hp_connector); ?>">
                                            </div>

                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label class="bmd-label-floating"><?php echo e(__('Owner User')); ?></label>
                                                <select type="text" class="form-control" name="hp_owner_user"
                                                        id="hp_owner_user">
                                                    <option><?php echo e($project->hp_owner_user); ?></option>
                                                    <option><?php echo e(__('Residential')); ?></option>
                                                    <option><?php echo e(__('Commercial')); ?></option>
                                                    <option><?php echo e(__('edari')); ?></option>
                                                </select>

                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label class="bmd-label-floating"><?php echo e(__('Phone Number')); ?></label>
                                                <input type="number" class="form-control" required=""
                                                       aria-invalid="false"
                                                       name="hp_phone_number" id="hp_phone_number"
                                                       value="<?php echo e($project->hp_phone_number); ?>">
                                            </div>

                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label class="bmd-label-floating"><?php echo e(__('Project Area')); ?></label>
                                                <input type="number" class="form-control" required=""
                                                       aria-invalid="false"
                                                       name="hp_project_area" id="hp_project_area"
                                                       value="<?php echo e($project->hp_project_area); ?>">
                                            </div>

                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label class="bmd-label-floating"><?php echo e(__('Number Of Units')); ?></label>
                                                <input type="number" class="form-control" required=""
                                                       aria-invalid="false"
                                                       name="hp_number_of_units" id="hp_number_of_units"
                                                       value="<?php echo e($project->hp_number_of_units); ?>">
                                            </div>

                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label class="bmd-label-floating"><?php echo e(__('Type Project')); ?></label>
                                                <select class="form-control" name="hp_type_project"
                                                        id="hp_type_project">
                                                    <option><?php echo e($project->hp_type_project); ?></option>
                                                    <?php $__currentLoopData = $project_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type_project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option><?php echo e($type_project->hp_name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label class="bmd-label-floating"><?php echo e(__('Contract Type')); ?></label>
                                                <select class="form-control" type="text"
                                                        name="hp_contract_type" id="hp_contract_type">
                                                    <option>
                                                        <?php echo e($project->hp_contract_type); ?>

                                                    </option>
                                                    <option>
                                                        <?php echo e(__('Delivery')); ?>

                                                    </option>
                                                    <option>
                                                        <?php echo e(__('Install In Place')); ?>

                                                    </option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label class="bmd-label-floating"><?php echo e(__('State')); ?></label>
                                                <select class="form-control" type="text"
                                                        name="hp_address_state_id" id="hp_address_state_id">
                                                    <option><?php echo e($project->hp_address_state_id); ?></option>
                                                    <?php $__currentLoopData = $state; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($code->id); ?>">
                                                            <?php echo e($code->hp_project_state); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label class="bmd-label-floating"><?php echo e(__('City')); ?></label>
                                                <select class="form-control" type="text"
                                                        name="hp_address_city_id" id="hp_address_city_id">
                                                    <option><?php echo e($project->hp_address_city_id); ?></option>
                                                    <?php $__currentLoopData = $address; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($city->id); ?>">
                                                            <?php echo e($city->hp_city); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="bmd-label-floating"><?php echo e(__('Project Location')); ?></label>
                                                <div id="map"
                                                     style="width: 100%; height: 300px;direction: ltr;z-index:0"></div>
                                                <input name="hp_project_location" type="hidden"
                                                       id="location" class="form-control">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="bmd-label-floating"><?php echo e(__('Address')); ?></label>
                                                <textarea type="text" class="form-control" id="hp_address"
                                                          name="hp_address" required=""
                                                          aria-invalid="false"
                                                ><?php echo e($project->hp_address); ?></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <button type="submit" class="btn badge-primary"><?php echo e(__('Send')); ?></button>
                                </form>
                            </div>

                            <div role="tabpanel" class="tab-pane" id="tab2" data-lang="<?php echo e(app()->getLocale()); ?>">
                                <form id="form2">
                                    <table class="table invoice-table product-table" style="direction: rtl" id="table2">
                                        <thead>
                                        <tr>
                                            <th style="min-width:32px;" class="hide-border"></th>
                                            <th style="min-width:120px;width:25%"><?php echo e(__('Item')); ?></th>
                                            <th style="width:100%"><?php echo e(__('Description')); ?></th>
                                            <th style="min-width:120px"><?php echo e(__('Unit Cost')); ?></th>
                                            <th style="min-width:120px;display:table-cell"><?php echo e(__('Quantity')); ?></th>
                                            <th style="min-width:120px;display:none"><?php echo e(__('Discount')); ?></th>
                                            <th style="min-width:120px;display:none;"
                                                data-bind="visible: $root.invoice_item_taxes.show">Tax
                                            </th>
                                            <th style="min-width:120px;"><?php echo e(__('Line Total')); ?></th>
                                            <th style="min-width:32px;" class="hide-border"></th>
                                        </tr>
                                        </thead>
                                        <tbody data-bind="sortable: { data: invoice_items_without_tasks, allowDrop: false, afterMove: onDragged} "
                                               class="ui-sortable">
                                        <div hidden><?php echo e($index = 0); ?></div>
                                        <?php $__currentLoopData = $invoices_item ->name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $invoices_items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <input type="hidden" value="<?php echo e($key + 1); ?>">
                                                <input name="pid[]" value="<?php echo e($invoices_item->name[$index]); ?>"
                                                       type="hidden">
                                                <tr data-bind="event: { mouseover: showActions, mouseout: hideActions }"
                                                    class="sortable-row ui-sortable-handle" style="">
                                                    <td class="hide-border td-icon">
                                                        <i style="display:none" class="fa fa-sort"></i>
                                                    </td>
                                                    <td>
                                                        <select name="name[]"
                                                                class="select-item combobox-container name"
                                                                data-id="<?php echo e($invoices_item->name[$index]); ?>">
                                                            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product_selected): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if($product_selected->id == $invoices_item->hpo_product_id[$index]): ?>
                                                                    <option value="<?php echo e($product_selected->id); ?>"><?php echo e($product_selected->hp_product_name); ?></option>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($product_item->id); ?>"
                                                                        data-price="<?php echo e($product_item->hp_product_price); ?>">
                                                                    <?php echo e($product_item->hp_product_name . $product_item->hp_product_model . $product_item->hp_product_size); ?>

                                                                    <?php $__currentLoopData = $color; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $colors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php if($colors->id == $product_item->hp_product_color_id): ?>
                                                                            <?php echo e($colors->hn_color_name); ?>

                                                                        <?php endif; ?>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php if($property->id== $product_item->hp_product_property): ?>
                                                                            <?php echo e($property->hpp_property_name); ?>

                                                                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <?php if($item->id == $property->hpp_property_items): ?>
                                                                                    <?php echo e($item->hppi_items_name); ?>

                                                                                <?php endif; ?>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php endif; ?>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </td>
                                                    <td>
                                                <textarea
                                                        data-bind="value: notes, valueUpdate: 'afterkeydown', attr: {name: 'invoice_items[]'}"
                                                        rows="1" cols="60" style="resize: vertical; height: 42px;"
                                                        class="form-control word-wrap invoice_items"
                                                        name="invoice_items[]"><?php echo e($invoices_item->invoice_items[$index]); ?></textarea>
                                                    </td>
                                                    <td>
                                                        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product_item_price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($invoices_item->name[$index] == $product_item_price->id): ?>
                                                                <input disabled type="text"
                                                                       class="form-control unit"
                                                                       name="hp_product_price[]"
                                                                       value="<?php echo e($product_item_price->hp_product_price); ?>">
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </td>
                                                    <td style="display:table-cell">
                                                        <input
                                                                style="text-align: right"
                                                                class="form-control invoice_items qty"
                                                                name="invoice_items_qty[]"
                                                                value="<?php echo e($invoices_item->invoice_items_qty[$index]); ?>">
                                                    </td>
                                                    <td style="text-align:right;padding-top:9px !important" nowrap="">
                                                        <div class="line-total sub-total"
                                                             name="total[]"><?php echo e($invoices_item->total[$index]); ?></div>
                                                        <input name="total[]" class="sub-total" type="hidden"
                                                               value="<?php echo e($invoices_item->total[$index]); ?>">
                                                    </td>
                                                    <td style="cursor:pointer" class="hide-border td-icon">
                                                        <i class="tim-icons icon-simple-remove remove"
                                                           title="Remove item"/>
                                                    </td>
                                                  <div hidden ><?php echo e($index++); ?></div>
                                                </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                        <tbody data-bind="sortable: { data: invoice_items_without_tasks, allowDrop: false, afterMove: onDragged} "
                                               class="ui-sortable">

                                        <tr data-bind="event: { mouseover: showActions, mouseout: hideActions }"
                                            class="sortable-row ui-sortable-handle" style="">
                                            <td class="hide-border td-icon">
                                                <i style="display:none" data-bind="visible: actionsVisible() &amp;&amp;
                $parent.invoice_items_without_tasks().length > 1" class="fa fa-sort"></i>
                                            </td>
                                            <td>
                                                <select name="name[]" class="select-item combobox-container">
                                                    <option value=""></option>
                                                    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option id="name" value="<?php echo e($product_item->id); ?>"
                                                                data-price="<?php echo e($product_item->hp_product_price); ?>">
                                                            <?php echo e($product_item->hp_product_name . $product_item->hp_product_model . $product_item->hp_product_size); ?>

                                                            <?php $__currentLoopData = $color; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $colors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if($colors->id == $product_item->hp_product_color_id): ?>
                                                                    <?php echo e($colors->hn_color_name); ?>

                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if($property->id== $product_item->hp_product_property): ?>
                                                                    <?php echo e($property->hpp_property_name); ?>

                                                                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php if($item->id == $property->hpp_property_items): ?>
                                                                            <?php echo e($item->hppi_items_name); ?>

                                                                        <?php endif; ?>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>

                                            </td>
                                            <td>
                                                <textarea
                                                        data-bind="value: notes, valueUpdate: 'afterkeydown', attr: {name: 'invoice_items[]'}"
                                                        rows="1" cols="60" style="resize: vertical; height: 42px;"
                                                        class="form-control word-wrap"
                                                        name="invoice_items[]"></textarea>
                                            </td>
                                            <td>
                                                <input disabled type="text" class="form-control unit"
                                                       name="hp_product_price[]">
                                                <input name="price" id="price" type="hidden">
                                            </td>
                                            <td style="display:table-cell">
                                                <input
                                                        style="text-align: right" class="form-control invoice-item qty"
                                                        name="invoice_items_qty[]">
                                            </td>
                                            <td style="text-align:right;padding-top:9px !important" nowrap="">
                                                <div class="line-total sub-total" name="total[]"></div>
                                                <input name="total[]" class="sub-total" type="hidden">
                                            </td>
                                            <td style="cursor:pointer" class="hide-border td-icon">
                                                <i class="tim-icons icon-simple-remove remove" title="Remove item"/>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                    
                                    <div class="col-md-6">
                                        <div class="card">
                                            <div class="card-body">
                                                <div class="row">
                                                    <label class="bmd-label-floating"><?php echo e(__('Discount')); ?>

                                                        :</label>
                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            <div class="col-lg-6 col-sm-6">
                                                                <div class="input-group"><input class="form-control"
                                                                                                id="discount"
                                                                                                type="number"
                                                                                                name="hpo_discount"
                                                                                                value="<?php echo e($invoices_item->hpo_discount); ?>">
                                                                    &nbsp
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <label class="bmd-label-floating"><?php echo e(__('Paid to Date:')); ?></label>
                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            <div class="col-lg-6 col-sm-6">
                                                                <input class="form-control"
                                                                       id="test-date-id"
                                                                       type="text"
                                                                       name="hop_due_date"
                                                                       value="<?php echo e($invoices_item->hop_due_date); ?>"
                                                                >
                                                                &nbsp
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <label class="bmd-label-floating"><?php echo e(__('Total:')); ?></label>
                                                    <div class="col-md-12 ">
                                                        <div class="form-group">
                                                            <div class="form-group">
                                                                <div class="col-lg-6 col-sm-6">
                                                                    <input disabled class="form-control"
                                                                           id="all_total"
                                                                           type="text"
                                                                           name="all_total"
                                                                           value="<?php echo e($invoices_item->all_tot); ?>"
                                                                    >
                                                                    &nbsp
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <label class="bmd-label-floating"><?php echo e(__('Total Including Discount:')); ?></label>
                                                    <div class="col-md-12 ">
                                                        <div class="form-group">
                                                            <div class="form-group">
                                                                <div class="col-lg-6 col-sm-6">
                                                                    <input disabled class="form-control"
                                                                           id="total_discount"
                                                                           type="text"
                                                                           name="total_discount"
                                                                           value="<?php echo e($invoices_item->all_dis); ?>"
                                                                    >
                                                                    &nbsp
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                                                <div class="row">
                                                    <label class="bmd-label-floating"><?php echo e(__('Statuses:')); ?></label>
                                                    <div class="col-md-12 ">
                                                        <div class="col-lg-6 col-sm-6">
                                                            <div class="form-group">

                                                                <select name="hpo_status" class="form-control">
                                                                    <?php $__currentLoopData = $invoice_statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice_status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option>
                                                                            <?php echo e($invoice_status->name); ?>

                                                                        </option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    

                                    
                                    <input type="hidden" id="client_id" name="hpo_client_id"
                                           value="<?php echo e($project->ho_client); ?>">
                                    <input type="hidden" id="order_id" name="hpo_order_id" value="<?php echo e($project->id); ?>">
                                    <input id="all_dis" name="all_dis" type="hidden"
                                           value="<?php echo e($invoices_item->hpo_total_discount); ?>">
                                    <input id="all_tot" name="all_tot" type="hidden"
                                           value="<?php echo e($invoices_item->hpo_total_all); ?>">
                                    
                                    <div class="col-md-12">
                                        <a href="<?php echo e(route('order.index')); ?>"
                                           class="btn btn-primary"><?php echo e(__('Back')); ?></a>
                                        <button id="btn_submit_form2" type="submit"
                                                class="btn btn-primary"><?php echo e(__('Send')); ?></button>
                                        
                                                
                                    </div>
                                </form>
                            </div>
                        </div>
                        
                        <div class="modal fade" id="modalRegisterForm" tabindex="-1" role="dialog"
                             aria-labelledby="myModalLabel"
                             aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header text-center">
                                        <h4 class="modal-title w-100 font-weight-bold"><?php echo e(__('Add New Client')); ?></h4>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <form method="post" id="modal_form" enctype="multipart/form-data">
                                        <div class="modal-body mx-3">
                                            <div class="md-form mb-5">
                                                
                                                <label class="bmd-label-floating" data-error="wrong"
                                                       data-success="right"
                                                       for="orangeForm-name"><?php echo e(__('Name')); ?></label>
                                                <input type="text" id="orangeForm-name" class="form-control validate"
                                                       name="hc_name">
                                            </div>
                                            <div class="md-form mb-5">
                                                
                                                <label class="bmd-label-floating" data-error="wrong"
                                                       data-success="right"><?php echo e(__('Phone')); ?></label>
                                                <input type="number" required class="form-control validate"
                                                       name="hc_phone">
                                            </div>

                                            <div class="md-form mb-4">
                                                
                                                <label class="bmd-label-floating" data-error="wrong"
                                                       data-success="right"><?php echo e(__('Address')); ?></label>
                                                <input type="text" class="form-control validate" name="hc_address">
                                            </div>

                                        </div>
                                        <div class="modal-footer d-flex justify-content-center">
                                            <button type="submit" class="btn btn-deep-orange"><?php echo e(__('Send')); ?></button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        
                    </div>

                </div>

            </div>
        </div>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('assets/js/select2.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('assets/js/plugins/jquery.blockUI.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('assets/js/leaflet.js')); ?>"></script>
    <script>
        var total;
        var discount;
        var total_discount;
        var remove = 0;

        $(document).ready(function () {
            var client_id;
            var order_id;

            $("#modal_form").submit(function (event) {
                var data = $("#modal_form").serialize();
                event.preventDefault();
                $.blockUI();
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.blockUI({
                    message: '<?php echo e(__('please wait...')); ?>', css: {
                        border: 'none',
                        padding: '15px',
                        backgroundColor: '#000',
                        '-webkit-border-radius': '10px',
                        '-moz-border-radius': '10px',
                        opacity: .5,
                        color: '#fff'
                    }
                });
                $.ajax({
                    url: '/client',
                    type: 'POST',
                    data: data,
                    dataType: 'json',
                    async: false,
                    success: function (data) {
                        setTimeout($.unblockUI);
                        $("#modalRegisterForm").find("input").val("");
                        $("#modalRegisterForm").modal('hide');
                        $("#client_name").append('<option selected>' + data.client_name + '</option>');
                    },
                    cache: false,
                });
            });

            $("#form1").submit(function (event) {
                var data = {
                    id: $("#hp_project_name").data('id'),
                    hp_project_name: $("#hp_project_name").val(),
                    hp_employer_name: $("#hp_employer_name").val(),
                    ho_client: $("#ho_client").val(),
                    hp_connector: $("#hp_connector").val(),
                    hp_owner_user: $("#hp_owner_user").val(),
                    hp_phone_number: $("#hp_phone_number").val(),
                    hp_project_area: $("#hp_project_area").val(),
                    hp_number_of_units: $("#hp_number_of_units").val(),
                    hp_type_project: $("#hp_type_project").val(),
                    hp_contract_type: $("#hp_contract_type").val(),
                    hp_address_state_id: $("#hp_address_state_id").val(),
                    hp_address_city_id: $("#hp_address_city_id").val(),
                    hp_address: $("#hp_address").val(),
                }
                event.preventDefault();
                $.blockUI({
                    message: '<?php echo e(__('please wait...')); ?>', css: {
                        border: 'none',
                        padding: '15px',
                        backgroundColor: '#000',
                        '-webkit-border-radius': '10px',
                        '-moz-border-radius': '10px',
                        opacity: .5,
                        color: '#fff'
                    }
                });
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });

                $.ajax({
                    url: '/order/' + data.id,
                    type: 'POST',
                    data: data,
                    method: 'put',
                    dataType: 'json',
                    async: false,
                    success: function (data) {
                        setTimeout($.unblockUI, 2000);
                        client_id = data.client_id;
                        order_id = data.order_id;
                        $("#order_id").val(order_id);
                        $("#client_id").val(client_id);
                        $("#order_id_show").text(order_id);
                    },
                    cache: false,
                });
            });

            $("#btn_submit_form2").on('click', function (event) {
                var data = $("#form2").serialize();
                var pid = $("#pid").val();
                event.preventDefault();
                $.blockUI({
                    message: '<?php echo e(__('please wait...')); ?>', css: {
                        border: 'none',
                        padding: '15px',
                        backgroundColor: '#000',
                        '-webkit-border-radius': '10px',
                        '-moz-border-radius': '10px',
                        opacity: .5,
                        color: '#fff'
                    }
                });
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });

                $.ajax({
                    url: '/order_product',
                    type: 'POST',
                    data: data,
                    dataType: 'json',
                    async: false,
                    success: function (data) {
                        setTimeout($.unblockUI, 2000);
                        window.location.href = "/order";
                    },
                    cache: false,
                });
            });

            var locale = $("#tab2").data('lang');

            $(".select-item").select2({
                theme: "bootstrap",
                placeholder: (locale == 'fa' ? 'انتخاب محصول' : 'Select Product'),
                // allowClear: true

            });

            $(".select-item").on('change', function (event) {

                $(".unit").val($(this).find("option[value='" + $(this).val() + "']").data('price'));
                unit_count = $(".unit").val();
                unit_qty = $(".qty").val();
                $(this).parent().parent().find("div[name='total[]']").text(unit_count * unit_qty);
                $(this).parent().parent().find("input[name='total[]']").val(unit_count * unit_qty);
                var all_total_val = $("#all_total").val()

                $('.sub-total').each(function () {

                    total = $(this).text();
                    if (total != "") {
                        $("#all_total").val(parseInt(total) + parseInt(all_total_val));
                        $("#all_total").text(parseInt(total) + parseInt(all_total_val));
                        $("#all_tot").val(parseInt(total) + parseInt(all_total_val));

                    }

                });

                $(".qty").on('change', function (event) {
                    unit_count = $(this).parent().parent().find("input[name='hp_product_price[]']").val();
                    unit_qty = $(this).val();
                    $(this).parent().parent().find("div[name='total[]']").text(unit_count * unit_qty);
                    $(this).parent().parent().find("input[name='total[]']").val(unit_count * unit_qty);
                    discount = $("#discount").val();
                    total = $("#all_total").val();
                    if (discount != "") {
                        total_discount = parseInt(discount) * parseInt(total) / 100;
                        $("#all_dis").val(parseInt(total) - parseInt(total_discount))
                        $("#total_discount").val(parseInt(total) - parseInt(total_discount))
                        $("#total_discount").text(parseInt(total) - parseInt(total_discount))
                    }
                    total = 0;
                    $('.sub-total').each(function () {

                        current = $(this).text();
                        if (current != "") {
                            total = total + parseInt(current);
                            $("#all_total").val(total);
                            $("#all_total").text(total);
                        }
                    });

                });

                $("#discount").on('change', function (event) {
                    total = $('#all_total').val();
                    discount = $(this).val();
                    total_discount = parseInt(discount) * parseInt(total) / 100;
                    $('#all_dis').val(parseInt(total) - parseInt(total_discount));
                    $('#total_discount').val(parseInt(total) - parseInt(total_discount));
                    $('#total_discount').text(parseInt(total) - parseInt(total_discount));
                })


                append_item();

                function append_item() {

                    $('.table').append('<tr data-bind="event: { mouseover: showActions, mouseout: hideActions }"\n' +
                        '                                        class="sortable-row ui-sortable-handle" style="">\n' +
                        '                                        <td class="hide-border td-icon">\n' +
                        '                                            <i style="display:none" data-bind="visible: actionsVisible() &amp;&amp;\n' +
                        '                $parent.invoice_items_without_tasks().length > 1" class="fa fa-sort"></i>\n' +
                        '                                        </td>\n' +
                        '                                        <td>\n' +
                        '                                                       <select name="name[]" class="select-item combobox-container">\n' +
                        '                                                            <option value=""></option>' +
                        '                                                            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>\n' +
                        '                                                                <option value="<?php echo e($product_item->id); ?>" data-price="<?php echo e($product_item->hp_product_price); ?>">\n' +
                        '                                                                    <?php echo e($product_item->hp_product_name); ?>\n' +


                        '                                                            <?php $__currentLoopData = $color; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $colors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> \n' +
                        '                                                            <?php if($colors->id == $product_item->hp_product_color_id): ?> \n' +
                        '                                                            <?php echo e($colors->hn_color_name); ?> \n' +
                        '                                                            <?php endif; ?> \n' +
                        '                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> \n' +
                        '                                                            <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> \n' +
                        '                                                            <?php if($property->id== $product_item->hp_product_property): ?> \n' +
                        '                                                            <?php echo e($property->hpp_property_name); ?> \n' +
                        '                                                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>\n' +
                        '                                                            <?php if($item->id == $property->hpp_property_items): ?> \n' +
                        '                                                            <?php echo e($item->hppi_items_name); ?> \n' +
                        '                                                            <?php endif; ?> \n' +
                        '                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> \n' +
                        '                                                            <?php endif; ?> \n' +
                        '                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> \n' +
                        '                                                                </option>\n' +
                        '                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>\n' +
                        '                                                        </select>\n' +
                        '\n' +
                        '                                        </td>\n' +
                        '                                        <td>\n' +
                        '                                                <textarea\n' +
                        '                                                        data-bind="value: notes, valueUpdate: \'afterkeydown\', attr: {name: \'invoice_items[]\'}"\n' +
                        '                                                        rows="1" cols="60" style="resize: vertical; height: 42px;"\n' +
                        '                                                        class="form-control word-wrap"\n' +
                        '                                                        name="invoice_items[]"></textarea>\n' +
                        '\n' +
                        '                                        </td>\n' +
                        '                                        <td>\n' +
                        '                                            <input disabled type="text"  class="form-control unit"\n' +
                        '                                                   name="hp_product_price[]">\n' +
                        '                                        </td>\n' +
                        '                                        <td style="display:table-cell">\n' +
                        '                                            <input \n' +
                        '                                                   style="text-align: right" class="form-control invoice-item qty"\n' +
                        '                                                   name="invoice_items_qty[]">\n' +
                        '                                        </td>\n' +
                        '                                        <td style="text-align:right;padding-top:9px !important" nowrap="">\n' +
                        '                                            <div name="total[]" class="line-total sub-total"></div>\n' +
                        '                                            <input name="total[]"class="sub-total" type="hidden">\n' +
                        '                                        </td>\n' +
                        '                                        <td style="cursor:pointer" class="hide-border td-icon">\n' +
                        '                                            <i \n' +
                        '                                               \n' +
                        '                                               class="tim-icons icon-simple-remove remove"  title="Remove item">\n' +
                        '                                            </i></td>\n' +
                        '                                    </tr>'
                    )
                    ;

                    var locale = $("#tab2").data('lang');

                    $(".select-item").select2({
                        theme: "bootstrap",
                        placeholder: (locale == 'fa' ? 'انتخاب محصول' : 'Select Product'),
                    });

                    $(".select-item").on('change', function (event) {

                        $(this).parent().parent().find("input[name='hp_product_price[]']").val($(this).find("option[value='" + $(this).val() + "']").data('price'));
                        $(this).parent().parent().find("input[name='invoice_items_qty[]']").val('1');


                        unit_count = $(this).parent().parent().find("input[name='hp_product_price[]']").val();
                        unit_qty = $(this).parent().parent().find("input[name='invoice_items_qty[]']").val();
                        $(this).parent().parent().find("div[name='total[]']").text(unit_count * unit_qty);
                        $(this).parent().parent().find("input[name='total[]']").val(unit_count * unit_qty);

                        total = 0;
                        $('.sub-total').each(function () {

                            current = $(this).text();
                            if (current != "") {
                                total = total + parseInt(current);
                                $("#all_tot").val(total);
                                $("#all_total").val(total);
                                $("#all_total").text(total);
                                if ($('#discount').val() != "") {
                                    total1 = $('#all_total').val();
                                    discount = $('#discount').val();
                                    total_discount = parseInt(discount) * parseInt(total1) / 100;
                                    $('#all_dis').val(parseInt(total1) - parseInt(total_discount));
                                    $('#total_discount').val(parseInt(total1) - parseInt(total_discount));
                                    $('#total_discount').text(parseInt(total1) - parseInt(total_discount));
                                }
                            }
                        });

                        $(".qty").on('change', function (event) {

                            unit_count = $(this).parent().parent().find("input[name='hp_product_price[]']").val();
                            unit_qty = $(this).val();
                            $(this).parent().parent().find("div[name='total[]']").text(unit_count * unit_qty);
                            $(this).parent().parent().find("input[name='total[]']").val(unit_count * unit_qty);
                            discount = $("#discount").val();
                            total = $("#all_total").val();
                            if (discount != "") {
                                total_discount = parseInt(discount) * parseInt(total) / 100;
                                $("#all_dis").val(parseInt(total) - parseInt(total_discount))
                                $("#total_discount").val(parseInt(total) - parseInt(total_discount))
                                $("#total_discount").text(parseInt(total) - parseInt(total_discount))
                            }
                            total = 0;
                            $('.sub-total').each(function () {

                                current = $(this).text();
                                if (current != "") {
                                    total = total + parseInt(current);
                                    $("#all_tot").val(total);
                                    $("#all_total").val(total);
                                    $("#all_total").text(total);
                                }
                            });

                        });

                        $("#discount").on('change', function (event) {
                            discount = $(this).val();
                            total_discount = parseInt(discount) * parseInt(total) / 100;
                            $('#all_dis').val(parseInt(total) - parseInt(total_discount));
                            $('#total_discount').val(parseInt(total) - parseInt(total_discount));
                            $('#total_discount').text(parseInt(total) - parseInt(total_discount));
                        });

                        $(".remove").click(function () {


                            var rowCount = $('#table2 tr').length;

                            if (rowCount > 2) {

                                if ($(this).parent().parent().find('.sub-total').text() != "") {
                                    all = $("#all_total").val();
                                    total = all - parseInt($(this).parent().parent().find('.sub-total').text());
                                    $('#all_total').val(total);
                                    $('#all_tot').val(total);
                                    if ($('#discount').val != "") {
                                        total1 = $('#all_total').val();
                                        discount = $('#discount').val();
                                        total_discount = parseInt(discount) * parseInt(total1) / 100;
                                        $('#total_dis').val(parseInt(total1) - parseInt(total_discount));
                                        $('#total_discount').val(parseInt(total1) - parseInt(total_discount));
                                        $('#total_discount').text(parseInt(total1) - parseInt(total_discount));
                                    }
                                }


                                if (remove == 0) {

                                    total = all - parseInt($(this).parent().parent().find('.sub-total').text());
                                    $("#all_tot").val(total);
                                    $("#all_total").val(total);
                                    remove += 1;

                                }

                                $(this).parent().parent().remove();
                                remove = 0;

                            }
                        });

                        append_item();
                    });

                }

                var data = {
                    name: $(this).parent().parent().find('#name').val(),
                    total: $(this).parent().parent().find('.sub-total').text(),
                    hpo_order_id: $("#order_id").val(),
                    hpo_client_id: $("#order_id_show").data('client'),
                    hop_due_date: $("#test-date-id").val(),
                    hpo_discount: $("#discount").val(),
                    all_tot: $("#all_total").val(),
                    all_dis: $("#total_discount").val(),
                }
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });

                $.ajax({
                    url: '/order_product',
                    type: 'Post',
                    data: data,
                    dataType: 'json',
                    async: false,
                    success: function (data) {
                    },
                    cache: false,
                });


            })

            $("#discount").on('change', function (event) {
                total = $('#all_total').val();
                discount = $(this).val();
                total_discount = parseInt(discount) * parseInt(total) / 100;
                $('#all_dis').val(parseInt(total) - parseInt(total_discount));
                $('#total_discount').val(parseInt(total) - parseInt(total_discount));
                $('#total_discount').text(parseInt(total) - parseInt(total_discount));
            })

            $(".qty").on('change', function (event) {
                unit_count = $(this).parent().parent().find("input[name='hp_product_price[]']").val();
                unit_qty = $(this).val();
                $(this).parent().parent().find("div[name='total[]']").text(unit_count * unit_qty);
                $(this).parent().parent().find("input[name='total[]']").val(unit_count * unit_qty);
                discount = $("#discount").val();
                total = $("#all_total").val();
                if (discount != "") {
                    total_discount = parseInt(discount) * parseInt(total) / 100;
                    $("#all_dis").val(parseInt(total) - parseInt(total_discount))
                    $("#total_discount").val(parseInt(total) - parseInt(total_discount))
                    $("#total_discount").text(parseInt(total) - parseInt(total_discount))
                }
                total = 0;
                $('.sub-total').each(function () {

                    current = $(this).text();
                    if (current != "") {
                        total = total + parseInt(current);
                        $("#all_total").val(total);
                        $("#all_tot").val(total);
                        $("#all_total").text(total);
                    }

                    discount = $("#discount").val();
                    var total_a = $("#all_total").val();
                    if (discount != "") {
                        total_discount = parseInt(discount) * parseInt(total_a) / 100;
                        $("#all_dis").val(parseInt(total_a) - parseInt(total_discount))
                        $("#total_discount").val(parseInt(total_a) - parseInt(total_discount))
                        $("#total_discount").text(parseInt(total_a) - parseInt(total_discount))
                    }
                });

            });

            $(".remove").click(function () {

                var rowCount = $('#table2 tr').length;

                if (rowCount > 2) {

                    if ($(this).parent().parent().find('.sub-total').text() != "") {
                        all = $("#all_total").val();
                        total = all - parseInt($(this).parent().parent().find('.sub-total').text());
                        $('#all_total').val(total);
                        $('#all_tot').val(total);
                        if ($('#discount').val != "") {
                            total1 = $('#all_total').val();
                            discount = $('#discount').val();
                            total_discount = parseInt(discount) * parseInt(total1) / 100;
                            $('#total_dis').val(parseInt(total1) - parseInt(total_discount));
                            $('#total_discount').val(parseInt(total1) - parseInt(total_discount));
                            $('#total_discount').text(parseInt(total1) - parseInt(total_discount));
                        }
                    }


                    if (remove == 0) {

                        total = all - parseInt($(this).parent().parent().find('.sub-total').text());
                        $("#all_tot").val(total);
                        $("#all_total").val(total);
                        remove += 1;

                    }
                    var data = {
                        id: $(".name").data('id')
                    }
                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });

                    $.ajax({
                        url: '/order_product/' + data.id,
                        type: 'delete',
                        data: data,
                        dataType: 'json',
                        async: false,
                        success: function (data) {
                            window.location.href = "/order";
                            setTimeout($.unblockUI, 2000);
                        },
                        cache: false,
                    });
                    $(this).parent().parent().remove();
                    remove = 0;

                }
            });
        });

        $('#preview').on('click', function () {
            $('#form2').attr('action', '<?php echo e(route('order.preview')); ?>');
        })

    </script>
    
    <script src="<?php echo e(asset('assets/js/kamadatepicker.min.js')); ?>"></script>
    <script>
        kamaDatepicker('test-date-id', {
            buttonsColor: "blue",
            forceFarsiDigits: true,
            nextButtonIcon: "fa fa-arrow-circle-right",
            previousButtonIcon: "fa fa-arrow-circle-left"
        });
    </script>
    <script type="text/javascript">

        var loc;
        var greenIcon = L.icon({
            iconUrl: '../../assets/images/marker-icon-x48.png',
            shadowUrl: 'leaf-shadow.png',

            iconSize: [48, 48], // size of the icon
            shadowSize: [50, 64], // size of the shadow
            iconAnchor: [25, 44], // point of the icon which will correspond to marker's location
            shadowAnchor: [4, 62],  // the same for the shadow
            popupAnchor: [-3, -76] // point from which the popup should open relative to the iconAnchor
        });

        var map = L.map('map').setView([35.7736, 51.4631], 13);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map);

        L.marker([35.7736, 51.4631], {icon: greenIcon}).addTo(map)
            .bindPopup('<?php echo e($project->hp_address); ?>')
            .openPopup();

        function onMapClick(e) {
            ;

            var jsonLoc = JSON.parse(JSON.stringify(e.latlng));
            $("#location").val(jsonLoc.lat + ',' + jsonLoc.lng);

            if (loc != undefined) {
                loc.remove();
            }
            loc = L.marker([jsonLoc.lat, jsonLoc.lng], {icon: greenIcon}).addTo(map);
        }

        $("#remove").click(function () {
            loc.remove();
        });

        map.on('click', onMapClick);

    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>