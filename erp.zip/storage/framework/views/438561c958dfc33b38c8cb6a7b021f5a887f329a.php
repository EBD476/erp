<?php $__env->startSection('title', '| Roles'); ?>

<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap.min.css">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>


    <div class="wrap main-content persian" data-scrollbar>
        <div class="content">
            <a href="<?php echo e(route('users.index')); ?>" class="btn btn-primary pull-left"><i
                        class="tim-icons icon-simple-add"></i><?php echo e(__('Users')); ?></a>
            <a href="<?php echo e(route('permissions.index')); ?>" class="btn btn-primary pull-left"><i
                        class="tim-icons icon-simple-add"></i><?php echo e(__('Permissions')); ?></a>
            <a href="<?php echo e(URL::to('roles/create')); ?>" class="btn btn-primary pull-left"><i
                        class="tim-icons icon-simple-add"></i><?php echo e(__('Add Role')); ?></a>
            <div class="card">
                <div class="card-body">
                    <div class="col-lg-9">
                        <h3><i class="fa fa-key pull-right"><?php echo e(__('Roles')); ?></i></h3>
                        <hr>
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive" style="font-size: 13px;color: #65767c">
                                    <table id="table" class="table table-striped">
                                        <thead>
                                        <tr>
                                            <th><?php echo e(__('Role')); ?></th>
                                            <th><?php echo e(__('Permissions')); ?></th>
                                            <th><?php echo e(__('Operation')); ?></th>
                                        </tr>
                                        </thead>

                                        <tbody>
                                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>

                                                <td><?php echo e($role->name); ?></td>

                                                <td><?php echo e($role->permissions()->pluck('name')->implode(' ')); ?></td>
                                                <td>
                                                    <a href="<?php echo e(URL::to('roles/'.$role->id.'/edit')); ?>"
                                                       class="btn btn-link btn-warning btn-icon btn-sm btn-neutral  edit">
                                                        <i class="tim-icons icon-pencil"></i></a>

                                                    <form action="<?php echo e(route('roles.destroy', $role->id)); ?>" style="display: none;">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                    </form>
                                                    <a class="btn btn-link btn-danger btn-icon btn-sm btn-neutral remove"
                                                       onclick="if(confirm('آیا از حذف این نقش اطمینان دارید؟')){
                                                               event.preventDefault();
                                                               document.getElementById('-form-delete<?php echo e($role->id); ?>').submit();
                                                               }else {
                                                               event.preventDefault();}"><i
                                                                class="tim-icons icon-simple-remove"></i></a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>

                                    </table>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <br><br>
                        <div class="card card-user">
                            <div class="card-body">
                                <p class="card-text">
                                    <div class="author">
                                        <div class="block block-one"></div>
                                        <div class="block block-two"></div>
                                        <div class="block block-three"></div>
                                        <div class="block block-four"></div>
                                        <a href="javascript:void(0)">
                                            
                                            <h5 class="title">Hanta IBMS</h5>
                                        </a>
                                <p class="description">
                                    
                                </p>
                            </div>
                            </p>
                            <div class="card-description">

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#table').DataTable({
                "language": {
                    "sEmptyTable":     "هیچ داده ای در جدول وجود ندارد",
                    "sInfo":           "نمایش _START_ تا _END_ از _TOTAL_ رکورد",
                    "sInfoEmpty":      "نمایش 0 تا 0 از 0 رکورد",
                    "sInfoFiltered":   "(فیلتر شده از _MAX_ رکورد)",
                    "sInfoPostFix":    "",
                    "sInfoThousands":  ",",
                    "sLengthMenu":     "نمایش _MENU_ رکورد",
                    "sLoadingRecords": "در حال بارگزاری...",
                    "sProcessing":     "در حال پردازش...",
                    "sSearch":         "جستجو:",
                    "sZeroRecords":    "رکوردی با این مشخصات پیدا نشد",
                    "oPaginate": {
                        "sFirst":    "ابتدا",
                        "sLast":     "انتها",
                        "sNext":     "بعدی",
                        "sPrevious": "قبلی"
                    },
                    "oAria": {
                        "sSortAscending":  ": فعال سازی نمایش به صورت صعودی",
                        "sSortDescending": ": فعال سازی نمایش به صورت نزولی"
                    }
                }
            } );
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>