<?php $__env->startSection('title',__('Receiver Page')); ?>

<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <?php echo $__env->make('layouts.partial.Msg', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header card-header-primary">
                            <h4 class="card-title "><?php echo e(__('show Message')); ?></h4>
                            <p class="card-category"></p>
                        </div>
                        <div class="card-body">
                            <form>
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="bmd-label-floating"><?php echo e(__('Title')); ?></label>
                                            <input required="" type="text" name="hhd_title" class="form-control"
                                                   value="<?php echo e($help_desks->hhd_title); ?>" disabled>
                                        </div>

                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="bmd-label-floating"><?php echo e(__('Type')); ?> </label>
                                            <?php $__currentLoopData = $type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $types): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($types->id == $help_desks->hhd_type): ?>
                                                    <input class="form-control" name="hhd_ticket_status"
                                                           value="<?php echo e($types->th_name); ?>"
                                                           disabled>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>

                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="bmd-label-floating"><?php echo e(__('Ticket Status')); ?></label>
                                            <?php $__currentLoopData = $ticket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tickets): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($tickets->id == $help_desks->hhd_ticket_status): ?>
                                                    <input class="form-control" name="hhd_ticket_status"
                                                           value="<?php echo e($tickets->ts_name); ?>"
                                                           disabled>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>

                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="bmd-label-floating"><?php echo e(__('Receiver')); ?></label>
                                            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($users->id == $help_desks->hhd_receiver_user_id): ?>
                                                    <input class="form-control" value="<?php echo e($users->name); ?>" disabled>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>

                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="bmd-label-floating"><?php echo e(__('Priority')); ?></label>
                                            <?php $__currentLoopData = $priority; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $priorities_1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($priorities_1->id == $help_desks->hhd_priority): ?>
                                                    <input class="form-control" value="<?php echo e($priorities_1->hdp_name); ?>"
                                                           disabled>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>

                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="bmd-label-floating"><?php echo e(__('Description')); ?></label>
                                            <textarea type="text" required=""
                                                      aria-invalid="false" class="form-control"
                                                      name="hhd_problem"
                                                      disabled><?php echo e($help_desks->hhd_problem); ?></textarea>
                                        </div>

                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="bmd-label-floating"><?php echo e(__('Verify Ticket')); ?></label>
                                            <div class="form-check ">
                                                <label class="form-check-label">
                                                    <input class="form-check-input"
                                                           type="checkbox"
                                                           data-id="<?php echo e($help_desks->id); ?>"
                                                           id="checkbox"
                                                    >
                                                    <span class="form-check-sign">
                                                                <span class="check"></span>
                                                                </span>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>

                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card card-user">
                        <div class="card-body">
                            <p class="card-text">
                            <div class="author">
                                <div class="block block-one"></div>
                                <div class="block block-two"></div>
                                <div class="block block-three"></div>
                                <div class="block block-four"></div>
                                <a href="javascript:void(0)">
                                    
                                    <h5 class="title">Hanta IBMS</h5>
                                </a>
                            </div>
                            </p>
                            <div class="card-description">

                            </div>
                        </div>
                        <div class="card-footer">
                            <div class="button-container">
                                <button href="javascript:void(0)" class="btn btn-icon btn-round btn-facebook">
                                    <i class="fab fa-facebook"></i>
                                </button>
                                <button href="javascript:void(0)" class="btn btn-icon btn-round btn-twitter">
                                    <i class="fab fa-twitter"></i>
                                </button>
                                <button href="javascript:void(0)" class="btn btn-icon btn-round btn-google">
                                    <i class="fab fa-google-plus"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <?php $__env->stopSection(); ?>

        <?php $__env->startPush('scripts'); ?>
            <script src="<?php echo e(asset('assets/js/plugins/jquery.blockUI.js')); ?>" type="text/javascript"></script>
            <script>
                $(document).ready(function () {
                    $('#checkbox').on('change', function (event) {
                        if (event.target.checked) {
                            var data = {
                                id: $("#checkbox").data('id'),
                                state: $(this)[0].checked == true ? 3 : 2,
                            };
                            $.blockUI({
                                message: '<?php echo e(__('please wait...')); ?>', css: {
                                    border: 'none',
                                    padding: '15px',
                                    backgroundColor: '#000',
                                    '-webkit-border-radius': '10px',
                                    '-moz-border-radius': '10px',
                                    opacity: .5,
                                    color: '#fff'
                                }
                            });
                            //token
                            $.ajaxSetup({
                                headers: {
                                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                                }
                            });
                            $.ajax({
                                url: '/receive_verify/' + data.id,
                                type: 'POST',
                                data: data,
                                dataType: 'json',
                                async: false,
                                success: function (data) {
                                    setTimeout($.unblockUI, 2000);
                                },
                                cache: false,
                            });
                        }
                    });
                });
            </script>
    <?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>