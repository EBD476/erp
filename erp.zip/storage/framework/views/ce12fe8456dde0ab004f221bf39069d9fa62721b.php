<?php $__env->startSection('title',__('Product Requirement')); ?>

<?php $__env->startPush('css'); ?>
    <link href="<?php echo e(asset('assets/css/dataTables.bootstrap.min.css')); ?>" rel="stylesheet"/>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin')): ?>
    <div class="content persian">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <a href="<?php echo e(route('repository_requirement.create')); ?>" class="btn btn-primary float-left mb-lg-2"><i
                                class="tim-icons icon-simple-add"></i><?php echo e(__('Add New Repository')); ?></a>
                </div>
                <div class="col-md-9">
                    <div class="card">
                        <div class="card-header card-header-primary">
                            <h4 class="card-title "><?php echo e(__('Repository Requirement')); ?></h4>
                            <p class="card-category"></p>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="table" class="table" cellspacing="0" width="100%">
                                    <thead class=" text-primary">
                                    <th>
                                        <?php echo e(__('ID')); ?>

                                    </th>
                                    <th>
                                        <?php echo e(__('Product Id')); ?>

                                    </th>
                                    <th>
                                        <?php echo e(__('Product Count')); ?>

                                    </th>
                                    <th>
                                        <?php echo e(__('Comment')); ?>

                                    </th>
                                    <th>
                                        <?php echo e(__('Create At')); ?>

                                    </th>
                                    <th>
                                        <?php echo e(__('Update At')); ?>

                                    </th>
                                    <th>
                                        <?php echo e(__('action')); ?>

                                    </th>
                                    </thead>
                                    <tbody>

                                    <?php $__currentLoopData = $Repositories_Requirement; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $Repositories_Requirement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <?php echo e($key + 1); ?>

                                            </td>
                                            <td>
                                                <?php echo e($Repositories_Requirement -> Product_Id); ?>

                                            </td>
                                            <td>
                                                <?php echo e($Repositories_Requirement ->Product_Count); ?>

                                            </td>
                                            <td>
                                                <?php echo e($Repositories_Requirement -> Comment); ?>

                                            </td>
                                            <td>
                                                <?php echo e($Repositories_Requirement -> created_at); ?>

                                            </td>
                                            <td>
                                                <?php echo e($Repositories_Requirement -> updated_at); ?>

                                            </td>
                                            <td>
                                                <div class="dropdown">
                                                    <button type="button"
                                                            class="btn btn-link dropdown-toggle btn-icon"
                                                            data-toggle="dropdown">
                                                        <i class="tim-icons icon-settings-gear-63"></i>
                                                    </button>
                                                    <div class="dropdown-menu dropdown-menu-right"
                                                         aria-labelledby="dropdownMenuLink">
                                                        <a class="dropdown-item"
                                                           href="<?php echo e(route('repository_requirement.edit',$Repositories_Requirement->id)); ?>"
                                                        ><?php echo e(__('Edit')); ?></a>
                                                        <form id="-form-delete<?php echo e($Repositories_Requirement->id); ?>"
                                                              style="display: none;" method="POST"
                                                              action="<?php echo e(route('repository_requirement.destroy',$Repositories_Requirement->id)); ?>">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                        </form>
                                                        <a class="dropdown-item"
                                                           onclick="if(confirm('آیا از حذف این پروژه اطمینان دارید؟')){
                                                                   event.preventDefault();
                                                                   document.getElementById('-form-delete<?php echo e($Repositories_Requirement->id); ?>').submit();
                                                                   }else {
                                                                   event.preventDefault();}"><?php echo e(__('Delete')); ?></a>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <br><br>
                    <div class="card card-user">
                        <div class="card-body">
                            <p class="card-text">
                            <div class="author">
                                <div class="block block-one"></div>
                                <div class="block block-two"></div>
                                <div class="block block-three"></div>
                                <div class="block block-four"></div>
                                <a href="javascript:void(0)">
                                    
                                    <h5 class="title">Hanta IBMS</h5>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap.min.js"></script>
    <script src="<?php echo e(asset('assets/js/sweetalert.min.js')); ?>"></script>
    
        

            

            

                
                
                    
                        
                    
                
                
                    
                    
                    
                    
                    
                    
                
                    
                        
                            
                                
                                
                                
                                
                                
                                
                                    
                                        
                                        
                                    
                                
                                
                            
                            
                        
                            
                                
                                
                            

                        
                    
            
            
                

                    
                        
                    
                        
                    
                        
                    
                        
                            
                            
                            
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                        
                            
                            
                            
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                        
                    
                        
                            
                                
                            
                                
                            
                                
                            
                                
                            
                                
                            
                                
                            
                                
                            
                                
                            
                                
                            
                                
                            
                                
                            
                                
                                    
                                        
                                    
                                        
                                    
                                        
                                    
                                        
                                
                            
                            
                                
                                    
                                        
                                    
                                        
                                
                        
                
            
        
    
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>