<?php $__env->startSection('title',__('Invoices List')); ?>

<?php $__env->startPush('css'); ?>
    <link href="<?php echo e(asset('assets/css/dataTables.bootstrap.min.css')); ?>" rel="stylesheet"/>
    <link href="<?php echo e(asset('assets/css/switchery.min.css')); ?>" rel="stylesheet"/>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin||product')): ?>
    <div class="content persian">
        <div class="container-fluid">
            
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header card-header-primary">
                        <h4 class="card-title "><?php echo e(__('Order List')); ?></h4>
                        <p class="card-category"></p>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table" id="table1" cellspacing="0" width="100%">
                                <thead class=" text-primary">
                                <th>
                                    <?php echo e(__('ID')); ?>

                                </th>
                                <th>
                                    <?php echo e(__('Invoices Number')); ?>

                                </th>
                                <th>
                                    <?php echo e(__('Product Name')); ?>

                                </th>
                                <th>
                                    <?php echo e(__('Product Model')); ?>

                                </th>

                                <th>
                                    <?php echo e(__('Property Name')); ?>

                                </th>
                                <th>
                                    <?php echo e(__('Color')); ?>

                                </th>
                                <th>
                                    <?php echo e(__('Size')); ?>

                                </th>
                                <th>
                                    <?php echo e(__('Count')); ?>

                                </th>
                                <th>
                                    <?php echo e(__('Due Date')); ?>

                                </th>
                                <th>
                                    <?php echo e(__('Action')); ?>

                                </th>
                                </thead>
                                <tbody>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            

            
            <div class="col-md-12">
                <div class="row">
                    
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-header card-header-primary">
                                <h4 class="card-title "><?php echo e(__('inventory Repository Product')); ?></h4>
                                <p class="card-category"></p>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table" id="table2" cellspacing="0" width="100%">
                                        <thead class=" text-primary">
                                        <th>
                                            <?php echo e(__('ID')); ?>

                                        </th>
                                        <th>
                                            <?php echo e(__('Product Name')); ?>

                                        </th>
                                        <th>
                                            <?php echo e(__('Stock')); ?>

                                        </th>
                                        <th>
                                            <?php echo e(__('Repository')); ?>

                                        </th>
                                        </thead>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-header card-header-primary">
                                <h4 class="card-title "><?php echo e(__('Repository Middle Part List')); ?></h4>
                                <p class="card-category"></p>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table" id="table3" cellspacing="0" width="100%">
                                        <thead class=" text-primary">
                                        <th>
                                            <?php echo e(__('ID')); ?>

                                        </th>
                                        <th>
                                            <?php echo e(__('Name')); ?>

                                        </th>
                                        <th>
                                            <?php echo e(__('Stock')); ?>

                                        </th>
                                        <th>
                                            <?php echo e(__('Repository')); ?>

                                        </th>
                                        </thead>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    

                    
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-header card-header-primary">
                                <h4 class="card-title "><?php echo e(__('Repository Part List')); ?></h4>
                                <p class="card-category"></p>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive table-hover">
                                    <table id="table4" class="table" cellspacing="0" width="100%">
                                        <thead class=" text-primary">
                                        <th>
                                            <?php echo e(__('ID')); ?>

                                        </th>
                                        <th>
                                            <?php echo e(__('Name')); ?>

                                        </th>
                                        <th>
                                            <?php echo e(__('Stock')); ?>

                                        </th>
                                        <th>
                                            <?php echo e(__('Repository')); ?>

                                        </th>
                                        </thead>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
            

            
            <div class="row">
                <div class="col-lg-12">
                    <div class="card card-tasks">
                        
                        <div class="card-header ">
                            <div class="dropdown">
                                <h6 class="title d-inline"><?php echo e(__('Inventory Deficit')); ?></h6>
                                <button type="button" class="btn btn-link dropdown-toggle btn-icon"
                                        data-toggle="dropdown">
                                    <i class="tim-icons icon-settings-gear-63"></i>
                                </button>
                                <div class="dropdown-menu dropdown-menu-right"
                                     aria-labelledby="dropdownMenuLink">
                                    <a class="dropdown-item" href="#" data-toggle="modal"
                                       data-target="#modalRegisterForm"><?php echo e(__('Details')); ?></a>
                                    
                                    
                                </div>
                            </div>
                        </div>
                        

                        <div class="card-body ">
                            <div class="table-full-width table-responsive ps ps--active-y">
                                <table class="table" id="table5">
                                    <thead>
                                    <th><?php echo e(__('ID')); ?></th>
                                    <th><?php echo e(__('Invoices Number')); ?></th>
                                    <th><?php echo e(__('Product Name')); ?></th>
                                    <th><?php echo e(__('Count')); ?></th>
                                    <th><?php echo e(__('Inventory After Exit')); ?></th>
                                    <th><?php echo e(__('Start The Process')); ?></th>
                                    <th><?php echo e(__('Status Invoice')); ?></th>
                                    <th><?php echo e(__('Status Verify')); ?></th>
                                    </thead>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    </div>

    
    <div class="modal fade" id="modalRegisterForm" tabindex="-1" role="dialog"
         aria-labelledby="myModalLabel"
         aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content modal-content-landscape-in">
                <div class="modal-header text-center">
                    <h4 class="modal-title w-100 font-weight-bold"><?php echo e(__('View Details Data')); ?></h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form method="post" id="modal_form" enctype="multipart/form-data">
                    <div class="modal-body mx-3">
                        <div class="md-form mb-5">
                            
                            <table class="table" id="table6" cellspacing="0" width="100%">
                                <tbody>
                                <thead class=" text-primary">
                                <th>
                                    <?php echo e(__('ID')); ?>

                                </th>
                                <th>
                                    <?php echo e(__('Product Name')); ?>

                                </th>
                                <th>
                                    <?php echo e(__('Count')); ?>

                                </th>
                                <th>
                                    <?php echo e(__('Inventory Deficit')); ?>

                                </th>
                                </thead>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="modal-footer d-flex justify-content-center">
                            <button type="submit"
                                    class="btn btn-deep-orange" form="modal_form"
                                    value="Submit"><?php echo e(__('Request Send')); ?></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    

    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap.min.js"></script>
    <script src="<?php echo e(asset('assets/js/plugins/jquery.blockUI.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('assets/js/switchery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/sweetalert.min.js')); ?>"></script>
    <script>
        $(document).ready(function () {

            var elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));

            $('#table1').DataTable({
                "processing":
                    true,
                "serverSide":
                    true,
                "ajax":
                    '/json-data-order-product',
                "columnDefs":
                    [{
                        "targets": -1,
                        "data": null,

                        "render": function (data, type, row, meta) {
                            return "  <div class=\"dropdown\">\n" +
                                "                                                            <a class=\"btn btn-link dropdown-toggle btn-icon\"\n" +
                                "                                                                    data-toggle=\"dropdown\">\n" +
                                "                                                                <i class=\"tim-icons icon-settings-gear-63\"></i>\n" +
                                "                                                            </a>\n" +
                                "                                                            <div class=\"dropdown-menu dropdown-menu-right\"\n" +
                                "                                                                 aria-labelledby=\"dropdownMenuLink\">\n" +
                                "                                                               <a  href=\"verify_pre/" + data[9] + "/edit\" class=\"dropdown-item\"\n" +
                                "                                                                ><?php echo e(__('Preview Invoice')); ?></a>\n" +
                                "                                                            </div>\n" +
                                "                                                        </div>"
                        }
                    }],
                "language":
                    {
                        "sEmptyTable":
                            "هیچ داده ای در جدول وجود ندارد",
                        "sInfo":
                            "نمایش _START_ تا _END_ از _TOTAL_ رکورد",
                        "sInfoEmpty":
                            "نمایش 0 تا 0 از 0 رکورد",
                        "sInfoFiltered":
                            "(فیلتر شده از _MAX_ رکورد)",
                        "sInfoPostFix":
                            "",
                        "sInfoThousands":
                            ",",
                        "sLengthMenu":
                            "نمایش _MENU_ رکورد",
                        "sLoadingRecords":
                            "در حال بارگزاری...",
                        "sProcessing":
                            "در حال پردازش...",
                        "sSearch":
                            "جستجو:",
                        "sZeroRecords":
                            "رکوردی با این مشخصات پیدا نشد",
                        "oPaginate":
                            {
                                "sFirst":
                                    "ابتدا",
                                "sLast":
                                    "انتها",
                                "sNext":
                                    "بعدی",
                                "sPrevious":
                                    "قبلی"
                            }
                        ,
                        "oAria":
                            {
                                "sSortAscending":
                                    ": فعال سازی نمایش به صورت صعودی",
                                "sSortDescending":
                                    ": فعال سازی نمایش به صورت نزولی"
                            }
                    }
            });
            $('#table2').DataTable({
                "processing":
                    true,
                "serverSide":
                    true,
                "ajax":
                    '/json-data-repository-product-p',
                "language":
                    {
                        "sEmptyTable":
                            "هیچ داده ای در جدول وجود ندارد",
                        "sInfo":
                            "نمایش _START_ تا _END_ از _TOTAL_ رکورد",
                        "sInfoEmpty":
                            "نمایش 0 تا 0 از 0 رکورد",
                        "sInfoFiltered":
                            "(فیلتر شده از _MAX_ رکورد)",
                        "sInfoPostFix":
                            "",
                        "sInfoThousands":
                            ",",
                        "sLengthMenu":
                            "نمایش _MENU_ رکورد",
                        "sLoadingRecords":
                            "در حال بارگزاری...",
                        "sProcessing":
                            "در حال پردازش...",
                        "sSearch":
                            "جستجو:",
                        "sZeroRecords":
                            "رکوردی با این مشخصات پیدا نشد",
                        "oPaginate":
                            {
                                "sFirst":
                                    "ابتدا",
                                "sLast":
                                    "انتها",
                                "sNext":
                                    "بعدی",
                                "sPrevious":
                                    "قبلی"
                            }
                        ,
                        "oAria":
                            {
                                "sSortAscending":
                                    ": فعال سازی نمایش به صورت صعودی",
                                "sSortDescending":
                                    ": فعال سازی نمایش به صورت نزولی"
                            }
                    }
            });
            $('#table3').DataTable({
                "processing":
                    true,
                "serverSide":
                    true,
                "ajax":
                    '/json-data-repository-middle-part-p',
                "language":
                    {
                        "sEmptyTable":
                            "هیچ داده ای در جدول وجود ندارد",
                        "sInfo":
                            "نمایش _START_ تا _END_ از _TOTAL_ رکورد",
                        "sInfoEmpty":
                            "نمایش 0 تا 0 از 0 رکورد",
                        "sInfoFiltered":
                            "(فیلتر شده از _MAX_ رکورد)",
                        "sInfoPostFix":
                            "",
                        "sInfoThousands":
                            ",",
                        "sLengthMenu":
                            "نمایش _MENU_ رکورد",
                        "sLoadingRecords":
                            "در حال بارگزاری...",
                        "sProcessing":
                            "در حال پردازش...",
                        "sSearch":
                            "جستجو:",
                        "sZeroRecords":
                            "رکوردی با این مشخصات پیدا نشد",
                        "oPaginate":
                            {
                                "sFirst":
                                    "ابتدا",
                                "sLast":
                                    "انتها",
                                "sNext":
                                    "بعدی",
                                "sPrevious":
                                    "قبلی"
                            }
                        ,
                        "oAria":
                            {
                                "sSortAscending":
                                    ": فعال سازی نمایش به صورت صعودی",
                                "sSortDescending":
                                    ": فعال سازی نمایش به صورت نزولی"
                            }
                    }
            });
            $('#table4').DataTable({
                "processing":
                    true,
                "serverSide":
                    true,
                "ajax":
                    '/json-data-repository-part-p',
                "language":
                    {
                        "sEmptyTable":
                            "هیچ داده ای در جدول وجود ندارد",
                        "sInfo":
                            "نمایش _START_ تا _END_ از _TOTAL_ رکورد",
                        "sInfoEmpty":
                            "نمایش 0 تا 0 از 0 رکورد",
                        "sInfoFiltered":
                            "(فیلتر شده از _MAX_ رکورد)",
                        "sInfoPostFix":
                            "",
                        "sInfoThousands":
                            ",",
                        "sLengthMenu":
                            "نمایش _MENU_ رکورد",
                        "sLoadingRecords":
                            "در حال بارگزاری...",
                        "sProcessing":
                            "در حال پردازش...",
                        "sSearch":
                            "جستجو:",
                        "sZeroRecords":
                            "رکوردی با این مشخصات پیدا نشد",
                        "oPaginate":
                            {
                                "sFirst":
                                    "ابتدا",
                                "sLast":
                                    "انتها",
                                "sNext":
                                    "بعدی",
                                "sPrevious":
                                    "قبلی"
                            }
                        ,
                        "oAria":
                            {
                                "sSortAscending":
                                    ": فعال سازی نمایش به صورت صعودی",
                                "sSortDescending":
                                    ": فعال سازی نمایش به صورت نزولی"
                            }
                    }
            });
            var table5 = $('#table5').on('draw.dt', function (e, settings, json, xhr) {
                    $('.js-switch').each(function () {

                        var data = table5.row($(this).parents('tr')).data();
                        var switchery = new Switchery($(this)[0], $(this).data());

                        data[12] == 1 ? $(this)[0].click() : 0;

                        $(this)[0].onchange = function () {
                            var cdata = table5.row($(this).parents('tr')).data();
                            var data = {
                                id: cdata[9],
                                status: $(this)[0].checked == true ? 1 : 0
                            };
                            //token
                            $.ajaxSetup({
                                headers: {
                                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                                }
                            });
                            $.ajax({
                                url: '/checkbox/' + data.id,
                                type: 'POST',
                                data: data,
                                dataType: 'json',
                                method: 'put',
                                async: false,
                                success: function (data) {
                                    swal({
                                        title: "",
                                        text: "<?php echo e(__('success')); ?>",
                                        icon: "success",
                                        button: "<?php echo e(__('Done')); ?>"
                                    })
                                },
                                cache: false,
                            });
                        }
                    })
                }).DataTable({

                    "processing":
                        true,
                    "serverSide":
                        true,
                    "ajax":
                        '/invoices-list-product',
                    "columnDefs":
                        [{
                            "targets": -1,
                            "data": null,
                            "render": function (data, type, row, meta) {
                                return "  <div class=\"dropdown\">\n" +
                                    "                                                            <a class=\"btn btn-link dropdown-toggle btn-icon\"\n" +
                                    "                                                                    data-toggle=\"dropdown\">\n" +
                                    "                                                                <i class=\"tim-icons icon-settings-gear-63\"></i>\n" +
                                    "                                                            </a>\n" +
                                    "                                                            <div class=\"dropdown-menu dropdown-menu-right\"\n" +
                                    "                                                                 aria-labelledby=\"dropdownMenuLink\">\n" +
                                    "                                                               <a  href=\"verify_pre/" + data[0] + "/edit\" class=\"dropdown-item\"\n" +
                                    "                                                                ><?php echo e(__('Preview Report')); ?></a>\n" +
                                    "                                                                <button class=\"dropdown-item deleted\" id=\"deleted\" type=\"submit\"><?php echo e(__('Final Approval')); ?></button>\n" +
                                    "                                                            </div>\n" +
                                    "                                                        </div>"
                            }
                        }, {
                            "targets": -2,
                            "data": null,
                            "defaultContent": '  <div class="progress">\n' +
                                    
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                        '                                                        </div>'
                        },
                            {
                                "targets": -3,
                                "data": null,
                                "defaultContent": '<input type="checkbox" class="js-switch" data-size="small"  >'
                            }],

                    "language":
                        {
                            "sEmptyTable":
                                "هیچ داده ای در جدول وجود ندارد",
                            "sInfo":
                                "نمایش _START_ تا _END_ از _TOTAL_ رکورد",
                            "sInfoEmpty":
                                "نمایش 0 تا 0 از 0 رکورد",
                            "sInfoFiltered":
                                "(فیلتر شده از _MAX_ رکورد)",
                            "sInfoPostFix":
                                "",
                            "sInfoThousands":
                                ",",
                            "sLengthMenu":
                                "نمایش _MENU_ رکورد",
                            "sLoadingRecords":
                                "در حال بارگزاری...",
                            "sProcessing":
                                "در حال پردازش...",
                            "sSearch":
                                "جستجو:",
                            "sZeroRecords":
                                "رکوردی با این مشخصات پیدا نشد",
                            "oPaginate":
                                {
                                    "sFirst":
                                        "ابتدا",
                                    "sLast":
                                        "انتها",
                                    "sNext":
                                        "بعدی",
                                    "sPrevious":
                                        "قبلی"
                                }
                            ,
                            "oAria":
                                {
                                    "sSortAscending":
                                        ": فعال سازی نمایش به صورت صعودی",
                                    "sSortDescending":
                                        ": فعال سازی نمایش به صورت نزولی"
                                }
                        }
                })
            ;
            $('#table6').DataTable({

                    "processing":
                        true,
                    "serverSide":
                        true,
                    "ajax":
                        '/invoices-list-product-inventory',
                    "language":
                        {
                            "sEmptyTable":
                                "هیچ داده ای در جدول وجود ندارد",
                            "sInfo":
                                "نمایش _START_ تا _END_ از _TOTAL_ رکورد",
                            "sInfoEmpty":
                                "نمایش 0 تا 0 از 0 رکورد",
                            "sInfoFiltered":
                                "(فیلتر شده از _MAX_ رکورد)",
                            "sInfoPostFix":
                                "",
                            "sInfoThousands":
                                ",",
                            "sLengthMenu":
                                "نمایش _MENU_ رکورد",
                            "sLoadingRecords":
                                "در حال بارگزاری...",
                            "sProcessing":
                                "در حال پردازش...",
                            "sSearch":
                                "جستجو:",
                            "sZeroRecords":
                                "رکوردی با این مشخصات پیدا نشد",
                            "oPaginate":
                                {
                                    "sFirst":
                                        "ابتدا",
                                    "sLast":
                                        "انتها",
                                    "sNext":
                                        "بعدی",
                                    "sPrevious":
                                        "قبلی"
                                }
                            ,
                            "oAria":
                                {
                                    "sSortAscending":
                                        ": فعال سازی نمایش به صورت صعودی",
                                    "sSortDescending":
                                        ": فعال سازی نمایش به صورت نزولی"
                                }
                        }
                })
            ;
            $('#table5').on('click', 'button', function (event) {

                var data_table = table5.row($(this).parents('tr')).data();
                var data = {
                    id: data_table[6],
                    product: data_table[5],
                    computing_repository_requirement: data_table[4],
                }
                alert(data.id);
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                swal({
                    // title: "",
                    text: "<?php echo e(__('Are you sure?')); ?>",
                    buttons: ["<?php echo e(__('cancel')); ?>", "<?php echo e(__('Done')); ?>"],
                    icon: "warning",
                    // buttons: true,
                    dangerMode: true,
                })
                    .then((willDelete) => {
                        if (willDelete) {
                            $.ajax({
                                url: '/order-state/' + data.id,
                                type: 'POST',
                                method: 'put',
                                data: data,
                                dataType: 'json',
                                async: true,
                                success: function (data) {
                                    swal("<?php echo e(__("The production process was successfully completed.")); ?>", {
                                        icon: "success",
                                        button: "<?php echo e(__('Done')); ?>",
                                    });
                                    $('#table5').DataTable().ajax.reload();
                                    $('#table2').DataTable().ajax.reload();
                                },
                                cache: false,
                            });
                        } else {
                            swal(
                                "<?php echo e(__("Your imaginary file is safe!")); ?>",
                                {button: "<?php echo e(__('Done')); ?>"}
                            );

                        }
                    });
            });

            // Modal Form
            $('#modal_form').submit(function (event) {
                var data = {
                    Product_Id: $('.product-id').data('id[]'),
                    Inventory_deficit: $('.inventory-deficit').data('inventory-deficit'),
                    Product_Count: $('.product-stock').data('product-stock'),
                }
                event.preventDefault();
                $.blockUI({
                    message: '<?php echo e(__('please wait...')); ?>', css: {
                        border: 'none',
                        padding: '15px',
                        backgroundColor: '#000',
                        '-webkit-border-radius': '10px',
                        '-moz-border-radius': '10px',
                        opacity: .5,
                        color: '#fff'
                    }
                });
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });

                $.ajax({
                    url: '/repository_requirement',
                    type: 'POST',
                    data: data,
                    dataType: 'json',
                    async: false,
                    success: function (data) {
                        alert('ok');
                        setTimeout($.unblockUI, 2000);
                        $("#modalRegisterForm").modal('hide');
                    },
                    cache: false,
                });
            });
            // End Modal Form
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>