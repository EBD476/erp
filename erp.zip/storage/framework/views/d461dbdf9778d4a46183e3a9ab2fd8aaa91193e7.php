<?php $__env->startSection('title',__('Order')); ?>

<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap.min.css">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(auth()->check() && auth()->user()->hasRole('order')): ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    
                    <a href="<?php echo e(route('order.create')); ?>" class="btn btn-primary float-left mb-lg-2"><i
                                class="tim-icons icon-simple-add"></i><?php echo e(__('Add New Order')); ?></a>
                    
                </div>
                <div class="card">
                    <div class="card-body">
                        <div class="col-md-9">
                            <div class="card">
                                <div class="card-header card-header-primary">
                                    <h4 class="card-title "><?php echo e(__('Order')); ?></h4>
                                    <p class="card-category"></p>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table id="table" class="table" cellspacing="0" width="100%">
                                            <thead class=" text-primary">
                                            <th>
                                                <?php echo e(__('ID')); ?>

                                            </th>
                                            <th>
                                                <?php echo e(__('Project Name')); ?>

                                            </th>
                                            <th>
                                                <?php echo e(__('Employer Name')); ?>

                                            </th>
                                            <th>
                                                <?php echo e(__('Connector')); ?>

                                            </th>
                                            <th>
                                                <?php echo e(__('Type Project')); ?>

                                            </th>
                                            <th>
                                                <?php echo e(__('action')); ?>

                                            </th>
                                            <th>
                                                <?php echo e(__('Accept State')); ?>

                                            </th>
                                            </thead>
                                            <tbody>
                                            <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $orders): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <?php echo e($key + 1); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($orders->hp_project_name); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($orders->hp_employer_name); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($orders->hp_connector); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($orders->hp_type_project); ?>

                                                    </td>
                                                    <td>
                                                        <div class="dropdown">
                                                            <button type="button"
                                                                    class="btn btn-link dropdown-toggle btn-icon"
                                                                    data-toggle="dropdown">
                                                                <i class="tim-icons icon-settings-gear-63"></i>
                                                            </button>
                                                            <div class="dropdown-menu dropdown-menu-right"
                                                                 aria-labelledby="dropdownMenuLink">
                                                                
                                                                
                                                                
                                                                <form id="-form-delete<?php echo e($orders->id); ?>"
                                                                      style="display: none;" method="POST"
                                                                      action="<?php echo e(route('order.destroy',$orders->id)); ?>">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('DELETE'); ?>
                                                                </form>
                                                                <a class="dropdown-item"
                                                                   onclick="if(confirm('آیا از حذف این پروژه اطمینان دارید؟')){
                                                                           event.preventDefault();
                                                                           document.getElementById('-form-delete<?php echo e($orders->id); ?>').submit();
                                                                           }else {
                                                                           event.preventDefault();}"><?php echo e(__('Delete')); ?></a>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="progress">
                                                            <?php $__currentLoopData = $progress; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $progresses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                
                                                                <?php if($progresses->ho_process_id == 1 and $orders->id == $progresses->order_id ): ?>
                                                                    <div class="progress-bar" role="progressbar"
                                                                         aria-valuenow="60" aria-valuemin="0"
                                                                         aria-valuemax="100" style="width: 25%;"></div>
                                                                <?php endif; ?>
                                                                <?php if($progresses->ho_process_id == 2 and $orders->id == $progresses->order_id): ?>
                                                                    <div class="progress-bar" role="progressbar"
                                                                         aria-valuenow="60" aria-valuemin="0"
                                                                         aria-valuemax="100" style="width: 50%;"></div>
                                                                <?php endif; ?>
                                                                <?php if($progresses->ho_process_id == 3 and $orders->id == $progresses->order_id): ?>
                                                                    <div class="progress-bar" role="progressbar"
                                                                         aria-valuenow="60" aria-valuemin="0"
                                                                         aria-valuemax="100"
                                                                         style="width: 75%;"></div>
                                                                <?php endif; ?>
                                                                <?php if($progresses->ho_process_id == 4 and $orders->id == $progresses->order_id ): ?>
                                                                    <div class="progress-bar" role="progressbar"
                                                                         aria-valuenow="60" aria-valuemin="0"
                                                                         aria-valuemax="100"
                                                                         style="width:100%; direction: ltr"></div>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </div>
                                                        
                                                    </td>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <br><br>
                            <div class="card card-user">
                                <div class="card-body">
                                    <p class="card-text">
                                    <div class="author">
                                        <div class="block block-one"></div>
                                        <div class="block block-two"></div>
                                        <div class="block block-three"></div>
                                        <div class="block block-four"></div>
                                        <a href="javascript:void(0)">
                                            
                                            <h5 class="title">Hanta IBMS</h5>
                                        </a>
                                    </div>
                                    </p>
                                    <div class="card-description">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin')): ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    
                    <a href="<?php echo e(route('order.create')); ?>" class="btn btn-primary float-left mb-lg-2"><i
                                class="tim-icons icon-simple-add"></i><?php echo e(__('Add New Order')); ?></a>
                    
                </div>
                <div class="card">
                    <div class="card-body">
                        <div class="col-md-9">
                            <div class="card">
                                <div class="card-header card-header-primary">
                                    <h4 class="card-title "><?php echo e(__('Order')); ?></h4>
                                    <p class="card-category"></p>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table id="table" class="table" cellspacing="0" width="100%">
                                            <thead class=" text-primary">
                                            <th>
                                                <?php echo e(__('ID')); ?>

                                            </th>
                                            <th>
                                                <?php echo e(__('Project Name')); ?>

                                            </th>
                                            <th>
                                                <?php echo e(__('Employer Name')); ?>

                                            </th>
                                            <th>
                                                <?php echo e(__('Connector')); ?>

                                            </th>
                                            <th>
                                                <?php echo e(__('Type Project')); ?>

                                            </th>
                                            <th>
                                                <?php echo e(__('action')); ?>

                                            </th>
                                            <th>
                                                <?php echo e(__('Accept State')); ?>

                                            </th>
                                            </thead>
                                            <tbody>
                                            <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $orders): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <?php echo e($key + 1); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($orders->hp_project_name); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($orders->hp_employer_name); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($orders->hp_connector); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($orders->hp_type_project); ?>

                                                    </td>
                                                    <td>
                                                        <div class="dropdown">
                                                            <button type="button"
                                                                    class="btn btn-link dropdown-toggle btn-icon"
                                                                    data-toggle="dropdown">
                                                                <i class="tim-icons icon-settings-gear-63"></i>
                                                            </button>
                                                            <div class="dropdown-menu dropdown-menu-right"
                                                                 aria-labelledby="dropdownMenuLink">
                                                                <a class="dropdown-item"
                                                                href="<?php echo e(route('order.edit',$orders->id)); ?>"
                                                                ><?php echo e(__('Edit')); ?></a>
                                                                <form id="-form-delete<?php echo e($orders->id); ?>"
                                                                      style="display: none;" method="POST"
                                                                      action="<?php echo e(route('order.destroy',$orders->id)); ?>">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('DELETE'); ?>
                                                                </form>
                                                                <a class="dropdown-item"
                                                                   onclick="if(confirm('آیا از حذف این پروژه اطمینان دارید؟')){
                                                                           event.preventDefault();
                                                                           document.getElementById('-form-delete<?php echo e($orders->id); ?>').submit();
                                                                           }else {
                                                                           event.preventDefault();}"><?php echo e(__('Delete')); ?></a>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="progress">
                                                            <?php $__currentLoopData = $progress; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $progresses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                
                                                                <?php if($progresses->ho_process_id == 1 and $orders->id == $progresses->order_id ): ?>
                                                                    <div class="progress-bar" role="progressbar"
                                                                         aria-valuenow="60" aria-valuemin="0"
                                                                         aria-valuemax="100"
                                                                         style="width: 25%;"></div>
                                                                <?php endif; ?>
                                                                <?php if($progresses->ho_process_id == 2 and $orders->id == $progresses->order_id): ?>
                                                                    <div class="progress-bar" role="progressbar"
                                                                         aria-valuenow="60" aria-valuemin="0"
                                                                         aria-valuemax="100"
                                                                         style="width: 50%;"></div>
                                                                <?php endif; ?>
                                                                <?php if($progresses->ho_process_id == 3 and $orders->id == $progresses->order_id): ?>
                                                                    <div class="progress-bar" role="progressbar"
                                                                         aria-valuenow="60" aria-valuemin="0"
                                                                         aria-valuemax="100"
                                                                         style="width: 75%;"></div>
                                                                <?php endif; ?>
                                                                <?php if($progresses->ho_process_id == 4 and $orders->id == $progresses->order_id ): ?>
                                                                    <div class="progress-bar" role="progressbar"
                                                                         aria-valuenow="60" aria-valuemin="0"
                                                                         aria-valuemax="100"
                                                                         style="width:100%; direction: ltr"></div>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </div>
                                                    </td>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <br><br>
                            <div class="card card-user">
                                <div class="card-body">
                                    <p class="card-text">
                                    <div class="author">
                                        <div class="block block-one"></div>
                                        <div class="block block-two"></div>
                                        <div class="block block-three"></div>
                                        <div class="block block-four"></div>
                                        <a href="javascript:void(0)">
                                            
                                            <h5 class="title">Hanta IBMS</h5>
                                        </a>
                                    </div>
                                    </p>
                                    <div class="card-description">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap.min.js"></script>
    <script>
        $(document).ready(function () {
            $('#table').DataTable({
                "language": {
                    "sEmptyTable": "هیچ داده ای در جدول وجود ندارد",
                    "sInfo": "نمایش _START_ تا _END_ از _TOTAL_ رکورد",
                    "sInfoEmpty": "نمایش 0 تا 0 از 0 رکورد",
                    "sInfoFiltered": "(فیلتر شده از _MAX_ رکورد)",
                    "sInfoPostFix": "",
                    "sInfoThousands": ",",
                    "sLengthMenu": "نمایش _MENU_ رکورد",
                    "sLoadingRecords": "در حال بارگزاری...",
                    "sProcessing": "در حال پردازش...",
                    "sSearch": "جستجو:",
                    "sZeroRecords": "رکوردی با این مشخصات پیدا نشد",
                    "oPaginate": {
                        "sFirst": "ابتدا",
                        "sLast": "انتها",
                        "sNext": "بعدی",
                        "sPrevious": "قبلی"
                    },
                    "oAria": {
                        "sSortAscending": ": فعال سازی نمایش به صورت صعودی",
                        "sSortDescending": ": فعال سازی نمایش به صورت نزولی"
                    }
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>