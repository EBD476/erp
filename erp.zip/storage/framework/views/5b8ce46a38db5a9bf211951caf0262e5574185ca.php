<footer class="footer">
    <div class="container-fluid persian">
        
            
                
                    
                
            
            
                
                    
                
            
            
                
                    
                
            
        
        <div class="copyright fc-ltr">
            <a href=http://hantaibms.com>Hantaibms</a> Co. by PGH ©2020
        </div>
    </div>
</footer>
