<?php $__env->startSection('content'); ?>
<div class="container col-md-8 h-100" >

    <div class="row justify-content-center align-items-lg-center h-100 ">
        <div class="col-md-7" >
            <div class="card card-white card-login">

                <div class="card-header bg-gradient-primary pt-3 pb-5">
                   <h3 class="text-white mb-0"> <?php echo e(__('Login')); ?> </h3>
                    <span> HANTA ERP V1.0</span>
                </div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>

                            <div class="input-group col-md-10 offset-md-1">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">
                                        <i class="tim-icons icon-single-02"></i>
                                    </div>
                                </div>
                                <input id="username"  type="text" class="form-control<?php echo e($errors->has('username') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Username')); ?>" name="username" value="<?php echo e(old('username')); ?>" required autofocus>
                                <?php if($errors->has('username')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('username')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>

                        <div class="input-group col-md-10 offset-md-1">
                            <div class="input-group-prepend">
                                <div class="input-group-text">
                                    <i class="tim-icons icon-key-25"></i>
                                </div>
                            </div>
                            <input id="password"  type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Password')); ?>" name="password"  required autofocus>
                            <?php if($errors->has('password')): ?>
                                <span class="invalid-feedback" role="alert">
                                    //خطای پسورد رو نشون میدهد//
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                            <?php endif; ?>
                        </div>

                        
                            

                            
                                

                                
                                    
                                        
                                    
                                
                            
                        

                        
                            
                                
                                    

                                    
                                        
                                    
                                
                            
                        

                        <div class="form-group row mb-0">
                            <div class="col-md-4 offset-md-4">
                                <button type="submit" class="btn btn-primary btn-block">
                                    <?php echo e(__('Login')); ?>

                                </button>
                            </div>


                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-4 offset-md-4">
                            <?php if(Route::has('password.request')): ?>
                                <a class="btn btn-link pm-md-0 mb-0" style="padding:0px" href="<?php echo e(route('password.request')); ?>">
                                    <small>
                                        <?php echo e(__('Forgot Your Password?')); ?>

                                    </small>
                                </a>
                        <?php endif; ?>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
            <div class="copyright text-center">
                ©2020 <a href=http://hantaibms.com >Hantaibms</a> Co. by PGH
            </div>
        </div>
    </div>

    
        
            
                
            
        
    

</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>