<?php $__env->startSection('title',__('Support')); ?>

<?php $__env->startPush('css'); ?>
    <link href="<?php echo e(asset('assets/css/dataTables.bootstrap.min.css')); ?>" rel="stylesheet"/>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin')): ?>
    <div class="content persian">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <a href="<?php echo e(route('support.show')); ?>" class="btn btn-primary float-left mb-lg-2"><i
                                class="tim-icons icon-simple-add"></i><?php echo e(__('All Support Request List')); ?></a>
                </div>
                <div class="card">
                    <div class="card-body">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header card-header-primary">
                                    <h4 class="card-title "><?php echo e(__('Support')); ?></h4>
                                    <p class="card-category"></p>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="card-header card-header-primary">
                                            <h4 class="card-title "><?php echo e(__('Projects List')); ?></h4>
                                            <p class="card-category"></p>
                                        </div>
                                        <div class="card-body">
                                            <div class="table-responsive">
                                                <table id="table1" class="table" cellspacing="0" width="100%">
                                                    <thead class=" text-primary">
                                                    <th>
                                                        <?php echo e(__('ID')); ?>

                                                    </th>
                                                    <th>
                                                        <?php echo e(__('Project Name')); ?>

                                                    </th>
                                                    </thead>
                                                    <tbody>

                                                    <?php $__currentLoopData = $project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $projects): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td>
                                                                <?php echo e($key + 1); ?>

                                                            </td>
                                                            <td>
                                                                <?php echo e($projects -> hp_project_name); ?>

                                                            </td>
                                                            <td>
                                                                <?php echo e($projects -> hp_project_type); ?>

                                                            </td>
                                                            <td>
                                                                <?php echo e($projects -> created_at); ?>

                                                            </td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="card-header card-header-primary">
                                            <h4 class="card-title "><?php echo e(__('Support Request')); ?></h4>
                                            <p class="card-category"></p>
                                        </div>
                                        <div class="card-body">
                                            <div class="table-responsive">
                                                <table id="table2" class="table" cellspacing="0" width="100%">
                                                    <thead class=" text-primary">
                                                    <th>
                                                        <?php echo e(__('ID')); ?>

                                                    </th>
                                                    <th>
                                                        <?php echo e(__('Project Name')); ?>

                                                    </th>
                                                    <th>
                                                        <?php echo e(__('action')); ?>

                                                    </th>
                                                    </thead>
                                                    <tbody>

                                                    <?php $__currentLoopData = $request; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $requests): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td>
                                                                <?php echo e($key + 1); ?>

                                                            </td>
                                                            <?php $__currentLoopData = $project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projects_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if($projects_name->id == $requests -> hs_project_id): ?>
                                                                    <td>
                                                                        <?php echo e($projects_name->hp_project_name); ?>

                                                                    </td>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            
                                                            
                                                            
                                                            <td>
                                                                <div class="dropdown">
                                                                    <button type="button"
                                                                            class="btn btn-link dropdown-toggle btn-icon"
                                                                            data-toggle="dropdown">
                                                                        <i class="tim-icons icon-settings-gear-63"></i>
                                                                    </button>
                                                                    <div class="dropdown-menu dropdown-menu-right"
                                                                         aria-labelledby="dropdownMenuLink">
                                                                        <a class="dropdown-item"
                                                                           href="<?php echo e(route('support.edit',$requests->id)); ?>"
                                                                        ><?php echo e(__('Show')); ?></a>
                                                                    </div>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    
    
    
    
        

            

            

                
                
                    
                        
                    
                
                
                    
                    
                    
                    
                    
                    
                
                    
                        
                            
                                
                                
                                
                                
                                
                                
                                    
                                        
                                        
                                    
                                
                                
                            
                            
                        
                            
                                
                                
                            

                        
                    
            
            
                

                    
                        
                    
                        
                    
                        
                    
                        
                            
                            
                            
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                        
                            
                            
                            
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                        
                    
                        
                            
                                
                            
                                
                            
                                
                            
                                
                            
                                
                            
                                
                            
                                
                            
                                
                            
                                
                            
                                
                            
                                
                            
                                
                                    
                                        
                                    
                                        
                                    
                                        
                                    
                                        
                                
                            
                            
                                
                                    
                                        
                                    
                                        
                                
                        
                
            
        
    
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>