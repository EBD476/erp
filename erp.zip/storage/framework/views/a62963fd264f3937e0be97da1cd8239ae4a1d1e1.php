<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="perfect-scrollbar-on">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <link href="<?php echo e(asset('assets/css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/nucleo-icons.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/style.min.css')); ?>" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-rtl/3.4.0/css/bootstrap-rtl.css" rel="stylesheet"/>
    <?php if(app()->getLocale() == 'fa'): ?>
        <link href="<?php echo e(asset('assets/css/rtl.css')); ?>" rel="stylesheet">
    <?php endif; ?>

    <?php echo $__env->yieldPushContent('css'); ?>
</head>
<body <?php if(app()->getLocale() == 'fa'): ?> class="white-content rtl menu-on-right" <?php else: ?>  class="white-content" <?php endif; ?>>

    <?php if(auth()->check() && auth()->user()->hasRole('Admin|order')): ?>
    <div class="wrapper">
            <div class="content persian">
                <div class="container-fluid">
                    <div class="card">
                        <div class="card-body">
                            <div class="card">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="panel panel-default">
                                                <div class="panel-heading">
                                                    <table class="table table-condensed">
                                                        <thead>
                                                        <tr>
                                                            <td class="text-left"><h4
                                                                        style="margin-top:30px;"><?php echo e(__('Date:')); ?> <?php echo e($data_dis->hop_due_date); ?></h4>
                                                            </td>
                                                            <td class="text-center"><h1
                                                                        style="margin-top:70px; margin-right: 150px ; margin-left: 150px"><?php echo e(__('Invoice Sales Of Product')); ?></h1>
                                                            </td>
                                                            <td><img align="right" width="170" height="170"
                                                                     src="<?php echo e(asset('assets/images/g.png')); ?>">
                                                            </td>

                                                        </tr>
                                                        </thead>
                                                    </table>
                                                </div>
                                                <div class="panel-body">
                                                    <div class="table-responsive">
                                                        <table class="table table-condensed">
                                                            <thead>
                                                            <th class="text-center"><strong><?php echo e(__('Owner profile')); ?>

                                                                    &nbsp;<?php echo e($client->hc_name); ?>

                                                                    &nbsp;<?php echo e($order->hp_phone_number); ?></strong></th>
                                                            <th class="text-center"><?php echo e(__('Employer Name:')); ?>

                                                                &nbsp;<?php echo e($order->hp_employer_name); ?></th>
                                                            <th class="text-center"><?php echo e(__('Project Name:')); ?>

                                                                &nbsp;<?php echo e($order->hp_project_name); ?></th>
                                                            <th class="text-center">&nbsp;<?php echo e(__('Type Project:')); ?>

                                                                &nbsp;<?php echo e($order->hp_type_project); ?></th>
                                                            <th class="text-center">
                                                                <?php echo e(__('Address:')); ?>

                                                                &nbsp;<?php echo e($state->hp_project_state); ?><?php echo e($city->hp_city); ?>

                                                                &nbsp;<?php echo e($order->hp_address); ?>

                                                            </th>
                                                            <th class="text-center">
                                                                &nbsp;<?php echo e(__('Create By:')); ?>&nbsp;
                                                                <?php echo e($order_registrant->name); ?>

                                                            </th>
                                                            </thead>
                                                            <thead>
                                                            <th class="text-center"><strong><?php echo e(__('Row')); ?></strong></th>
                                                            <th class="text-center">
                                                                <strong><?php echo e(__('Product Name')); ?></strong>
                                                            </th>
                                                            <th class="text-center"><strong><?php echo e(__('Quantity')); ?></strong>
                                                            </th>
                                                            <th class="text-center">
                                                                <strong><?php echo e(__('Description of Product')); ?></strong></th>
                                                            <?php if(auth()->check() && auth()->user()->hasRole('Admin||order')): ?>
                                                            <th class="text-center"><strong><?php echo e(__('Price')); ?></strong>
                                                            </th>
                                                            <th class="text-center"><strong><?php echo e(__('Sub Total')); ?></strong>
                                                            </th>
                                                            <?php endif; ?>
                                                            </thead>
                                                            <tbody>
                                                            <!-- foreach ($order->lineItems as $line) or some such thing here -->

                                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$data_loop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if($products->id == $data_loop->hpo_product_id): ?>
                                                                        <tr>
                                                                            <td class="text-center"><?php echo e($key + 1); ?></td>
                                                                            <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                    <?php $__currentLoopData = $color; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $colors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                        <?php if($colors->id == $products->hp_product_color_id): ?>
                                                                                            <?php if($property->id == $products->hp_product_property): ?>
                                                                                                <?php if($item->id == $property->hpp_property_items): ?>
                                                                                                    <td class="text-center"><?php echo e($products->hp_product_name . " " . $products->hp_product_model . " " .$colors->hn_color_name  . " " . $products->hp_product_size . " " . $property->hpp_property_name . " " . $item->hppi_items_name); ?></td>
                                                                                                <?php endif; ?>
                                                                                            <?php endif; ?>
                                                                                        <?php endif; ?>
                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                            <td class="text-center"><?php echo e($data_loop->hpo_count); ?></td>
                                                                            <td class="text-center"><?php echo e($data_loop->hpo_description); ?></td>
                                                                            <?php if(auth()->check() && auth()->user()->hasRole('Admin||order')): ?>
                                                                            <td class="text-center"><?php echo e($products->hp_product_price); ?></td>
                                                                            <td class="text-center"><?php echo e($data_loop->hpo_total); ?></td>
                                                                            <?php endif; ?>
                                                                        </tr>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <td class="thick-line"></td>
                                                            </tbody>
                                                            <?php if(auth()->check() && auth()->user()->hasRole('Admin||order')): ?>
                                                            <table>
                                                                <tr>
                                                                    <th class="no-line"></th>
                                                                    <th class="no-line"></th>
                                                                    <th class="no-line">
                                                                        <strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo e(__('Totals')); ?></strong>&nbsp;<?php echo e($order->hp_total_all); ?>

                                                                    </th>

                                                                </tr>
                                                                <?php if($order->hp_discount != ""): ?>
                                                                    <tr>
                                                                        <th class="no-line"></th>
                                                                        <th class="no-line"></th>
                                                                        <th class="no-line">
                                                                            <strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo e(__('Discount')); ?>

                                                                                %&nbsp;</strong><?php echo e($order->hp_discount); ?>

                                                                            &nbsp;&nbsp;
                                                                        </th>
                                                                    </tr>
                                                                    <tr>
                                                                        <th class="no-line"></th>
                                                                        <th class="no-line"></th>
                                                                        <th class="no-line">
                                                                            <strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo e(__('Total including discount:')); ?>

                                                                                &nbsp;</strong><?php echo e($order->hp_total_discount); ?>

                                                                        </th>
                                                                    </tr>
                                                                <?php endif; ?>
                                                            </table>
                                                        </table>
                                                    </div>
                                                    <?php if($current_verified_order === null and $order->hp_status == 1): ?>
                                                        <form method="POST"
                                                              action="<?php echo e(route('verify_pre.update',$order->id)); ?>"
                                                              ENCTYPE="multipart/form-data">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('PUT'); ?>
                                                            <button class="btn btn-primary"><?php echo e(__('Verify')); ?></button>
                                                        </form>
                                                    <?php endif; ?>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </div>
    <?php endif; ?>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="<?php echo e(asset('assets/js/plugins/persian-numbers-jquery-plugin-master/persianNum.jquery-2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugins/jquery.blockUI.js')); ?>" type="text/javascript"></script>
    <script>
        $(document).ready(function () {

            $('body').persianNum({
                forbiddenTag: ['input', 'div']
            })
            var isWindows = navigator.platform.indexOf('Win') > -1 ? true : false;

            $("#btn-1").on('click', function (event) {
                var data = $("#form1").serialize();
                event.preventDefault();
                $.blockUI({
                    message: '<?php echo e(__('please wait...')); ?>', css: {
                        border: 'none',
                        padding: '15px',
                        backgroundColor: '#000',
                        '-webkit-border-radius': '10px',
                        '-moz-border-radius': '10px',
                        opacity: .5,
                        color: '#fff'
                    }
                });
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });

                $.ajax({
                    url: '/order_product',
                    type: 'POST',
                    data: data,
                    dataType: 'json',
                    async: false,
                    success: function (data) {
                        setTimeout($.unblockUI, 2000);
                        window.location.href = "/order";
                    },
                    cache: false,
                });
            });
        });
    </script>
