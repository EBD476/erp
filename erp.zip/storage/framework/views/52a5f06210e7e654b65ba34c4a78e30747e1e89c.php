<?php $__env->startSection('title',__('Repository')); ?>

<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <?php echo $__env->make('layouts.partial.Msg', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
                <div class="card">
                    <div class="card-header card-header-primary">
                        <h4 class="card-title "><?php echo e(__('Edit Part')); ?></h4>
                        <p class="card-category"></p>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="<?php echo e(route('repository-part.update',$repository->id)); ?>"
                              ENCTYPE="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="bmd-label-floating"><?php echo e(__('Part Id')); ?></label>
                                        <input type="text" class="form-control" name="hrp_part_id" value="<?php echo e($repository->hrp_part_id); ?>">
                                    </div>

                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="bmd-label-floating"><?php echo e(__('Repository Name')); ?></label>
                                        <input type="text" class="form-control" required=""
                                               aria-invalid="false" name="hrp_repository_id" value="<?php echo e($repository->hrp_part_id); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="bmd-label-floating"><?php echo e(__('Count')); ?></label>
                                        <textarea class="form-control" required=""
                                                  aria-invalid="false" name="hrp_part_count" ><?php echo e($repository->hrp_part_count); ?></textarea>
                                    </div>
                                </div>
                            </div>
                                <a href="<?php echo e(route('repository.index')); ?>" class="btn badge-danger"><?php echo e(__('Back')); ?></a>

                                <button type="submit" class="btn badge-primary"><?php echo e(__('Send')); ?></button>
                        </form>
                    </div>

                </div>

            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>