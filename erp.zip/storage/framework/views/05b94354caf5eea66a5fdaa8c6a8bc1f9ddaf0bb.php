<?php $__env->startSection('title', __('Hanta Enterprise Resource Planning')); ?>

<?php $__env->startPush('css'); ?>
    <link href="<?php echo e(asset('assets/css/leaflet.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin')): ?>
    <div class="content persian">
        <div class="row">
            <div class="col-md-12">
                <div class="card card-plain">
                    
                    
                    
                    <div class="card-body">
                        <div id="map" class="map" style="width: 100%; height: 300px;direction: ltr"></div>
                    </div>
                </div>
            </div>

        </div>

        <div class="row">
            <div class="col-lg-3 col-md-6">
                <div class="card card-stats">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-5">
                                <div class="info-icon text-center icon-warning">
                                    <i class="tim-icons icon-puzzle-10"></i>
                                </div>
                            </div>
                            <div class="col-7">
                                <div class="numbers">
                                    <p class="card-category"><?php echo e(__('Total Orders')); ?></p>
                                    <h3 class="card-title persian"><?php echo e($orders); ?></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <hr>
                        <div class="stats">
                            <i class="tim-icons icon-refresh-01"></i> Update Now
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-6">
                <div class="card card-stats">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-5">
                                <div class="info-icon text-center icon-primary">
                                    <i class="tim-icons icon-single-copy-04"></i>
                                </div>
                            </div>
                            <div class="col-7">
                                <div class="numbers">
                                    <p class="card-category"><?php echo e(__('Order queue')); ?></p>
                                    <h3 class="card-title persian"><?php echo e($order_req); ?></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <hr>
                        <div class="stats">
                            <i class="tim-icons icon-sound-wave"></i> Last Research
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-6">
                <div class="card card-stats">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-5">
                                <div class="info-icon text-center icon-success">
                                    <i class="tim-icons icon-world"></i>
                                </div>
                            </div>
                            <div class="col-7">
                                <div class="numbers">
                                    <p class="card-category"><?php echo e(__('Agreement')); ?></p>
                                    <h3 class="card-title persian"><?php echo e($agreement); ?></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <hr>
                        <div class="stats">
                            <i class="tim-icons icon-trophy"></i> Customers feedback
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-6">
                <div class="card card-stats">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-5">
                                <div class="info-icon text-center icon-danger">
                                    <i class="tim-icons icon-single-02"></i>
                                </div>
                            </div>
                            <div class="col-7">
                                <div class="numbers">
                                    <p class="card-category"><?php echo e(__('Total Customers')); ?></p>
                                    <h3 class="card-title persian"><?php echo e($client); ?></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <hr>
                        <div class="stats">
                            <i class="tim-icons icon-watch-time"></i> In the last hours
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-12">
                <div class="card card-chart">
                    <div class="card-header ">
                        <div class="row">
                            <div class="col-sm-6 text-right">
                                
                                <h3 class="card-title"><?php echo e(__('Smart Home Projects')); ?></h3>
                            </div>
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="chart-area">
                            <canvas id="chartBig1"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-4">
                <div class="card card-chart">
                    <div class="card-header">
                        <h5 class="card-category">Total Shipments</h5>
                        <h3 class="card-title"><i class="tim-icons icon-bell-55 text-primary"></i> 763,215</h3>
                    </div>
                    <div class="card-body">
                        <div class="chart-area">
                            <canvas id="chartLinePurple"></canvas>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="card card-chart">
                    <div class="card-header">
                        <h5 class="card-category">Daily Sales</h5>
                        <h3 class="card-title"><i class="tim-icons icon-delivery-fast text-info"></i> 3,500€</h3>
                    </div>
                    <div class="card-body">
                        <div class="chart-area">
                            <canvas id="CountryChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="card card-chart">
                    <div class="card-header">
                        <h5 class="card-category">Completed Tasks</h5>
                        <h3 class="card-title"><i class="tim-icons icon-send text-success"></i> 12,100K</h3>
                    </div>
                    <div class="card-body">
                        <div class="chart-area">
                            <canvas id="chartLineGreen"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12 col-md-12">
                <div class="card ">
                    <div class="card-header text-right">
                        <h3 class="card-title"> <?php echo e(__('Order Verify List')); ?></h3>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table tablesorter " id="">
                                <thead class=" text-primary">
                                <tr>
                                    <th>
                                        <?php echo e(__('ID')); ?>

                                    </th>
                                    <th>
                                        <?php echo e(__('Name')); ?>

                                    </th>

                                    <th>
                                        <?php echo e(__('Created at')); ?>

                                    </th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <?php echo e($order->id); ?>

                                        </td>
                                        <td>
                                            <?php echo e($order->hp_project_name); ?>

                                        </td>
                                        <td>
                                            <?php echo e($order->created_at); ?>

                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('verify_pre.edit',$order->id)); ?>"
                                               class="btn btn-link btn-warning btn-icon btn-sm btn-neutral  edit">
                                                <i class="tim-icons icon-pencil"></i></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('finance')): ?>
    <div class="content persian">
        <div class="row">
            <div class="col-md-12">
                <div class="card card-plain">
                    
                    
                    
                    <div class="card-body">
                        <div id="map" class="map" style="width: 100%; height: 300px;direction: ltr"></div>
                    </div>
                </div>
            </div>

        </div>

        <div class="row">
            <div class="col-lg-3 col-md-6">
                <div class="card card-stats">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-5">
                                <div class="info-icon text-center icon-warning">
                                    <i class="tim-icons icon-puzzle-10"></i>
                                </div>
                            </div>
                            <div class="col-7">
                                <div class="numbers">
                                    <p class="card-category"><?php echo e(__('Total Orders')); ?></p>
                                    <h3 class="card-title persian"><?php echo e($orders); ?></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <hr>
                        <div class="stats">
                            <i class="tim-icons icon-refresh-01"></i> Update Now
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-6">
                <div class="card card-stats">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-5">
                                <div class="info-icon text-center icon-primary">
                                    <i class="tim-icons icon-single-copy-04"></i>
                                </div>
                            </div>
                            <div class="col-7">
                                <div class="numbers">
                                    <p class="card-category"><?php echo e(__('Order queue')); ?></p>
                                    <h3 class="card-title persian"><?php echo e($order_req); ?></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <hr>
                        <div class="stats">
                            <i class="tim-icons icon-sound-wave"></i> Last Research
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-6">
                <div class="card card-stats">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-5">
                                <div class="info-icon text-center icon-success">
                                    <i class="tim-icons icon-world"></i>
                                </div>
                            </div>
                            <div class="col-7">
                                <div class="numbers">
                                    <p class="card-category"><?php echo e(__('Agreement')); ?></p>
                                    <h3 class="card-title persian"><?php echo e($agreement); ?></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <hr>
                        <div class="stats">
                            <i class="tim-icons icon-trophy"></i> Customers feedback
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-6">
                <div class="card card-stats">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-5">
                                <div class="info-icon text-center icon-danger">
                                    <i class="tim-icons icon-single-02"></i>
                                </div>
                            </div>
                            <div class="col-7">
                                <div class="numbers">
                                    <p class="card-category"><?php echo e(__('Total Customers')); ?></p>
                                    <h3 class="card-title persian"><?php echo e($client); ?></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <hr>
                        <div class="stats">
                            <i class="tim-icons icon-watch-time"></i> In the last hours
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="row">
            <div class="col-12">
                <div class="card card-chart">
                    <div class="card-header ">
                        <div class="row">
                            <div class="col-sm-6 text-right">
                                
                                <h3 class="card-title"><?php echo e(__('Smart Home Projects')); ?></h3>
                            </div>
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="chart-area">
                            <canvas id="chartBig1"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="row">
            <div class="col-lg-4">
                <div class="card card-chart">
                    <div class="card-header">
                        <h5 class="card-category">Total Shipments</h5>
                        <h3 class="card-title"><i class="tim-icons icon-bell-55 text-primary"></i> 763,215</h3>
                    </div>
                    <div class="card-body">
                        <div class="chart-area">
                            <canvas id="chartLinePurple"></canvas>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="card card-chart">
                    <div class="card-header">
                        <h5 class="card-category">Daily Sales</h5>
                        <h3 class="card-title"><i class="tim-icons icon-delivery-fast text-info"></i> 3,500€</h3>
                    </div>
                    <div class="card-body">
                        <div class="chart-area">
                            <canvas id="CountryChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="card card-chart">
                    <div class="card-header">
                        <h5 class="card-category">Completed Tasks</h5>
                        <h3 class="card-title"><i class="tim-icons icon-send text-success"></i> 12,100K</h3>
                    </div>
                    <div class="card-body">
                        <div class="chart-area">
                            <canvas id="chartLineGreen"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            <div class="col-lg-12 col-md-12">
                <div class="card ">
                    <div class="card-header text-right">
                        <h3 class="card-title"> <?php echo e(__('Order Verify List')); ?></h3>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table tablesorter " id="">
                                <thead class=" text-primary">
                                <tr>
                                    <th>
                                        <?php echo e(__('ID')); ?>

                                    </th>
                                    <th>
                                        <?php echo e(__('Name')); ?>

                                    </th>

                                    <th>
                                        <?php echo e(__('Created at')); ?>

                                    </th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="persian">
                                            <?php echo e($order->id); ?>

                                        </td>
                                        <td>
                                            <?php echo e($order->hp_project_name); ?>

                                        </td>
                                        <td class="persian">
                                            <?php echo e($order->created_at); ?>

                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('verify_pre.edit',$order->id)); ?>"
                                               class="btn btn-link btn-warning btn-icon btn-sm btn-neutral  edit">
                                                <i class="tim-icons icon-pencil"></i></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('dealership')): ?>
    <div class="content persian">
        <div class="row">
            <div class="col-md-12">
                <div class="card card-plain">
                    
                    
                    
                    <div class="card-body">
                        <div id="map" class="map" style="width: 100%; height: 300px;direction: ltr"></div>
                    </div>
                </div>
            </div>

        </div>

        <div class="row">
            <div class="col-lg-3 col-md-6">
                <div class="card card-stats">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-5">
                                <div class="info-icon text-center icon-warning">
                                    <i class="tim-icons icon-puzzle-10"></i>
                                </div>
                            </div>
                            <div class="col-7">
                                <div class="numbers">
                                    <p class="card-category"><?php echo e(__('Total Orders')); ?></p>
                                    <h3 class="card-title persian"><?php echo e($orders); ?></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <hr>
                        <div class="stats">
                            <i class="tim-icons icon-refresh-01"></i> Update Now
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-6">
                <div class="card card-stats">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-5">
                                <div class="info-icon text-center icon-primary">
                                    <i class="tim-icons icon-single-copy-04"></i>
                                </div>
                            </div>
                            <div class="col-7">
                                <div class="numbers">
                                    <p class="card-category"><?php echo e(__('Order queue')); ?></p>
                                    <h3 class="card-title persian"><?php echo e($order_req); ?></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <hr>
                        <div class="stats">
                            <i class="tim-icons icon-sound-wave"></i> Last Research
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-6">
                <div class="card card-stats">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-5">
                                <div class="info-icon text-center icon-success">
                                    <i class="tim-icons icon-world"></i>
                                </div>
                            </div>
                            <div class="col-7">
                                <div class="numbers">
                                    <p class="card-category"><?php echo e(__('Agreement')); ?></p>
                                    <h3 class="card-title persian"><?php echo e($agreement); ?></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <hr>
                        <div class="stats">
                            <i class="tim-icons icon-trophy"></i> Customers feedback
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-6">
                <div class="card card-stats">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-5">
                                <div class="info-icon text-center icon-danger">
                                    <i class="tim-icons icon-single-02"></i>
                                </div>
                            </div>
                            <div class="col-7">
                                <div class="numbers">
                                    <p class="card-category"><?php echo e(__('Total Customers')); ?></p>
                                    <h3 class="card-title persian"><?php echo e($client); ?></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <hr>
                        <div class="stats">
                            <i class="tim-icons icon-watch-time"></i> In the last hours
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="row">
            <div class="col-12">
                <div class="card card-chart">
                    <div class="card-header ">
                        <div class="row">
                            <div class="col-sm-6 text-right">
                                
                                <h3 class="card-title"><?php echo e(__('Smart Home Projects')); ?></h3>
                            </div>
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="chart-area">
                            <canvas id="chartBig1"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="row">
            <div class="col-lg-4">
                <div class="card card-chart">
                    <div class="card-header">
                        <h5 class="card-category">Total Shipments</h5>
                        <h3 class="card-title"><i class="tim-icons icon-bell-55 text-primary"></i> 763,215</h3>
                    </div>
                    <div class="card-body">
                        <div class="chart-area">
                            <canvas id="chartLinePurple"></canvas>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="card card-chart">
                    <div class="card-header">
                        <h5 class="card-category">Daily Sales</h5>
                        <h3 class="card-title"><i class="tim-icons icon-delivery-fast text-info"></i> 3,500€</h3>
                    </div>
                    <div class="card-body">
                        <div class="chart-area">
                            <canvas id="CountryChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="card card-chart">
                    <div class="card-header">
                        <h5 class="card-category">Completed Tasks</h5>
                        <h3 class="card-title"><i class="tim-icons icon-send text-success"></i> 12,100K</h3>
                    </div>
                    <div class="card-body">
                        <div class="chart-area">
                            <canvas id="chartLineGreen"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
        </div>
    </div>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('repository')): ?>
    <div class="content persian">
        <div class="row">
            <div class="col-md-12">
                <div class="card card-plain">
                    
                    
                    
                    <div class="card-body">
                        <div id="map" class="map" style="width: 100%; height: 300px;direction: ltr"></div>
                    </div>
                </div>
            </div>

        </div>

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card card-chart">
                <div class="card-header ">
                    <div class="row">
                        <div class="col-sm-6 text-right">
                            
                            <h3 class="card-title"><?php echo e(__('Smart Home Projects')); ?></h3>
                        </div>
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                    </div>
                </div>
                <div class="card-body">
                    <div class="chart-area">
                        <canvas id="chartBig1"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-4">
            <div class="card card-chart">
                <div class="card-header">
                    <h5 class="card-category">Total Shipments</h5>
                    <h3 class="card-title"><i class="tim-icons icon-bell-55 text-primary"></i> 763,215</h3>
                </div>
                <div class="card-body">
                    <div class="chart-area">
                        <canvas id="chartLinePurple"></canvas>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="card card-chart">
                <div class="card-header">
                    <h5 class="card-category">Daily Sales</h5>
                    <h3 class="card-title"><i class="tim-icons icon-delivery-fast text-info"></i> 3,500€</h3>
                </div>
                <div class="card-body">
                    <div class="chart-area">
                        <canvas id="CountryChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="card card-chart">
                <div class="card-header">
                    <h5 class="card-category">Completed Tasks</h5>
                    <h3 class="card-title"><i class="tim-icons icon-send text-success"></i> 12,100K</h3>
                </div>
                <div class="card-body">
                    <div class="chart-area">
                        <canvas id="chartLineGreen"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    </div>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('product')): ?>
    <div class="content persian">
        <div class="row">
            <div class="col-lg-3 col-md-6">
                <div class="card card-stats">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-5">
                                <div class="info-icon text-center icon-warning">
                                    <i class="tim-icons icon-puzzle-10"></i>
                                </div>
                            </div>
                            <div class="col-7">
                                <div class="numbers">
                                    <p class="card-category"><?php echo e(__('Product Requirement')); ?></p>
                                    <?php $__currentLoopData = $product_requirement; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product_requirements): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <h3 class="card-title"><?php echo e($product_requirements->sum_hpo); ?></h3>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    
                    
                    
                    
                    
                </div>
            </div>

            <div class="col-lg-3 col-md-6">
                <div class="card card-stats">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-5">
                                <div class="info-icon text-center icon-primary">
                                    <i class="tim-icons icon-single-copy-04"></i>
                                </div>
                            </div>
                            <div class="col-7">
                                <div class="numbers">
                                    <p class="card-category"><?php echo e(__('Order queue')); ?></p>
                                    <h3 class="card-title"><?php echo e($order_req); ?></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    
                    
                    
                    
                    
                </div>
            </div>

            <div class="col-lg-3 col-md-6">
                <div class="card card-stats">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-5">
                                <div class="info-icon text-center icon-danger">
                                    <i class="tim-icons icon-single-02"></i>
                                </div>
                            </div>
                            <div class="col-7">
                                <div class="numbers">
                                    <p class="card-category"><?php echo e(__('Returned')); ?></p>
                                    <h3 class="card-title">0</h3>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    
                    
                    
                    
                    
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="card card-stats">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-5">
                                <div class="info-icon text-center icon-success">
                                    <i class="tim-icons icon-world"></i>
                                </div>
                            </div>
                            <div class="col-7">
                                <div class="numbers">
                                    <p class="card-category"><?php echo e(__('Unseen messages')); ?></p>
                                    <h3 class="card-title"><?php echo e($un_seen_message); ?></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    
                    
                    
                    
                    
                </div>
            </div>
        </div>


        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        


        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    </div>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('order')): ?>
    <div class="content persian">
        <div class="row">
            <div class="col-lg-2 col-md-6">
                <div class="card card-stats">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-5">
                                <div class="info-icon text-center icon-warning">
                                    <i class="tim-icons icon-puzzle-10"></i>
                                </div>
                            </div>
                            <div class="col-7">
                                <div class="numbers">
                                    <p class="card-category"><?php echo e(__('Total Orders')); ?></p>
                                    <h3 class="card-title"><?php echo e($order_order); ?></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    
                    
                    
                    
                    
                </div>
            </div>

            <div class="col-lg-2 col-md-6">
                <div class="card card-stats">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-5">
                                <div class="info-icon text-center icon-primary">
                                    <i class="tim-icons icon-single-copy-04"></i>
                                </div>
                            </div>
                            <div class="col-7">
                                <div class="numbers">
                                    <p class="card-category"><?php echo e(__('Order queue')); ?></p>
                                    <h3 class="card-title"><?php echo e($order_order); ?></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    
                    
                    
                    
                    
                </div>
            </div>

            <div class="col-lg-2 col-md-6">
                <div class="card card-stats">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-5">
                                <div class="info-icon text-center icon-success">
                                    <i class="tim-icons icon-world"></i>
                                </div>
                            </div>
                            <div class="col-7">
                                <div class="numbers">
                                    <p class="card-category"><?php echo e(__('Agreement')); ?></p>
                                    <h3 class="card-title"><?php echo e($agreement); ?></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    
                    
                    
                    
                    
                </div>
            </div>

            <div class="col-lg-2 col-md-6">
                <div class="card card-stats">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-5">
                                <div class="info-icon text-center icon-danger">
                                    <i class="tim-icons icon-single-02"></i>
                                </div>
                            </div>
                            <div class="col-7">
                                <div class="numbers">
                                    <p class="card-category"><?php echo e(__('Total Customers')); ?></p>
                                    <h3 class="card-title"><?php echo e($client_order); ?></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    
                    
                    
                    
                    
                </div>
            </div>

            <div class="col-lg-2 col-md-6">
                <div class="card card-stats">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-5">
                                <div class="info-icon text-center icon-success">
                                    <i class="tim-icons icon-world"></i>
                                </div>
                            </div>
                            <div class="col-7">
                                <div class="numbers">
                                    <p class="card-category" style="font-size: .73rem;"><?php echo e(__('Unseen messages')); ?></p>
                                    <h3 class="card-title"><?php echo e($un_seen_message); ?></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    
                    
                    
                    
                    
                </div>
            </div>
        </div>


        <div class="row">
            <div class="col-lg-12 col-md-12">
                <div class="card ">
                    <div class="card-header text-right">
                        <h3 class="card-title"> <?php echo e(__('Order Status List')); ?></h3>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table tablesorter " id="">
                                <thead class=" text-primary">
                                <tr>
                                    <th>
                                        <?php echo e(__('ID')); ?>

                                    </th>
                                    <th>
                                        <?php echo e(__('Name')); ?>

                                    </th>
                                    <th>
                                        <?php echo e(__('Created at')); ?>

                                    </th>
                                    <th>
                                        <?php echo e(__('Status')); ?>

                                    </th>
                                    <th>
                                        <?php echo e(__('Preview Factor')); ?>

                                    </th>

                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $order_agent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order_agents): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <?php echo e($order_agents->id); ?>

                                        </td>
                                        <td>
                                            <?php echo e($order_agents->hp_project_name); ?>

                                        </td>
                                        <td>
                                            <?php echo e($order_agents->created_at); ?>

                                        </td>
                                        <?php $__currentLoopData = $process_level; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($status->hp_process_id == $order_agents->hp_status): ?>
                                                <td>
                                                    <div class="row">
                                                        <div class="col-md-10">
                                                            <div class="col-md-4" style="margin-top: -10px">
                                                                <?php echo e($status->hp_process_name); ?>

                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="progress">
                                                                    <?php $__currentLoopData = $progress; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $progresses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        
                                                                        <?php if($progresses->ho_process_id == 1 and $order_agents->id == $progresses->order_id ): ?>
                                                                            <div class="progress-bar" role="progressbar"
                                                                                 aria-valuenow="60" aria-valuemin="0"
                                                                                 aria-valuemax="100"
                                                                                 style="width: 25%;"></div>
                                                                        <?php endif; ?>
                                                                        <?php if($progresses->ho_process_id == 2 and $order_agents->id == $progresses->order_id): ?>
                                                                            <div class="progress-bar" role="progressbar"
                                                                                 aria-valuenow="60" aria-valuemin="0"
                                                                                 aria-valuemax="100"
                                                                                 style="width: 50%;"></div>
                                                                        <?php endif; ?>
                                                                        <?php if($progresses->ho_process_id == 3 and $order_agents->id == $progresses->order_id): ?>
                                                                            <div class="progress-bar" role="progressbar"
                                                                                 aria-valuenow="60" aria-valuemin="0"
                                                                                 aria-valuemax="100"
                                                                                 style="width: 75%;"></div>
                                                                        <?php endif; ?>
                                                                        <?php if($progresses->ho_process_id == 4 and $order_agents->id == $progresses->order_id ): ?>
                                                                            <div class="progress-bar" role="progressbar"
                                                                                 aria-valuenow="60" aria-valuemin="0"
                                                                                 aria-valuemax="100"
                                                                                 style="width:100%; direction: ltr"></div>
                                                                        <?php endif; ?>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </td>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <td>
                                            <a href="<?php echo e(route('verify_pre.edit',$order_agents->id)); ?>"
                                               class="btn btn-link btn-warning btn-icon btn-sm btn-neutral  edit">
                                                <i class="tim-icons icon-pencil"></i></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    </div>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('geust')): ?>
    <div class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="card card-plain">
                    
                    
                    
                    <div class="card-body">
                        <div id="map" class="map" style="width: 100%; height: 300px;direction: ltr"></div>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

    
    <script src="<?php echo e(asset('assets/js/plugins/perfect-scrollbar.jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugins/leaflet.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugins/chartjs.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/demo.js')); ?>"></script>

    <script>
        $(document).ready(function () {

            demo.initDashboardPageCharts();

            var isWindows = navigator.platform.indexOf('Win') > -1 ? true : false;

            /**** Scroller ****/

            // if ($.fn.niceScroll){
            //     var mainScroller = $("html").niceScroll({
            //         zindex:999999,
            //         boxzoom:true,
            //         cursoropacitymin :0.5,
            //         cursoropacitymax :0.8,
            //         cursorwidth :"10px",
            //         cursorborder :"0px solid",
            //         autohidemode:false
            //     });
            // };

            /*** PerfectScrollbar ****/

            if (isWindows) {

                if ($('.main-panel').length != 0) {
                    var ps = new PerfectScrollbar('.main-panel', {
                        wheelSpeed: 0.01,
                        wheelPropagation: false,
                        minScrollbarLength: 10,
                        suppressScrollX: true
                    });
                }

                if ($('.sidebar .sidebar-wrapper').length != 0) {

                    var ps1 = new PerfectScrollbar('.sidebar .sidebar-wrapper');
                    $('.table-responsive').each(function () {
                        var ps2 = new PerfectScrollbar($(this)[0]);
                    });
                }

                $('html').addClass('perfect-scrollbar-on');
            }

            var greenIcon = L.icon({
                iconUrl: '../../assets/images/marker-icon.png',
                iconSize: [24, 24], // size of the icon
            });

            var cities = L.layerGroup();

            <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            L.marker([<?php echo e($project->hp_project_location); ?>], {icon: greenIcon}).bindPopup('This is Littleton, CO.').addTo(cities);
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            var mbAttr = '',
                mbUrl = 'https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token=pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTA2emYycXBndHRqcmZ3N3gifQ.rJcFIG214AriISLbB6B5aw';

            var grayscale = L.tileLayer(mbUrl, {id: 'mapbox.light', attribution: mbAttr}),
                streets = L.tileLayer(mbUrl, {id: 'mapbox.streets', attribution: mbAttr});

            var map = L.map('map', {
                center: [32.760, 53.503],
                zoom: 5,
                layers: [cities, grayscale]
            });

            var baseLayers = {
                "Grayscale": grayscale,
                "Streets": streets
            };

            var overlays = {
                "Cities": cities
            };

            // map.on('click', onMapClick);


        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>