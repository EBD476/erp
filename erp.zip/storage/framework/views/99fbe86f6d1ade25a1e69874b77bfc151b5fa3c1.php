<?php $__env->startSection('title', '| Permissions'); ?>

<?php $__env->startSection('content'); ?>

    <div class="wrap main-content" data-scrollbar>
        <div class="content">
            <div class="col-md-12">
                <h3>
                    <i class="fa fa-key pull-right"><?php echo e(__('Available Permissions')); ?></i>

                    <a href="<?php echo e(route('users.index')); ?>" class="btn btn-primary pull-left"><i
                                class="tim-icons icon-simple-add"></i><?php echo e(__('Users')); ?></a>
                    <a href="<?php echo e(route('roles.index')); ?>" class="btn btn-primary pull-left"><i
                                class="tim-icons icon-simple-add"></i><?php echo e(__('Roles')); ?></a>
                    <a href="<?php echo e(URL::to('permissions/create')); ?>"
                       class="btn btn-primary pull-left"><i
                                class="tim-icons icon-simple-add"></i><?php echo e(__('Add Permission')); ?></a>
                </h3>
                <hr>
            </div>
            <div class="card">
                <div class="card-body">
                    <div class="col-md-9">
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive" style="font-size: 13px;color: #65767c">
                                    <table class="table table-striped">

                                        <thead>
                                        <tr>
                                            <th><?php echo e(__('Permissions')); ?></th>
                                            <th><?php echo e(__('Operation')); ?></th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($permission->name); ?></td>
                                                <td>
                                                    <a href="<?php echo e(URL::to('permissions/'.$permission->id.'/edit')); ?>"
                                                       class="btn btn-link btn-warning btn-icon btn-sm btn-neutral  edit">
                                                        <i class="tim-icons icon-pencil"></i></a>

                                                    <form action="<?php echo e(route('permissions.destroy', $permission->id)); ?>" style="display: none;">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                    </form>
                                                    <a class="btn btn-link btn-danger btn-icon btn-sm btn-neutral remove"
                                                       onclick="if(confirm('آیا از حذف این مجوز اطمینان دارید؟')){
                                                               event.preventDefault();
                                                               document.getElementById('-form-delete<?php echo e($permission->id); ?>').submit();
                                                               }else {
                                                               event.preventDefault();}"><i
                                                                class="tim-icons icon-simple-remove"></i></a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <br><br>
                        <div class="card card-user">
                            <div class="card-body">
                                <p class="card-text">
                                    <div class="author">
                                        <div class="block block-one"></div>
                                        <div class="block block-two"></div>
                                        <div class="block block-three"></div>
                                        <div class="block block-four"></div>
                                        <a href="javascript:void(0)">
                                            
                                            <h5 class="title">Hanta IBMS</h5>
                                        </a>
                                <p class="description">

                                </p>
                            </div>
                            </p>
                            <div class="card-description">

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>