<?php $__env->startSection('title', '| Edit User'); ?>

<?php $__env->startSection('content'); ?>
    <?php if(auth()->check() && auth()->user()->hasRole('super admin')): ?>
    <div class="wrap main-content" data-scrollbar>
        <div class="content">
            <div class="card">
                <div class="card-body">
                    <div class='col-lg-8'>
                        <h3><i class='fa fa-user-plus pull-right'> <?php echo e(__('Edit')); ?> <?php echo e($user->name); ?></i></h3>
                        <hr>
                        <form action="<?php echo e(route('users.update',[$user->id])); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label><?php echo e(__('Name')); ?></label>
                                        <input type="text" class="form-control" name="name" value="<?php echo e($user->name); ?>">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label><?php echo e(__('Username')); ?></label>
                                        <input type="text" class="form-control" name="username"
                                               value="<?php echo e($user->username); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label><?php echo e(__('Device ID')); ?></label>
                                        <input type="number" class="form-control" name="device_id"
                                               value="<?php echo e($user->device_id); ?>">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group   ">
                                        <label><?php echo e(__('Password')); ?></label>
                                        <input type="password" class="form-control" name="password"
                                               value="<?php echo e($user->password); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="form-group">
                                        <label><?php echo e(__('Email')); ?></label>
                                        <input type="email" class="form-control" name="email" value="<?php echo e($user->email); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class='form-group'>
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="row">
                                        <div class="col-md-8">
                                            <div class="col-md-3">
                                                <label><?php echo e(ucfirst($role->name)); ?></label>
                                                <input type="checkbox" name="roles[]" value="<?php echo e($role->id); ?>">
                                                
                                                
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                            <div class="row">
                                <input type="submit" class="btn btn-block btn-primary col-md-2" value="<?php echo e(__('Send')); ?>">
                            </div>
                        </form>
                    </div>
                    <div class="col-md-4">
                        <div class="card card-user">
                            <div class="card-body">
                                <p class="card-text">
                                    <div class="author">
                                        <div class="block block-one"></div>
                                        <div class="block block-two"></div>
                                        <div class="block block-three"></div>
                                        <div class="block block-four"></div>
                                        <a href="javascript:void(0)">
                                            
                                            <h5 class="title">Hanta IBMS</h5>
                                        </a>
                                <p class="description">
                                    Project Implementors
                                </p>
                            </div>
                            </p>
                            <div class="card-description">

                            </div>
                        </div>
                        <div class="card-footer">
                            <div class="button-container">
                                <button href="javascript:void(0)" class="btn btn-icon btn-round btn-facebook">
                                    <i class="fab fa-facebook"></i>
                                </button>
                                <button href="javascript:void(0)" class="btn btn-icon btn-round btn-twitter">
                                    <i class="fab fa-twitter"></i>
                                </button>
                                <button href="javascript:void(0)" class="btn btn-icon btn-round btn-google">
                                    <i class="fab fa-google-plus"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php endif; ?>
        <?php if(auth()->check() && auth()->user()->hasRole('Admin')): ?>
    <div class="wrap main-content" data-scrollbar>
        <div class="content">
            <div class="card">
                <div class="card-body">
                    <div class='col-lg-8'>
                        <h3><i class='fa fa-user-plus pull-right'> <?php echo e(__('Edit')); ?> <?php echo e($user->name); ?></i></h3>
                        <hr>
                        <form action="<?php echo e(route('users.update',[$user->id])); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label><?php echo e(__('Name')); ?></label>
                                        <input type="text" class="form-control" name="name" value="<?php echo e($user->name); ?>">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label><?php echo e(__('Username')); ?></label>
                                        <input type="text" class="form-control" name="username"
                                               value="<?php echo e($user->username); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label><?php echo e(__('Device ID')); ?></label>
                                        <input type="number" class="form-control" name="device_id"
                                               value="<?php echo e($user->device_id); ?>">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group   ">
                                        <label><?php echo e(__('Password')); ?></label>
                                        <input type="password" class="form-control" name="password"
                                               value="<?php echo e($user->password); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="form-group">
                                        <label><?php echo e(__('Email')); ?></label>
                                        <input type="email" class="form-control" name="email" value="<?php echo e($user->email); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class='form-group'>
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="row">
                                        <div class="col-md-8">
                                            <div class="col-md-3">
                                                <label><?php echo e(ucfirst($role->name)); ?></label>
                                                <input type="checkbox" name="roles[]" value="<?php echo e($role->id); ?>">
                                                
                                                
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                            <div class="row">
                                <input type="submit" class="btn btn-block btn-primary col-md-2" value="<?php echo e(__('Send')); ?>">
                            </div>
                        </form>
                    </div>
                    <div class="col-md-4">
                        <div class="card card-user">
                            <div class="card-body">
                                <p class="card-text">
                                    <div class="author">
                                        <div class="block block-one"></div>
                                        <div class="block block-two"></div>
                                        <div class="block block-three"></div>
                                        <div class="block block-four"></div>
                                        <a href="javascript:void(0)">
                                            
                                            <h5 class="title">Hanta IBMS</h5>
                                        </a>
                                <p class="description">
                                    Project Implementors
                                </p>
                            </div>
                            </p>
                            <div class="card-description">

                            </div>
                        </div>
                        <div class="card-footer">
                            <div class="button-container">
                                <button href="javascript:void(0)" class="btn btn-icon btn-round btn-facebook">
                                    <i class="fab fa-facebook"></i>
                                </button>
                                <button href="javascript:void(0)" class="btn btn-icon btn-round btn-twitter">
                                    <i class="fab fa-twitter"></i>
                                </button>
                                <button href="javascript:void(0)" class="btn btn-icon btn-round btn-google">
                                    <i class="fab fa-google-plus"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
        <?php if(auth()->check() && auth()->user()->hasRole('finance')): ?>
        <div class="wrap main-content" data-scrollbar>
            <div class="content">
                <div class="card">
                    <div class="card-body">
                        <div class='col-lg-8'>
                            <h3><i class='fa fa-user-plus pull-right'> <?php echo e(__('Edit')); ?> <?php echo e($user->name); ?></i></h3>
                            <hr>
                            <form action="<?php echo e(route('users.update',[$user->id])); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label><?php echo e(__('Name')); ?></label>
                                            <input type="text" class="form-control" name="name" value="<?php echo e($user->name); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label><?php echo e(__('Username')); ?></label>
                                            <input type="text" class="form-control" name="username"
                                                   value="<?php echo e($user->username); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label><?php echo e(__('Device ID')); ?></label>
                                            <input type="number" class="form-control" name="device_id"
                                                   value="<?php echo e($user->device_id); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group   ">
                                            <label><?php echo e(__('Password')); ?></label>
                                            <input type="password" class="form-control" name="password"
                                                   value="<?php echo e($user->password); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-8">
                                        <div class="form-group">
                                            <label><?php echo e(__('Email')); ?></label>
                                            <input type="email" class="form-control" name="email" value="<?php echo e($user->email); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <input type="submit" class="btn btn-block btn-primary col-md-2" value="<?php echo e(__('Send')); ?>">
                                </div>
                            </form>
                        </div>
                        <div class="col-md-4">
                            <div class="card card-user">
                                <div class="card-body">
                                    <p class="card-text">
                                        <div class="author">
                                            <div class="block block-one"></div>
                                            <div class="block block-two"></div>
                                            <div class="block block-three"></div>
                                            <div class="block block-four"></div>
                                            <a href="javascript:void(0)">
                                                
                                                <h5 class="title">Hanta IBMS</h5>
                                            </a>
                                    <p class="description">
                                        Project Implementors
                                    </p>
                                </div>
                                </p>
                                <div class="card-description">

                                </div>
                            </div>
                            <div class="card-footer">
                                <div class="button-container">
                                    <button href="javascript:void(0)" class="btn btn-icon btn-round btn-facebook">
                                        <i class="fab fa-facebook"></i>
                                    </button>
                                    <button href="javascript:void(0)" class="btn btn-icon btn-round btn-twitter">
                                        <i class="fab fa-twitter"></i>
                                    </button>
                                    <button href="javascript:void(0)" class="btn btn-icon btn-round btn-google">
                                        <i class="fab fa-google-plus"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <?php if(auth()->check() && auth()->user()->hasRole('dealership')): ?>
        <div class="wrap main-content" data-scrollbar>
            <div class="content">
                <div class="card">
                    <div class="card-body">
                        <div class='col-lg-8'>
                            <h3><i class='fa fa-user-plus pull-right'> <?php echo e(__('Edit')); ?> <?php echo e($user->name); ?></i></h3>
                            <hr>
                            <form action="<?php echo e(route('users.update',[$user->id])); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label><?php echo e(__('Name')); ?></label>
                                            <input type="text" class="form-control" name="name" value="<?php echo e($user->name); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label><?php echo e(__('Username')); ?></label>
                                            <input type="text" class="form-control" name="username"
                                                   value="<?php echo e($user->username); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label><?php echo e(__('Device ID')); ?></label>
                                            <input type="number" class="form-control" name="device_id"
                                                   value="<?php echo e($user->device_id); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group   ">
                                            <label><?php echo e(__('Password')); ?></label>
                                            <input type="password" class="form-control" name="password"
                                                   value="<?php echo e($user->password); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-8">
                                        <div class="form-group">
                                            <label><?php echo e(__('Email')); ?></label>
                                            <input type="email" class="form-control" name="email" value="<?php echo e($user->email); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <input type="submit" class="btn btn-block btn-primary col-md-2" value="<?php echo e(__('Send')); ?>">
                                </div>
                            </form>
                        </div>
                        <div class="col-md-4">
                            <div class="card card-user">
                                <div class="card-body">
                                    <p class="card-text">
                                        <div class="author">
                                            <div class="block block-one"></div>
                                            <div class="block block-two"></div>
                                            <div class="block block-three"></div>
                                            <div class="block block-four"></div>
                                            <a href="javascript:void(0)">
                                                
                                                <h5 class="title">Hanta IBMS</h5>
                                            </a>
                                    <p class="description">
                                        Project Implementors
                                    </p>
                                </div>
                                </p>
                                <div class="card-description">

                                </div>
                            </div>
                            <div class="card-footer">
                                <div class="button-container">
                                    <button href="javascript:void(0)" class="btn btn-icon btn-round btn-facebook">
                                        <i class="fab fa-facebook"></i>
                                    </button>
                                    <button href="javascript:void(0)" class="btn btn-icon btn-round btn-twitter">
                                        <i class="fab fa-twitter"></i>
                                    </button>
                                    <button href="javascript:void(0)" class="btn btn-icon btn-round btn-google">
                                        <i class="fab fa-google-plus"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <?php if(auth()->check() && auth()->user()->hasRole('repository')): ?>
        <div class="wrap main-content" data-scrollbar>
            <div class="content">
                <div class="card">
                    <div class="card-body">
                        <div class='col-lg-8'>
                            <h3><i class='fa fa-user-plus pull-right'> <?php echo e(__('Edit')); ?> <?php echo e($user->name); ?></i></h3>
                            <hr>
                            <form action="<?php echo e(route('users.update',[$user->id])); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label><?php echo e(__('Name')); ?></label>
                                            <input type="text" class="form-control" name="name" value="<?php echo e($user->name); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label><?php echo e(__('Username')); ?></label>
                                            <input type="text" class="form-control" name="username"
                                                   value="<?php echo e($user->username); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label><?php echo e(__('Device ID')); ?></label>
                                            <input type="number" class="form-control" name="device_id"
                                                   value="<?php echo e($user->device_id); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group   ">
                                            <label><?php echo e(__('Password')); ?></label>
                                            <input type="password" class="form-control" name="password"
                                                   value="<?php echo e($user->password); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-8">
                                        <div class="form-group">
                                            <label><?php echo e(__('Email')); ?></label>
                                            <input type="email" class="form-control" name="email" value="<?php echo e($user->email); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <input type="submit" class="btn btn-block btn-primary col-md-2" value="<?php echo e(__('Send')); ?>">
                                </div>
                            </form>
                        </div>
                        <div class="col-md-4">
                            <div class="card card-user">
                                <div class="card-body">
                                    <p class="card-text">
                                        <div class="author">
                                            <div class="block block-one"></div>
                                            <div class="block block-two"></div>
                                            <div class="block block-three"></div>
                                            <div class="block block-four"></div>
                                            <a href="javascript:void(0)">
                                                
                                                <h5 class="title">Hanta IBMS</h5>
                                            </a>
                                    <p class="description">
                                        Project Implementors
                                    </p>
                                </div>
                                </p>
                                <div class="card-description">

                                </div>
                            </div>
                            <div class="card-footer">
                                <div class="button-container">
                                    <button href="javascript:void(0)" class="btn btn-icon btn-round btn-facebook">
                                        <i class="fab fa-facebook"></i>
                                    </button>
                                    <button href="javascript:void(0)" class="btn btn-icon btn-round btn-twitter">
                                        <i class="fab fa-twitter"></i>
                                    </button>
                                    <button href="javascript:void(0)" class="btn btn-icon btn-round btn-google">
                                        <i class="fab fa-google-plus"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <?php if(auth()->check() && auth()->user()->hasRole('product')): ?>
        <div class="wrap main-content" data-scrollbar>
            <div class="content">
                <div class="card">
                    <div class="card-body">
                        <div class='col-lg-8'>
                            <h3><i class='fa fa-user-plus pull-right'> <?php echo e(__('Edit')); ?> <?php echo e($user->name); ?></i></h3>
                            <hr>
                            <form action="<?php echo e(route('users.update',[$user->id])); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label><?php echo e(__('Name')); ?></label>
                                            <input type="text" class="form-control" name="name" value="<?php echo e($user->name); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label><?php echo e(__('Username')); ?></label>
                                            <input type="text" class="form-control" name="username"
                                                   value="<?php echo e($user->username); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label><?php echo e(__('Device ID')); ?></label>
                                            <input type="number" class="form-control" name="device_id"
                                                   value="<?php echo e($user->device_id); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group   ">
                                            <label><?php echo e(__('Password')); ?></label>
                                            <input type="password" class="form-control" name="password"
                                                   value="<?php echo e($user->password); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-8">
                                        <div class="form-group">
                                            <label><?php echo e(__('Email')); ?></label>
                                            <input type="email" class="form-control" name="email" value="<?php echo e($user->email); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <input type="submit" class="btn btn-block btn-primary col-md-2" value="<?php echo e(__('Send')); ?>">
                                </div>
                            </form>
                        </div>
                        <div class="col-md-4">
                            <div class="card card-user">
                                <div class="card-body">
                                    <p class="card-text">
                                        <div class="author">
                                            <div class="block block-one"></div>
                                            <div class="block block-two"></div>
                                            <div class="block block-three"></div>
                                            <div class="block block-four"></div>
                                            <a href="javascript:void(0)">
                                                
                                                <h5 class="title">Hanta IBMS</h5>
                                            </a>
                                    <p class="description">
                                        Project Implementors
                                    </p>
                                </div>
                                </p>
                                <div class="card-description">

                                </div>
                            </div>
                            <div class="card-footer">
                                <div class="button-container">
                                    <button href="javascript:void(0)" class="btn btn-icon btn-round btn-facebook">
                                        <i class="fab fa-facebook"></i>
                                    </button>
                                    <button href="javascript:void(0)" class="btn btn-icon btn-round btn-twitter">
                                        <i class="fab fa-twitter"></i>
                                    </button>
                                    <button href="javascript:void(0)" class="btn btn-icon btn-round btn-google">
                                        <i class="fab fa-google-plus"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <?php if(auth()->check() && auth()->user()->hasRole('geust')): ?>
        <div class="wrap main-content" data-scrollbar>
            <div class="content">
                <div class="card">
                    <div class="card-body">
                        <div class='col-lg-8'>
                            <h3><i class='fa fa-user-plus pull-right'> <?php echo e(__('Edit')); ?> <?php echo e($user->name); ?></i></h3>
                            <hr>
                            <form action="<?php echo e(route('users.update',[$user->id])); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label><?php echo e(__('Name')); ?></label>
                                            <input type="text" class="form-control" name="name" value="<?php echo e($user->name); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label><?php echo e(__('Username')); ?></label>
                                            <input type="text" class="form-control" name="username"
                                                   value="<?php echo e($user->username); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label><?php echo e(__('Device ID')); ?></label>
                                            <input type="number" class="form-control" name="device_id"
                                                   value="<?php echo e($user->device_id); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group   ">
                                            <label><?php echo e(__('Password')); ?></label>
                                            <input type="password" class="form-control" name="password"
                                                   value="<?php echo e($user->password); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-8">
                                        <div class="form-group">
                                            <label><?php echo e(__('Email')); ?></label>
                                            <input type="email" class="form-control" name="email" value="<?php echo e($user->email); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <input type="submit" class="btn btn-block btn-primary col-md-2" value="<?php echo e(__('Send')); ?>">
                                </div>
                            </form>
                        </div>
                        <div class="col-md-4">
                            <div class="card card-user">
                                <div class="card-body">
                                    <p class="card-text">
                                        <div class="author">
                                            <div class="block block-one"></div>
                                            <div class="block block-two"></div>
                                            <div class="block block-three"></div>
                                            <div class="block block-four"></div>
                                            <a href="javascript:void(0)">
                                                
                                                <h5 class="title">Hanta IBMS</h5>
                                            </a>
                                    <p class="description">
                                        Project Implementors
                                    </p>
                                </div>
                                </p>
                                <div class="card-description">

                                </div>
                            </div>
                            <div class="card-footer">
                                <div class="button-container">
                                    <button href="javascript:void(0)" class="btn btn-icon btn-round btn-facebook">
                                        <i class="fab fa-facebook"></i>
                                    </button>
                                    <button href="javascript:void(0)" class="btn btn-icon btn-round btn-twitter">
                                        <i class="fab fa-twitter"></i>
                                    </button>
                                    <button href="javascript:void(0)" class="btn btn-icon btn-round btn-google">
                                        <i class="fab fa-google-plus"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>