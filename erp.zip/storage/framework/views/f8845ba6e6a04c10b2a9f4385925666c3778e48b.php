<?php $__env->startSection('title', 'Users Management'); ?>

<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap.min.css">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin')): ?>
    <div class="wrap main-content persian" data-scrollbar>
        <div class="content">
            <div class="col-lg-12 ">
                <h3><i class="fa fa-user pull-right">&nbsp;<?php echo e(__('User Administration')); ?></i>
                    <a href="<?php echo e(route('roles.index')); ?>" class="btn btn-primary pull-left"><i
                                class="tim-icons icon-simple-add"></i><?php echo e(__('Roles')); ?></a>
                    <a href="<?php echo e(route('permissions.index')); ?>"
                       class="btn btn-primary pull-left"><i
                                class="tim-icons icon-simple-add"></i><?php echo e(__('Permissions')); ?></a>
                    <a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary"><i
                                class="tim-icons icon-simple-add"></i><?php echo e(__('Add User')); ?></a>

                </h3>
                <hr>
            </div>
            <div class="card">
                <div class="card-body">
                    <div class="col-md-9">
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive" style="font-size: 13px;color: #65767c">
                                    <table id="table" class="table  table-striped">
                                        <thead>
                                        <tr>
                                            <th><?php echo e(__('Name')); ?></th>
                                            <th><?php echo e(__('Username')); ?></th>
                                            <th><?php echo e(__('Code')); ?></th>
                                            
                                            
                                            <th><?php echo e(__('Operations')); ?></th>
                                        </tr>
                                        </thead>

                                        <tbody>
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_select): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>

                                                <td><?php echo e($user_select->name); ?></td>
                                                <td><?php echo e($user_select->username); ?></td>
                                                <td><?php echo e($user_select->device_id); ?></td>


                                                <td>
                                                    <a href="<?php echo e(route('users.edit', $user_select->id)); ?>"
                                                       class="btn btn-link btn-warning btn-icon btn-sm btn-neutral  edit">
                                                        <i class="tim-icons icon-pencil"></i></a>
                                                    <form id="-form-delete<?php echo e($user_select->id); ?>" style="display: none;"
                                                          method="POST" action="<?php echo e(route('users.destroy', $user_select->id)); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                    </form>
                                                    <a class="btn btn-link btn-danger btn-icon btn-sm btn-neutral remove"
                                                       onclick="if(confirm('آیا از حذف این پروژه اطمینان دارید؟')){
                                                               event.preventDefault();
                                                               document.getElementById('-form-delete<?php echo e($user_select->id); ?>').submit();
                                                               }else {
                                                               event.preventDefault();}"><i
                                                                class="tim-icons icon-simple-remove"></i></a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>

                                    </table>
                                </div>
                                </h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <br><br>
                        <div class="card card-user">
                            <div class="card-body">
                                <p class="card-text">
                                    <div class="author">
                                        <div class="block block-one"></div>
                                        <div class="block block-two"></div>
                                        <div class="block block-three"></div>
                                        <div class="block block-four"></div>
                                        <a href="javascript:void(0)">
                                            
                                            <h5 class="title">Hanta IBMS</h5>
                                        </a>
                                <p class="description">
                                    
                                </p>
                            </div>
                            <div class="card-description">

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div></div>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('finance')): ?>
    <div class="wrap main-content" data-scrollbar>
        <div class="content">
            <div class="card">
                <div class="card-body">
                    <div class="col-md-9">
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive" style="font-size: 13px;color: #65767c">
                                    <table id="table" class="table  table-striped">
                                        <thead>
                                        <tr>
                                            <th><?php echo e(__('ID')); ?></th>
                                            <th><?php echo e(__('Name')); ?></th>
                                            <th><?php echo e(__('Username')); ?></th>
                                            
                                            
                                            <th><?php echo e(__('Operations')); ?></th>
                                        </tr>
                                        </thead>

                                        <tbody>
                                            <tr>
                                                <td>1</td>
                                                <td><?php echo e($role_user->name); ?></td>
                                                <td><?php echo e($role_user->username); ?></td>


                                                <td>
                                                    <a href="<?php echo e(route('users.edit', $role_user->id)); ?>"
                                                       class="btn btn-link btn-warning btn-icon btn-sm btn-neutral  edit">
                                                        <i class="tim-icons icon-pencil"></i></a>
                                                </td>
                                            </tr>
                                        </tbody>

                                    </table>
                                </div>
                                </h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <br><br>
                        <div class="card card-user">
                            <div class="card-body">
                                <p class="card-text">
                                    <div class="author">
                                        <div class="block block-one"></div>
                                        <div class="block block-two"></div>
                                        <div class="block block-three"></div>
                                        <div class="block block-four"></div>
                                        <a href="javascript:void(0)">
                                            
                                            <h5 class="title">Hanta IBMS</h5>
                                        </a>
                                <p class="description">
                                    
                                </p>
                            </div>
                            <div class="card-description">

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div></div>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('dealership')): ?>
    <div class="wrap main-content" data-scrollbar>
        <div class="content">
            <div class="card">
                <div class="card-body">
                    <div class="col-md-9">
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive" style="font-size: 13px;color: #65767c">
                                    <table id="table" class="table  table-striped">
                                        <thead>
                                        <tr>
                                            <th><?php echo e(__('ID')); ?></th>
                                            <th><?php echo e(__('Name')); ?></th>
                                            <th><?php echo e(__('Username')); ?></th>
                                            
                                            
                                            <th><?php echo e(__('Operations')); ?></th>
                                        </tr>
                                        </thead>

                                        <tbody>
                                            <tr>
                                                <td>1</td>
                                                <td><?php echo e($role_user->name); ?></td>
                                                <td><?php echo e($role_user->username); ?></td>


                                                <td>
                                                    <a href="<?php echo e(route('users.edit', $role_user->id)); ?>"
                                                       class="btn btn-link btn-warning btn-icon btn-sm btn-neutral  edit">
                                                        <i class="tim-icons icon-pencil"></i></a>
                                                </td>
                                            </tr>
                                        </tbody>

                                    </table>
                                </div>
                                </h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <br><br>
                        <div class="card card-user">
                            <div class="card-body">
                                <p class="card-text">
                                    <div class="author">
                                        <div class="block block-one"></div>
                                        <div class="block block-two"></div>
                                        <div class="block block-three"></div>
                                        <div class="block block-four"></div>
                                        <a href="javascript:void(0)">
                                            
                                            <h5 class="title">Hanta IBMS</h5>
                                        </a>
                                <p class="description">
                                    
                                </p>
                            </div>
                            <div class="card-description">

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div></div>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('repository')): ?>
    <div class="wrap main-content" data-scrollbar>
        <div class="content">
            <div class="card">
                <div class="card-body">
                    <div class="col-md-9">
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive" style="font-size: 13px;color: #65767c">
                                    <table id="table" class="table  table-striped">
                                        <thead>
                                        <tr>
                                            <th><?php echo e(__('ID')); ?></th>
                                            <th><?php echo e(__('Name')); ?></th>
                                            <th><?php echo e(__('Username')); ?></th>
                                            
                                            
                                            <th><?php echo e(__('Operations')); ?></th>
                                        </tr>
                                        </thead>

                                        <tbody>
                                            <tr>
                                                <td>1</td>
                                                <td><?php echo e($role_user->name); ?></td>
                                                <td><?php echo e($role_user->username); ?></td>


                                                <td>
                                                    <a href="<?php echo e(route('users.edit', $role_user->id)); ?>"
                                                       class="btn btn-link btn-warning btn-icon btn-sm btn-neutral  edit">
                                                        <i class="tim-icons icon-pencil"></i></a>
                                                </td>
                                            </tr>
                                        </tbody>

                                    </table>
                                </div>
                                </h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <br><br>
                        <div class="card card-user">
                            <div class="card-body">
                                <p class="card-text">
                                    <div class="author">
                                        <div class="block block-one"></div>
                                        <div class="block block-two"></div>
                                        <div class="block block-three"></div>
                                        <div class="block block-four"></div>
                                        <a href="javascript:void(0)">
                                            
                                            <h5 class="title">Hanta IBMS</h5>
                                        </a>
                                <p class="description">
                                    
                                </p>
                            </div>
                            <div class="card-description">

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div></div>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('product')): ?>
    <div class="wrap main-content" data-scrollbar>
        <div class="content">
            <div class="card">
                <div class="card-body">
                    <div class="col-md-9">
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive" style="font-size: 13px;color: #65767c">
                                    <table id="table" class="table  table-striped">
                                        <thead>
                                        <tr>
                                            <th><?php echo e(__('ID')); ?></th>
                                            <th><?php echo e(__('Name')); ?></th>
                                            <th><?php echo e(__('Username')); ?></th>
                                            
                                            
                                            <th><?php echo e(__('Operations')); ?></th>
                                        </tr>
                                        </thead>

                                        <tbody>
                                            <tr>
                                                <td>1</td>
                                                <td><?php echo e($role_user->name); ?></td>
                                                <td><?php echo e($role_user->username); ?></td>


                                                <td>
                                                    <a href="<?php echo e(route('users.edit', $role_user->id)); ?>"
                                                       class="btn btn-link btn-warning btn-icon btn-sm btn-neutral  edit">
                                                        <i class="tim-icons icon-pencil"></i></a>
                                                </td>
                                            </tr>
                                        </tbody>

                                    </table>
                                </div>
                                </h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <br><br>
                        <div class="card card-user">
                            <div class="card-body">
                                <p class="card-text">
                                    <div class="author">
                                        <div class="block block-one"></div>
                                        <div class="block block-two"></div>
                                        <div class="block block-three"></div>
                                        <div class="block block-four"></div>
                                        <a href="javascript:void(0)">
                                            
                                            <h5 class="title">Hanta IBMS</h5>
                                        </a>
                                <p class="description">
                                    
                                </p>
                            </div>
                            <div class="card-description">

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div></div>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('order')): ?>
    <div class="wrap main-content" data-scrollbar>
        <div class="content">
            <div class="card">
                <div class="card-body">
                    <div class="col-md-9">
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive" style="font-size: 13px;color: #65767c">
                                    <table id="table" class="table  table-striped">
                                        <thead>
                                        <tr>
                                            <th><?php echo e(__('ID')); ?></th>
                                            <th><?php echo e(__('Name')); ?></th>
                                            <th><?php echo e(__('Username')); ?></th>
                                            
                                            
                                            <th><?php echo e(__('Operations')); ?></th>
                                        </tr>
                                        </thead>

                                        <tbody>
                                            <tr>
                                                <td>1</td>
                                                <td><?php echo e($role_user->name); ?></td>
                                                <td><?php echo e($role_user->username); ?></td>


                                                <td>
                                                    <a href="<?php echo e(route('users.edit', $role_user->id)); ?>"
                                                       class="btn btn-link btn-warning btn-icon btn-sm btn-neutral  edit">
                                                        <i class="tim-icons icon-pencil"></i></a>
                                                </td>
                                            </tr>
                                        </tbody>

                                    </table>
                                </div>
                                </h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <br><br>
                        <div class="card card-user">
                            <div class="card-body">
                                <p class="card-text">
                                    <div class="author">
                                        <div class="block block-one"></div>
                                        <div class="block block-two"></div>
                                        <div class="block block-three"></div>
                                        <div class="block block-four"></div>
                                        <a href="javascript:void(0)">
                                            
                                            <h5 class="title">Hanta IBMS</h5>
                                        </a>
                                <p class="description">
                                    
                                </p>
                            </div>
                            <div class="card-description">

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div></div>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('geust')): ?>
    <div class="wrap main-content" data-scrollbar>
        <div class="content">
            <div class="card">
                <div class="card-body">
                    <div class="col-md-9">
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive" style="font-size: 13px;color: #65767c">
                                    <table id="table" class="table  table-striped">
                                        <thead>
                                        <tr>
                                            <th><?php echo e(__('ID')); ?></th>
                                            <th><?php echo e(__('Name')); ?></th>
                                            <th><?php echo e(__('Username')); ?></th>
                                            
                                            
                                            <th><?php echo e(__('Operations')); ?></th>
                                        </tr>
                                        </thead>

                                        <tbody>
                                            <tr>
                                                <td>1</td>
                                                <td><?php echo e($role_user->name); ?></td>
                                                <td><?php echo e($role_user->username); ?></td>


                                                <td>
                                                    <a href="<?php echo e(route('users.edit', $role_user->id)); ?>"
                                                       class="btn btn-link btn-warning btn-icon btn-sm btn-neutral  edit">
                                                        <i class="tim-icons icon-pencil"></i></a>
                                                </td>
                                            </tr>
                                        </tbody>

                                    </table>
                                </div>
                                </h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <br><br>
                        <div class="card card-user">
                            <div class="card-body">
                                <p class="card-text">
                                    <div class="author">
                                        <div class="block block-one"></div>
                                        <div class="block block-two"></div>
                                        <div class="block block-three"></div>
                                        <div class="block block-four"></div>
                                        <a href="javascript:void(0)">
                                            
                                            <h5 class="title">Hanta IBMS</h5>
                                        </a>
                                <p class="description">
                                    
                                </p>
                            </div>
                            <div class="card-description">

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div></div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
            <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
            <script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap.min.js"></script>
            <script>
                $(document).ready(function() {
                    $('#table').DataTable({
                        "language": {
                            "sEmptyTable":     "هیچ داده ای در جدول وجود ندارد",
                            "sInfo":           "نمایش _START_ تا _END_ از _TOTAL_ رکورد",
                            "sInfoEmpty":      "نمایش 0 تا 0 از 0 رکورد",
                            "sInfoFiltered":   "(فیلتر شده از _MAX_ رکورد)",
                            "sInfoPostFix":    "",
                            "sInfoThousands":  ",",
                            "sLengthMenu":     "نمایش _MENU_ رکورد",
                            "sLoadingRecords": "در حال بارگزاری...",
                            "sProcessing":     "در حال پردازش...",
                            "sSearch":         "جستجو:",
                            "sZeroRecords":    "رکوردی با این مشخصات پیدا نشد",
                            "oPaginate": {
                                "sFirst":    "ابتدا",
                                "sLast":     "انتها",
                                "sNext":     "بعدی",
                                "sPrevious": "قبلی"
                            },
                            "oAria": {
                                "sSortAscending":  ": فعال سازی نمایش به صورت صعودی",
                                "sSortDescending": ": فعال سازی نمایش به صورت نزولی"
                            }
                        }
                    });
                });
            </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>