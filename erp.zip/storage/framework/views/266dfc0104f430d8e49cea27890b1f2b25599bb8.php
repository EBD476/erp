<nav class="navbar navbar-expand-lg fixed-top bg-gradient-light p-md-0 text-danger">
    <div class="container-fluid">
        <div class="navbar-wrapper">
            <div class="navbar-minimize d-inline">
                <button class="minimize-sidebar btn btn-link btn-just-icon" rel="tooltip"
                        data-original-title="Sidebar toggle" data-placement="right">
                    <i class="tim-icons icon-align-center visible-on-sidebar-regular"></i>
                    <i class="tim-icons icon-bullet-list-67 visible-on-sidebar-mini"></i>
                </button>
            </div>
            <div class="navbar-toggle d-inline">
                <button type="button" class="navbar-toggler">
                    <span class="navbar-toggler-bar bar1"></span>
                    <span class="navbar-toggler-bar bar2"></span>
                    <span class="navbar-toggler-bar bar3"></span>
                </button>
            </div>
            <a class="navbar-brand font-weight-bold" href="javascript:void(0)"><?php echo $__env->yieldContent('title'); ?></a>
        </div>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation"
                aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-bar navbar-kebab"></span>
            <span class="navbar-toggler-bar navbar-kebab"></span>
            <span class="navbar-toggler-bar navbar-kebab"></span>
        </button>
        <div class="collapse navbar-collapse" id="navigation">
            <ul class="navbar-nav <?php if(app()->getLocale() == 'fa'): ?> mr-auto <?php else: ?> ml-auto <?php endif; ?>">
                <li class="search-bar input-group">
                    <button class="btn btn-link" id="search-button" data-toggle="modal"
                            data-target="#searchModal"><i class="tim-icons icon-zoom-split"></i>
                        <span class="d-lg-none d-md-block">Search</span>
                    </button>
                </li>
                <li class="dropdown nav-item">
                    <a href="javascript:void(0)" class="dropdown-toggle nav-link" data-toggle="dropdown">
                        <?php $__currentLoopData = $help_desk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $check_status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="notification d-none d-lg-block d-xl-block"></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <i class="tim-icons icon-sound-wave"></i>
                        <p class="d-lg-none">
                            Notifications
                        </p>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-right dropdown-navbar">

                        <li class="nav-link"><a href="<?php echo e(route('projects.show_all_response')); ?>"
                                                class="nav-item dropdown-item"><?php echo e(__('Support Response List')); ?></a>
                        </li>
                        
                        
                        
                        
                        

                        

                        

                        

                        
                        
                        
                        
                        

                        <?php $__currentLoopData = $help_desk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $help_desks_top_bar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="nav-link">
                                    <a href="<?php echo e(route('help_desk.receive_show',$help_desks_top_bar->id)); ?>"
                                       class="nav-item dropdown-item">
                                        <?php echo e(__('You Have One Ticket')); ?>

                                        <?php $__currentLoopData = $type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $types_top_bar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($types_top_bar->id == $help_desks_top_bar->hhd_type): ?>
                                                <?php echo e($types_top_bar->th_name); ?>

                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__currentLoopData = $priority; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $priorities): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($priorities->id == $help_desks_top_bar->hhd_priority): ?>
                                                <?php echo e($priorities->hdp_name); ?>

                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_all): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($user_all->id == $help_desks_top_bar->hhd_request_user_id): ?>
                                                <?php echo e(__('From')); ?>

                                                <?php echo e($user_all->name); ?>

                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e(__('H')); ?>

                                    </a>
                                </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        
                        
                        
                        
                        
                    </ul>
                </li>
                <li class="dropdown nav-item">
                    <a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown">
                        <div class="photo">
                            <img src="<?php echo e(asset('assets/images/user.jpg')); ?>" alt="Profile Photo">
                        </div>
                        <b class="caret d-none d-lg-block d-xl-block"></b>
                        <p class="d-lg-none">
                            Log out
                        </p>
                    </a>
                    <ul class="dropdown-menu dropdown-navbar">
                        <h5 class="dropdown-item"><?php echo e(__('Current User:')); ?><?php echo e(auth()->user()->username); ?></h5>
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        <li class="dropdown-divider"></li>
                        <li class="nav-link">
                            <a class="nav-item dropdown-item" href="<?php echo e(route('logout')); ?>"
                               onclick="event.preventDefault();
                                    document.getElementById('logout-form').submit();">
                                <?php echo e(__('Logout')); ?>

                            </a>
                            
                            
                            
                            
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                  style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>
                        </li>
                    </ul>
                </li>
                <li class="separator d-lg-none"></li>
            </ul>
        </div>
    </div>
</nav>
<div class="modal modal-search fade" id="searchModal" tabindex="-1" role="dialog" aria-labelledby="searchModal"
     aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <input type="text" class="form-control" id="inlineFormInputGroup" placeholder="SEARCH">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <i class="tim-icons icon-simple-remove"></i>
                </button>
            </div>
        </div>
    </div>
</div>
