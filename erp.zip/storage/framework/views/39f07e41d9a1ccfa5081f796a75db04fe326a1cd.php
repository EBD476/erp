<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="perfect-scrollbar-on">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'HANTA ERP')); ?></title>
    <!-- Fonts -->



<!-- Styles -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,600,700,800" rel="stylesheet"/>
    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">

    
    <link href="<?php echo e(asset('assets/css/nucleo-icons.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/style.min.css')); ?>" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-rtl/3.4.0/css/bootstrap-rtl.css" rel="stylesheet"/>
    <?php if(app()->getLocale() == 'fa'): ?>
        <link href="<?php echo e(asset('assets/css/rtl.css')); ?>" rel="stylesheet">
    <?php endif; ?>

    <?php echo $__env->yieldPushContent('css'); ?>
</head>
<body <?php if(app()->getLocale() == 'fa'): ?> class="white-content rtl menu-on-right" <?php else: ?>  class="white-content" <?php endif; ?>>

<div class="wrapper">

    <?php echo $__env->make('layouts.partial.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="main-panel">

        <!-- Navbar -->
    <?php echo $__env->make('layouts.partial.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- End Navbar -->

        <!-- Content -->
    <?php echo $__env->yieldContent('content'); ?>
    <!-- End Content -->

        <!-- Footer -->
    <?php echo $__env->make('layouts.partial.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- End Footer -->


    </div>
</div>

<!-- Scripts -->
<script src="<?php echo e(asset('assets/js/app.js')); ?>" defer></script>
<script src="<?php echo e(asset('assets/js/core/jquery.min.js')); ?> "></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="<?php echo e(asset('assets/js/plugins/persian-numbers-jquery-plugin-master/persianNum.jquery-2.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/plugins/perfect-scrollbar.jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/plugins/popper.min.js')); ?> "></script>
<script src="<?php echo e(asset('assets/js/core/bootstrap.min.js')); ?> "></script>
<script>
    $(document).ready(function () {


        $('body').persianNum({
            forbiddenTag: ['input','div']

        })


        sidebar_mini_active = false;

        var isWindows = navigator.platform.indexOf('Win') > -1 ? true : false;
        /**** Scroller ****/

        if (isWindows) {
            // if ($('.main-panel').length != 0) {
            //     var ps = new PerfectScrollbar('.main-panel', {
            //         wheelSpeed: 2,
            //         wheelPropagation: true,
            //         minScrollbarLength: 20,
            //         suppressScrollX: true
            //     });
            // }

            // if ($('.table-responsive').length != 0) {
            //     var ps = new PerfectScrollbar('.table-responsive', {
            //         wheelSpeed: 2,
            //         wheelPropagation: true,
            //         minScrollbarLength: 20,
            //         suppressScrollX: true
            //     });
            // }
        }


        // if ($.fn.niceScroll) {
        //     var mainScroller = $("html").niceScroll({
        //         zindex: 999999,
        //         boxzoom: true,
        //         cursoropacitymin: 0.5,
        //         cursoropacitymax: 0.8,
        //         cursorwidth: "10px",
        //         cursorborder: "0px solid",
        //         autohidemode: false
        //     });
        // }


    });
</script>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
