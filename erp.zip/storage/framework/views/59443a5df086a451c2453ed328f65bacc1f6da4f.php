<?php $__env->startSection('title',__('Bank Account')); ?>

<?php $__env->startPush('css'); ?>
    <link href="<?php echo e(asset('assets/css/datatables.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/leaflet.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <a href="<?php echo e(route('bank_account.create')); ?>" class="btn btn-primary float-left mb-lg-2">
                        <i class="tim-icons icon-simple-add"></i> &nbsp;
                        <?php echo e(__('New Bank Account')); ?>

                    </a>
                </div>
                <div class="card">
                    <div class="card-body">
                        <div class="col-md-9">
                            <div class="card">
                                <div class="card-header card-header-primary">
                                    <h4 class="card-title text-right font-weight-400"><?php echo e(__('Bank Account List')); ?></h4>
                                    <p class="card-category"></p>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive table-hover">
                                        <table id="table" class="table" cellspacing="0" width="100%">
                                            <thead class=" text-primary">
                                            <th>
                                                <?php echo e(__('ID')); ?>

                                            </th>
                                            <th>
                                                <?php echo e(__('Name')); ?>

                                            </th>
                                            <th>
                                                <?php echo e(__('Balance')); ?>

                                            </th>
                                            <th>
                                                <?php echo e(__('Debt')); ?>

                                            </th>
                                            <th>
                                                <?php echo e(__('Crediting')); ?>

                                            </th>
                                            <th>
                                                <?php echo e(__('Deduction Date')); ?>

                                            </th>
                                            <th>
                                                <?php echo e(__('Deposit Date')); ?>

                                            </th>
                                            <th>
                                                <?php echo e(__('Action')); ?>

                                            </th>
                                            </thead>
                                            <tbody>

                                            <?php $__currentLoopData = $bank_account; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $bank_accounts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <?php echo e($bank_accounts->hba_bank_id); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($bank_accounts->hba_balance); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($bank_accounts->hba_debt); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($bank_accounts->hba_crediting); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($bank_accounts->hba_deduction_date); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($bank_accounts->hba_deposit_date); ?>

                                                    </td>
                                                    <td>
                                                        <div class="dropdown">
                                                            <button type="button"
                                                                    class="btn btn-link dropdown-toggle btn-icon"
                                                                    data-toggle="dropdown">
                                                                <i class="tim-icons icon-settings-gear-63"></i>
                                                            </button>
                                                            <div class="dropdown-menu dropdown-menu-right"
                                                                 aria-labelledby="dropdownMenuLink">
                                                                <a class="dropdown-item"
                                                                   href="<?php echo e(route('bank_account.edit',$bank_accounts->id)); ?>"
                                                                ><?php echo e(__('Edit')); ?></a>
                                                                <form id="-form-delete<?php echo e($bank_accounts->id); ?>"
                                                                      style="display: none;" method="POST"
                                                                      action="<?php echo e(route('bank_account.destroy',$bank_accounts->id)); ?>">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('DELETE'); ?>
                                                                </form>
                                                                <a class="dropdown-item"
                                                                   onclick="if(confirm('آیا از حذف این پروژه اطمینان دارید؟')){
                                                                           event.preventDefault();
                                                                           document.getElementById('-form-delete<?php echo e($bank_accounts->id); ?>').submit();
                                                                           }else {
                                                                           event.preventDefault();}"><?php echo e(__('Delete')); ?></a>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <br><br>
                            <div class="card card-user">
                                <div class="card-body">
                                    <p class="card-text">
                                        <div class="author">
                                            <div class="block block-one"></div>
                                            <div class="block block-two"></div>
                                            <div class="block block-three"></div>
                                            <div class="block block-four"></div>
                                            <a href="javascript:void(0)">
                                                
                                                <h5 class="title">Hanta IBMS</h5>
                                            </a>
                                </div>
                                </p>
                                <div class="card-description">

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <?php $__env->stopSection(); ?>

        <?php $__env->startPush('scripts'); ?>
            <script src="<?php echo e(asset('assets/js/plugins/leaflet.js')); ?>"></script>
            <script src="<?php echo e(asset('assets/js/plugins/datatables.min.js')); ?>"></script>
            <script>
                $(document).ready(function () {
                    $('#table').DataTable({
                        "pagingType": "full_numbers",
                        "lengthMenu": [
                            [10, 25, 50, -1],
                            [10, 25, 50, "All"]
                        ],
                        responsive: true,
                        language: {
                            search: "_INPUT_",
                            searchPlaceholder: "عبارت جستجو",
                            "url": "//cdn.datatables.net/plug-ins/1.10.19/i18n/Persian.json"
                        }

                    });

                });

                $("#checkbox").on('change', function (event) {
                    if ($("#checkbox").val() == 1) {

                    }
                    else {
                        $("#checkbox").val() == 1
                    }
                });


            </script>
    <?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>