<?php $__env->startSection('title',__('Show Response List')); ?>

<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('assets/js/plugins/leaflet.js')); ?>"></script>
<?php $__env->stopPush(); ?>


<?php $__env->startPush('css'); ?>
    <link href="<?php echo e(asset('assets/css/datatables.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/leaflet.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="card">
                    <div class="card-body">
                        <div class="col-md-9">
                            <div class="card">
                                <div class="card-header card-header-primary">
                                    <h4 class="card-title text-right font-weight-400"><?php echo e(__('Support Response List')); ?></h4>
                                    <p class="card-category"></p>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table id="table2" class="table" cellspacing="0" width="100%">
                                            <thead class=" text-primary">
                                            <th>
                                                <?php echo e(__('ID')); ?>

                                            </th>
                                            <th>
                                                <?php echo e(__('Title')); ?>

                                            </th>

                                            <th>
                                                <?php echo e(__('Project Name')); ?>

                                            </th>
                                            <th>
                                                <?php echo e(__('Status')); ?>

                                            </th>
                                            <th>
                                                <?php echo e(__('Created at')); ?>

                                            </th>
                                            <th>
                                                <?php echo e(__('action')); ?>

                                            </th>
                                            </thead>
                                            <tbody>

                                            <?php $__currentLoopData = $request; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $requests): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <?php echo e($key + 1); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($requests->hs_title); ?>

                                                    </td>
                                                    <?php $__currentLoopData = $project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projects_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($projects_name->id == $requests -> hs_project_id): ?>
                                                            <td>
                                                                <?php echo e($projects_name->hp_project_name); ?>

                                                            </td>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php $__currentLoopData = $support_state; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $support_states): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($support_states->id == $requests->hs_status): ?>
                                                            <td>
                                                                <?php echo e($support_states->hss_name); ?>

                                                            </td>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <td>
                                                        <?php echo e($requests->created_at); ?>

                                                    </td>
                                                    <td>
                                                        <div class="dropdown">
                                                            <button type="button"
                                                                    class="btn btn-link dropdown-toggle btn-icon"
                                                                    data-toggle="dropdown">
                                                                <i class="tim-icons icon-settings-gear-63"></i>
                                                            </button>
                                                            <div class="dropdown-menu dropdown-menu-right"
                                                                 aria-labelledby="dropdownMenuLink">
                                                                <a class="dropdown-item"
                                                                   href="<?php echo e(route('projects.show_response',$requests->id)); ?>"
                                                                ><?php echo e(__('Show Response')); ?></a>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <br><br>
                            <div class="card card-user">
                                <div class="card-body">
                                    <p class="card-text">
                                        <div class="author">
                                            <div class="block block-one"></div>
                                            <div class="block block-two"></div>
                                            <div class="block block-three"></div>
                                            <div class="block block-four"></div>
                                            <a href="javascript:void(0)">
                                                
                                                <h5 class="title">Hanta IBMS</h5>
                                            </a>
                                </div>
                                </p>
                                <div class="card-description">

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <?php $__env->stopSection(); ?>

        <?php $__env->startPush('scripts'); ?>

            <script src="<?php echo e(asset('assets/js/plugins/datatables.min.js')); ?>"></script>
            <script>
                $(document).ready(function () {
                    $('#table').DataTable({
                        "pagingType": "full_numbers",
                        "lengthMenu": [
                            [10, 25, 50, -1],
                            [10, 25, 50, "All"]
                        ],
                        responsive: true,
                        language: {
                            search: "_INPUT_",
                            searchPlaceholder: "عبارت جستجو",
                            "url": "//cdn.datatables.net/plug-ins/1.10.19/i18n/Persian.json"
                        }

                    });

                });
            </script>
        <?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>