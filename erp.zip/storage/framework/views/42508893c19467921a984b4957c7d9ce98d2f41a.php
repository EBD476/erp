<?php $__env->startSection('title',__('Install')); ?>

<?php $__env->startPush('css'); ?>
    <link href="<?php echo e(asset('assets/css/datatables.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/leaflet.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="card">
                    <div class="card-body">
                        <div class="col-md-9">
                            <div class="card">
                                <div class="card-header card-header-primary">
                                    <h4 class="card-title text-right font-weight-400"><?php echo e(__('Delivery List')); ?></h4>
                                    <p class="card-category"></p>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive table-hover">
                                        <table id="table" class="table" cellspacing="0" width="100%">
                                            <thead class=" text-primary">
                                            <th>
                                                <?php echo e(__('ID')); ?>

                                            </th>
                                            <th>
                                                <?php echo e(__('Name')); ?>

                                            </th>
                                            <th>
                                                <?php echo e(__('Product Name')); ?>

                                            </th>
                                            <th>
                                                <?php echo e(__('Count')); ?>

                                            </th>
                                            <th>
                                                <?php echo e(__('Client Name')); ?>

                                            </th>
                                            <th>
                                                <?php echo e(__('Status')); ?>

                                            </th>
                                            </thead>
                                            <tbody>

                                            <?php $__currentLoopData = $invoice_status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice_statuses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <?php echo e($invoice_statuses ->hp_Invoice_number); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($invoice_statuses ->hp_project_name); ?>

                                                    </td>
                                                    <td>
                                                        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($products ->id == $invoice_statuses ->hpo_product_id ): ?>
                                                                <?php echo e($products ->hp_product_name); ?>

                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </td>
                                                    <td>
                                                        <?php echo e($invoice_statuses ->hpo_count); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($invoice_statuses ->hpo_client_id); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($invoice_statuses ->hop_due_date); ?>

                                                    </td>
                                                    <td>
                                                        <div class="form-check ">
                                                            <label class="form-check-label">
                                                                <input class="form-check-input checkbox"
                                                                       type="checkbox"
                                                                       data-id="<?php echo e($invoice_statuses->hpo_order_id); ?>">
                                                                <span class="form-check-sign">
                                                                <span class="check"></span>
                                                                </span>
                                                            </label>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <br><br>
                            <div class="card card-user">
                                <div class="card-body">
                                    <p class="card-text">
                                    <div class="author">
                                        <div class="block block-one"></div>
                                        <div class="block block-two"></div>
                                        <div class="block block-three"></div>
                                        <div class="block block-four"></div>
                                        <a href="javascript:void(0)">
                                            
                                            <h5 class="title">Hanta IBMS</h5>
                                        </a>
                                    </div>
                                    </p>
                                    <div class="card-description">

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <?php $__env->stopSection(); ?>

            <?php $__env->startPush('scripts'); ?>
                <script src="<?php echo e(asset('assets/js/plugins/jquery.blockUI.js')); ?>" type="text/javascript"></script>
                <script src="<?php echo e(asset('assets/js/plugins/leaflet.js')); ?>"></script>
                <script src="<?php echo e(asset('assets/js/plugins/datatables.min.js')); ?>"></script>
                <script>
                    $(document).ready(function () {
                        $('#table').DataTable({
                            "pagingType": "full_numbers",
                            "lengthMenu": [
                                [10, 25, 50, -1],
                                [10, 25, 50, "All"]
                            ],
                            responsive: true,
                            language: {
                                search: "_INPUT_",
                                searchPlaceholder: "عبارت جستجو",
                                "url": "//cdn.datatables.net/plug-ins/1.10.19/i18n/Persian.json"
                            }

                        });

                    });

                    // pass checkbox data
                    $('.checkbox').on('change', function (event) {
                        if (event.target.checked) {
                            var data = {
                                id: $(this).data('id'),
                                state: $(this)[0].checked == true ? 5 : 4,

                            };
                            $.blockUI({
                                message: '<?php echo e(__('please wait...')); ?>', css: {
                                    border: 'none',
                                    padding: '15px',
                                    backgroundColor: '#000',
                                    '-webkit-border-radius': '10px',
                                    '-moz-border-radius': '10px',
                                    opacity: .5,
                                    color: '#fff'
                                }
                            });
                            //token
                            $.ajaxSetup({
                                headers: {
                                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                                }
                            });
                            $.ajax({
                                url: '/install/' + data.id,
                                type: 'POST',
                                data: data,
                                dataType: 'json',
                                async: false,
                                method: 'PUT',
                                success: function (data) {
                                    alert(data.response);
                                    setTimeout($.unblockUI, 2000);
                                    location.reload();
                                },
                                cache: false,
                            });
                        }


                    });
                    // End data pass

                </script>
    <?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>