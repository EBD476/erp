<?php $__env->startSection('title',__('Client')); ?>

<?php $__env->startPush('css'); ?>
    <link href="<?php echo e(asset('assets/css/dataTables.bootstrap.min.css')); ?>" rel="stylesheet"/>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin')): ?>
    <div class="content persian">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    
                    <a href="<?php echo e(route('client.create')); ?>" class="btn btn-primary float-left mb-lg-2"><i
                                class="tim-icons icon-simple-add"></i><?php echo e(__('Create new client')); ?></a>
                    
                </div>
                <div class="card">
                    <div class="card-body">
                        <div class="col-md-9">
                            <div class="card">
                                <div class="card-header card-header-primary">
                                    <h4 class="card-title "><?php echo e(__('Client')); ?></h4>
                                    <p class="card-category"></p>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table id="table" class="table" cellspacing="0" width="100%">
                                            <thead class=" text-primary">
                                            <th>
                                                <?php echo e(__('ID')); ?>

                                            </th>
                                            <th>
                                                <?php echo e(__('Name')); ?>

                                            </th>
                                            <th>
                                                <?php echo e(__('Create At')); ?>

                                            </th>
                                            <th>
                                                <?php echo e(__('action')); ?>

                                            </th>
                                            </thead>
                                            <tbody>

                                            <?php $__currentLoopData = $admin_client; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <?php echo e($key + 1); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($client -> hc_name); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($client -> created_at); ?>

                                                    </td>
                                                    <td>
                                                        <div class="dropdown">
                                                            <button type="button"
                                                                    class="btn btn-link dropdown-toggle btn-icon"
                                                                    data-toggle="dropdown">
                                                                <i class="tim-icons icon-settings-gear-63"></i>
                                                            </button>
                                                            <div class="dropdown-menu dropdown-menu-right"
                                                                 aria-labelledby="dropdownMenuLink">
                                                                <a class="dropdown-item"
                                                                   href="<?php echo e(route('client.edit',$client->id)); ?>"
                                                                ><?php echo e(__('Edit')); ?></a>
                                                                <form id="-form-delete<?php echo e($client->id); ?>"
                                                                      style="display: none;" method="POST"
                                                                      action="<?php echo e(route('client.destroy',$client->id)); ?>">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('DELETE'); ?>
                                                                </form>
                                                                <a class="dropdown-item"
                                                                   onclick="if(confirm('آیا از حذف این مشتری اطمینان دارید؟')){
                                                                           event.preventDefault();
                                                                           document.getElementById('-form-delete<?php echo e($client->id); ?>').submit();
                                                                           }else {
                                                                           event.preventDefault();}"><?php echo e(__('Delete')); ?></a>
                                                            </div>
                                                        </div>
                                                    </td>

                                                    <td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <br><br>
                            <div class="card card-user">
                                <div class="card-body">
                                    <p class="card-text">
                                    <div class="author">
                                        <div class="block block-one"></div>
                                        <div class="block block-two"></div>
                                        <div class="block block-three"></div>
                                        <div class="block block-four"></div>
                                        <a href="javascript:void(0)">
                                            
                                            <h5 class="title">Hanta IBMS</h5>
                                        </a>
                                    </div>
                                    </p>
                                    <div class="card-description">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('order')): ?>
    <div class="content persian">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    
                    <a href="<?php echo e(route('client.create')); ?>" class="btn btn-primary float-left mb-lg-2"><i
                                class="tim-icons icon-simple-add"></i><?php echo e(__('Create new client')); ?></a>
                    
                </div>
                <div class="card">
                    <div class="card-body">
                        <div class="col-md-9">
                            <div class="card">
                                <div class="card-header card-header-primary">
                                    <h4 class="card-title "><?php echo e(__('Client')); ?></h4>
                                    <p class="card-category"></p>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table id="table" class="table" cellspacing="0" width="100%">
                                            <thead class=" text-primary">
                                            <th>
                                                <?php echo e(__('ID')); ?>

                                            </th>
                                            <th>
                                                <?php echo e(__('Name')); ?>

                                            </th>
                                            <th>
                                                <?php echo e(__('Create At')); ?>

                                            </th>
                                            <th>
                                                <?php echo e(__('action')); ?>

                                            </th>
                                            </thead>
                                            <tbody>

                                            <?php $__currentLoopData = $client; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <?php echo e($key + 1); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($client -> hc_name); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($client -> created_at); ?>

                                                    </td>
                                                    <td>
                                                        <div class="dropdown">
                                                            <button type="button"
                                                                    class="btn btn-link dropdown-toggle btn-icon"
                                                                    data-toggle="dropdown">
                                                                <i class="tim-icons icon-settings-gear-63"></i>
                                                            </button>
                                                            <div class="dropdown-menu dropdown-menu-right"
                                                                 aria-labelledby="dropdownMenuLink">
                                                                <a class="dropdown-item"
                                                                   href="<?php echo e(route('client.edit',$client->id)); ?>"
                                                                ><?php echo e(__('Edit')); ?></a>
                                                                <form id="-form-delete<?php echo e($client->id); ?>"
                                                                      style="display: none;" method="POST"
                                                                      action="<?php echo e(route('client.destroy',$client->id)); ?>">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('DELETE'); ?>
                                                                </form>
                                                                <a class="dropdown-item"
                                                                   onclick="if(confirm('آیا از حذف این مشتری اطمینان دارید؟')){
                                                                           event.preventDefault();
                                                                           document.getElementById('-form-delete<?php echo e($client->id); ?>').submit();
                                                                           }else {
                                                                           event.preventDefault();}"><?php echo e(__('Delete')); ?></a>
                                                            </div>
                                                        </div>
                                                    </td>

                                                    <td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <br><br>
                            <div class="card card-user">
                                <div class="card-body">
                                    <p class="card-text">
                                    <div class="author">
                                        <div class="block block-one"></div>
                                        <div class="block block-two"></div>
                                        <div class="block block-three"></div>
                                        <div class="block block-four"></div>
                                        <a href="javascript:void(0)">
                                            
                                            <h5 class="title">Hanta IBMS</h5>
                                        </a>
                                    </div>
                                    </p>
                                    <div class="card-description">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>