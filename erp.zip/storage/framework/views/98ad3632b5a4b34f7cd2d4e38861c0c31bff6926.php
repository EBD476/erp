<?php $__env->startSection('title',__('Conversation View')); ?>

<?php $__env->startPush('css'); ?>
    <!-- Chat CSS -->
    <link href="https://mdbootstrap.com/css/addons-pro/chat.css" rel="stylesheet">
    <!-- Chat CSS - minified-->
    <link href="https://mdbootstrap.com/css/addons-pro/chat.min.css" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                
                <div class="card">
                    <div class="card-body">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header card-header-primary">
                                    <h4 class="card-title "><?php echo e(__('Conversation View')); ?></h4>
                                    <p class="card-category"></p>
                                </div>
                                <div class="card purple lighten-4 chat-room">
                                    <div class="card-body">

                                        <!-- Grid row -->
                                        <div class="row px-2">

                                            <!-- Grid column -->
                                            <div class="col-md-6 col-xl-8 pr-md-4 px-lg-auto px-0">

                                                <div class="chat-message">
                                                    <ul class="list-unstyled chat">
                                                        
                                                        <?php $__currentLoopData = $message_send; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $messages_receive): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($messages_receive->hcv_receiver_user_id == $user ): ?>
                                                                <li class="d-flex justify-content-between mb-4"
                                                                    style="direction: ltr">
                                                                    <div class="chat-body white p-3 ml-2 z-depth-1">
                                                                        <div class="header">
                                                                            <?php $__currentLoopData = $user_name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requester_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <?php if($requester_name->id == $messages_receive->hcv_request_user_id): ?>
                                                                                    <img src="https://mdbootstrap.com/img/Photos/Avatars/avatar-6.jpg"
                                                                                         alt="avatar"
                                                                                         class="avatar rounded-circle mr-2 ml-0 z-depth-1">
                                                                                    <strong class="primary-font"
                                                                                            id=""><?php echo e($requester_name->name); ?></strong>

                                                                                <?php endif; ?>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                            <small class="pull-right text-muted"><i
                                                                                        class="far fa-clock"></i> <?php echo e($messages_receive->created_at->format('H:i')); ?>

                                                                            </small>
                                                                        </div>
                                                                        <hr class="w-100">
                                                                        <p class="mb-0">
                                                                            <?php echo e($messages_receive->hcv_message); ?>

                                                                        </p>
                                                                    </div>
                                                                </li>
                                                                <input hidden id="user_receive_id"
                                                                       data-user_receive_id="<?php echo e($messages_receive->hcv_request_user_id); ?>">
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        

                                                        
                                                        <?php $__currentLoopData = $message_send; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message_request_send): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($message_request_send->hcv_request_user_id == $user ): ?>
                                                                <li class="d-flex justify-content-between mb-4"
                                                                    style="direction: rtl">
                                                                    <div class="chat-body white p-3 z-depth-1">
                                                                        <div class="header">
                                                                            <strong class="primary-font">
                                                                                <img src="https://mdbootstrap.com/img/Photos/Avatars/avatar-5.jpg"
                                                                                     alt="avatar"
                                                                                     class="avatar rounded-circle mr-0 ml-3 z-depth-1">
                                                                                <?php echo e(auth()->user()->name); ?>

                                                                            </strong>
                                                                            <small class="pull-right text-muted"><i
                                                                                        class="far fa-clock"></i> <?php echo e($message_request_send->created_at->format('H:i')); ?>

                                                                            </small>
                                                                        </div>
                                                                        <hr class="w-100">
                                                                        <p class="mb-0">
                                                                            <?php echo e($message_request_send->hcv_message); ?>

                                                                        </p>
                                                                    </div>
                                                                </li>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <form id="message-form">
                                                            <li class="white">
                                                                <div class="form-group basic-textarea">
                                                                <textarea class="form-control pl-2 my-0"
                                                                          id="exampleFormControlTextarea2" rows="3"
                                                                          placeholder="<?php echo e(__('Type your message here...')); ?>"></textarea>
                                                                </div>
                                                            </li>
                                                            <button type="submit"
                                                                    class="btn btn-deep-purple btn-rounded btn-sm waves-effect waves-light float-right">
                                                                <?php echo e(__('Send')); ?>

                                                            </button>
                                                        </form>
                                                    </ul>
                                                </div>

                                            </div>
                                            <!-- Grid column -->

                                            <!-- Grid column -->
                                            <div class="col-md-6 col-xl-4 px-0">

                                                <h6 class="font-weight-bold mb-3 text-center text-lg-left"><?php echo e(__('Member')); ?></h6>
                                                <div class="white z-depth-1 px-3 pt-3 pb-0">
                                                    <ul class="list-unstyled friend-list">
                                                        
                                                        
                                                        
                                                        
                                                        
                                                        
                                                        
                                                        
                                                        
                                                        
                                                        
                                                        
                                                        
                                                        
                                                        
                                                        
                                                        <?php $__currentLoopData = $user_name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($users_name->id != auth()->user()->id): ?>
                                                                <li class="p-2">
                                                                    <a href="<?php echo e(route('conversation_view.edit',$users_name->id)); ?>"
                                                                       class="d-flex justify-content-between member">
                                                                        <img src="https://mdbootstrap.com/img/Photos/Avatars/avatar-1.jpg"
                                                                             alt="avatar"
                                                                             class="avatar rounded-circle d-flex align-self-center mr-2 z-depth-1">
                                                                        <div class="text-small">
                                                                            <strong><?php echo e($users_name->name); ?></strong>
                                                                            <p class="last-message text-muted">Lorem
                                                                                ipsum
                                                                                dolor
                                                                                sit.</p>
                                                                            <input hidden class="user_receive_id_null"
                                                                                   data-user_receive_id_null="<?php echo e($users_name->id); ?>">
                                                                        </div>

                                                                        <?php if($counter != null): ?>
                                                                            <div class="chat-footer">
                                                                                <p class="text-smaller text-muted mb-0">
                                                                                    Just now</p>
                                                                                <span class="badge badge-danger float-right"><?php echo e($counter); ?></span>
                                                                            </div>
                                                                        <?php else: ?>
                                                                            <div class="chat-footer">
                                                                                <?php $__currentLoopData = $last_message; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $last_messages): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                    <?php if($last_messages->hcv_request_user_id == $users_name->id and $find_last_message->created_at == $last_messages->created_at): ?>
                                                                                        <p class="text-smaller text-muted mb-0">
                                                                                            <?php echo e($last_messages->created_at->format('H:i')); ?></p>
                                                                                        <span class="text-muted float-right"><i
                                                                                                    class="fas fa-mail-reply"
                                                                                                    aria-hidden="true"></i></span>
                                                                                    <?php endif; ?>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                            </div>
                                                                        <?php endif; ?>

                                                                    </a>
                                                                </li>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </ul>
                                                </div>

                                            </div>
                                            <!-- Grid column -->

                                        </div>
                                        <!-- Grid row -->

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function () {
            $("#message-form").submit(function (event) {
                var data =
                    {
                        message: $('#exampleFormControlTextarea2').val(),
                        user_receive_id: $('#user_receive_id').data('user_receive_id') == null ? $('.user_receive_id_null').data('user_receive_id_null') : $('#user_receive_id').data('user_receive_id'),
                    }
                event.preventDefault();
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    url: '/conversation_view',
                    type: 'POST',
                    data: data,
                    dataType: 'json',
                    async: false,
                    success: function (data) {
                        location.reload();
                    },
                    cache: false,
                });
            });
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>