<footer class="footer">
    <div class="container-fluid persian">
        {{--<ul class="nav">--}}
            {{--<li class="nav-item">--}}
                {{--<a href="javascript:void(0)" class="nav-link">--}}
                    {{--Creative Tim--}}
                {{--</a>--}}
            {{--</li>--}}
            {{--<li class="nav-item">--}}
                {{--<a href="javascript:void(0)" class="nav-link">--}}
                    {{--About Us--}}
                {{--</a>--}}
            {{--</li>--}}
            {{--<li class="nav-item">--}}
                {{--<a href="javascript:void(0)" class="nav-link">--}}
                    {{--Blog--}}
                {{--</a>--}}
            {{--</li>--}}
        {{--</ul>--}}
        <div class="copyright fc-ltr">
            <a href=http://hantaibms.com>Hantaibms</a> Co. by PGH ©2020
        </div>
    </div>
</footer>
